package com.threadline.privateplanner

import org.junit.Assert.*
import org.junit.Test

class BackupCryptoTest {
    @Test fun encryptedBackupRoundTrips() {
        val source = "private task list / non-public notes".toByteArray()
        val encrypted = BackupCrypto.encrypt(source.copyOf(), "an unusually long backup passphrase".toCharArray())
        assertFalse(source.contentEquals(encrypted))
        val decrypted = BackupCrypto.decrypt(encrypted, "an unusually long backup passphrase".toCharArray())
        assertArrayEquals(source, decrypted)
    }

    @Test fun incorrectPassphraseIsRejected() {
        val encrypted = BackupCrypto.encrypt("state".toByteArray(), "correct long passphrase".toCharArray())
        try {
            BackupCrypto.decrypt(encrypted, "incorrect long passphrase".toCharArray())
            fail("Incorrect passphrase must be rejected")
        } catch (expected: IllegalArgumentException) {
            assertTrue(expected.message.orEmpty().contains("Could not decrypt"))
        }
    }

    @Test fun tamperingIsRejected() {
        val encrypted = BackupCrypto.encrypt("state".toByteArray(), "correct long passphrase".toCharArray())
        encrypted[encrypted.lastIndex] = (encrypted.last().toInt() xor 0x01).toByte()
        try {
            BackupCrypto.decrypt(encrypted, "correct long passphrase".toCharArray())
            fail("Tampered backup must be rejected")
        } catch (expected: IllegalArgumentException) {
            assertTrue(expected.message.orEmpty().contains("Could not decrypt"))
        }
    }
}
