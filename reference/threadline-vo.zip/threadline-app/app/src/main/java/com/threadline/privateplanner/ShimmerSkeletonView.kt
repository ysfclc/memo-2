package com.threadline.privateplanner

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator

/** A low-allocation skeleton shimmer used while the local model initializes. */
internal class ShimmerSkeletonView(context: Context, private val dark: Boolean, private val animated: Boolean = true) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val shaderMatrix = Matrix()
    private var shader: LinearGradient? = null
    private var phase = -0.9f
    private var animator: ValueAnimator? = null
    private val density = resources.displayMetrics.density
    private val widths = floatArrayOf(0.92f, 0.68f, 0.46f)
    private val base = if (dark) 0xff26352e.toInt() else 0xffe4ece6.toInt()
    private val shimmer = if (dark) 0xff40564a.toInt() else 0xfff7fbf8.toInt()

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        shader = LinearGradient(
            -w.toFloat(), 0f, w.toFloat(), 0f,
            intArrayOf(base, shimmer, base), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (animated && ValueAnimator.areAnimatorsEnabled() && animator == null) {
            animator = ValueAnimator.ofFloat(-0.9f, 0.9f).apply {
                duration = 1_150L
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener {
                    phase = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
        }
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        animator = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val activeShader = shader
        val barHeight = 7f * density
        val gap = 8f * density
        val startY = (height - (barHeight * 3 + gap * 2)) / 2f
        val left = 1f * density
        val right = width - 1f * density
        shaderMatrix.setTranslate(phase * width, 0f)
        activeShader?.setLocalMatrix(shaderMatrix)
        for (i in widths.indices) {
            val top = startY + i * (barHeight + gap)
            val barRight = left + (right - left) * widths[i]
            rect.set(left, top, barRight, top + barHeight)
            paint.shader = null
            paint.color = base
            canvas.drawRoundRect(rect, barHeight / 2f, barHeight / 2f, paint)
            paint.shader = activeShader
            canvas.drawRoundRect(rect, barHeight / 2f, barHeight / 2f, paint)
        }
        paint.shader = null
    }
}
