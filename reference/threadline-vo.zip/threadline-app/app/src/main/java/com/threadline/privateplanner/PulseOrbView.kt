package com.threadline.privateplanner

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator

/** A restrained, animated status light: motion signals life, not decoration. */
internal class PulseOrbView(context: Context, private val active: Boolean = true) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var glowShader: Shader? = null
    private var pulse = 0.92f
    private var animator: ValueAnimator? = null

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        val animationsAllowed = active && ThreadlineMotion.enabled(reduceMotion = false)
        if (animationsAllowed && animator == null) {
            animator = ValueAnimator.ofFloat(0.78f, 1.12f).apply {
                duration = 1_650L
                repeatCount = ValueAnimator.INFINITE
                repeatMode = ValueAnimator.REVERSE
                interpolator = AccelerateDecelerateInterpolator()
                addUpdateListener { pulse = it.animatedValue as Float; invalidate() }
            }
        }
        if (animationsAllowed) animator?.start()
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val radius = minOf(w, h) / 2f
        glowShader = RadialGradient(w / 2f, h / 2f, radius * 1.8f,
            intArrayOf(0x99b2efcf.toInt(), 0x33b2efcf, 0x00b2efcf),
            floatArrayOf(0f, 0.58f, 1f), Shader.TileMode.CLAMP)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val radius = minOf(width, height) / 2f
        paint.shader = glowShader
        canvas.drawCircle(cx, cy, radius * pulse * 1.8f, paint)
        paint.shader = null
        paint.color = 0xffb2efcf.toInt()
        canvas.drawCircle(cx, cy, radius * 0.72f, paint)
        paint.color = 0xfff5fff8.toInt()
        canvas.drawCircle(cx - radius * 0.2f, cy - radius * 0.22f, radius * 0.2f, paint)
    }
}
