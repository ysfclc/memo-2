package com.threadline.privateplanner

import androidx.core.content.ContextCompat
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.hardware.HardwareBuffer
import android.os.Build
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** Opt-in screenshot bridge. It captures only after an explicit tap in Threadline's floating panel. */
internal class ScreenCaptureAccessibilityService : AccessibilityService() {
    private var receiverRegistered = false
    private val requestReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != FloatingAssistantService.ACTION_SCREEN_CAPTURE_REQUEST) return
            captureCurrentScreen()
        }
    }

    @Suppress("DEPRECATION")
    override fun onServiceConnected() {
        super.onServiceConnected()
        val filter = IntentFilter(FloatingAssistantService.ACTION_SCREEN_CAPTURE_REQUEST)
        ContextCompat.registerReceiver(this, requestReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        receiverRegistered = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* Never inspect screen content passively. */ }
    override fun onInterrupt() = Unit

    private fun captureCurrentScreen() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            sendResult("", "Screen capture requires Android 11 or newer on this device.")
            return
        }
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(screenshot: ScreenshotResult) {
                var hardware: HardwareBuffer? = null
                var bitmap: Bitmap? = null
                try {
                    val screenshotBuffer = screenshot.hardwareBuffer
                    hardware = screenshotBuffer
                    val hardwareBitmap = Bitmap.wrapHardwareBuffer(screenshotBuffer, screenshot.colorSpace)
                    bitmap = hardwareBitmap?.copy(Bitmap.Config.ARGB_8888, false)
                    val ownedBitmap = bitmap
                    if (ownedBitmap == null) {
                        sendResult("", "Android returned an unreadable screenshot.")
                        return
                    }
                    val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                    recognizer.process(InputImage.fromBitmap(ownedBitmap, 0))
                        .addOnSuccessListener { vision ->
                            val extracted = vision.text.trim().take(16_000)
                            sendResult(extracted, if (extracted.isBlank()) "No readable text found. The screen may be mostly visual content." else "")
                        }
                        .addOnFailureListener { sendResult("", "Couldn't extract text from this screen. Try again.") }
                        .addOnCompleteListener {
                            recognizer.close()
                            ownedBitmap.recycle()
                        }
                } catch (_: Exception) {
                    sendResult("", "Screen capture failed. Try again.")
                    bitmap?.recycle()
                } finally {
                    hardware?.close()
                }
            }

            override fun onFailure(errorCode: Int) {
                sendResult("", "Android couldn't capture this screen (error $errorCode). Some secure screens intentionally block screenshots.")
            }
        })
    }

    private fun sendResult(text: String, error: String) {
        sendBroadcast(Intent(FloatingAssistantService.ACTION_SCREEN_TEXT).setPackage(packageName).apply {
            putExtra(FloatingAssistantService.EXTRA_SCREEN_TEXT, text)
            putExtra(FloatingAssistantService.EXTRA_SCREEN_ERROR, error)
            putExtra(FloatingAssistantService.EXTRA_SCREEN_PACKAGE, "current display")
        })
    }

    override fun onUnbind(intent: Intent?): Boolean {
        if (receiverRegistered) runCatching { unregisterReceiver(requestReceiver) }
        receiverRegistered = false
        return super.onUnbind(intent)
    }
}
