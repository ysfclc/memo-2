package com.threadline.privateplanner

/** Semantic design tokens shared by every Threadline screen. */
internal object ThreadlineTokens {
    const val NAVY = 0xff142521.toInt()
    const val BG = 0xfff2f5f1.toInt()
    const val WHITE = 0xffffffff.toInt()
    const val INK = 0xff19242c.toInt()
    const val MUTED = 0xff65736f.toInt()
    const val LIGHT_MUTED = 0xffbdc9c7.toInt()
    const val MINT = 0xffb2efcf.toInt()
    const val TEAL = 0xff276b56.toInt()
    const val BORDER = 0xffe0e7e3.toInt()
    const val FIELD = 0xfff8faf8.toInt()
    const val SECONDARY = 0xffe9efeb.toInt()
    const val ERROR = 0xffff8e83.toInt()
    const val ATTENTION_BG = 0xffe7efe9.toInt()
    const val ATTENTION_BORDER = 0xffc8d9ce.toInt()
    const val VOICE_PANEL_BG = 0xffedf7f0.toInt()
    const val VOICE_PANEL_BORDER = 0xffc5e4d0.toInt()
}

/** High-contrast palettes, with stable semantic tokens for existing feature layouts. */
internal object ThreadlinePalette {
    fun resolve(value: Int, dark: Boolean): Int {
        if (!dark) return value
        return when (value) {
            ThreadlineTokens.BG -> 0xff101714.toInt()
            ThreadlineTokens.INK -> 0xffedf5f0.toInt()
            ThreadlineTokens.MUTED -> 0xffa5b7ae.toInt()
            ThreadlineTokens.LIGHT_MUTED -> 0xffb9cbc2.toInt()
            ThreadlineTokens.TEAL -> 0xff83d8b0.toInt()
            ThreadlineTokens.BORDER -> 0xff34443c.toInt()
            ThreadlineTokens.FIELD -> 0xff1a2420.toInt()
            ThreadlineTokens.SECONDARY -> 0xff24332c.toInt()
            ThreadlineTokens.ATTENTION_BG, ThreadlineTokens.VOICE_PANEL_BG -> 0xff202e27.toInt()
            ThreadlineTokens.ATTENTION_BORDER, ThreadlineTokens.VOICE_PANEL_BORDER -> 0xff3c5146.toInt()
            else -> value
        }
    }

    fun surface(dark: Boolean): Int = if (dark) 0xff18211d.toInt() else ThreadlineTokens.WHITE

    fun heroGradient(dark: Boolean): IntArray = if (dark) {
        intArrayOf(0xff1b342c.toInt(), 0xff142521.toInt(), 0xff101b17.toInt())
    } else {
        intArrayOf(0xff1d4035.toInt(), 0xff142b25.toInt(), 0xff10221d.toInt())
    }

    fun heroBorder(dark: Boolean): Int = if (dark) 0xff355548.toInt() else 0xff2b4b40.toInt()
}
