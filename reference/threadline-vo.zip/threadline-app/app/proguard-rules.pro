# No custom rules are needed for the initial release. Release minification is disabled.
