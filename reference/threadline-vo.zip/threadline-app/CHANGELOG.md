# Changelog

## 1.6.0 — Agent execution, large-model path and floating screen workflow

- Added an in-app download option for the pinned LiteRT-LM Qwen3-4B Thinking model (2,477,192,112 bytes), with exact size and SHA-256 verification. The downloader preserves the prior model until the replacement initializes successfully; failed initialization rolls back.
- Fixed the larger model's inference budget: 4B reasoning gets a bounded thinking budget and 2,048-token output allowance instead of being cut off by the old 256-token cap. Its context payload is reduced to fit its 4,096-token context window.
- Added an available-RAM preflight and RAM-gated CPU fallback for the 4B model to avoid exhausting phone memory. The UI warns that it may not run on lower-memory phones.
- Added deterministic execution for explicit local commands: create/capture a task, create a project, complete an unambiguous task, move an unambiguous task, and create a task with a time-bounded reminder. These do not require a language model. Ambiguous task matches are rejected instead of guessing.
- Added opt-in auto-apply for validated model-proposed internal actions. Off by default. It applies only supported Threadline-local changes; external messages, purchases and publishing remain unsupported.
- Added a floating overlay workflow for one-tap current-screen capture, local OCR, screen summarization, action-item extraction, translation, questions, and local rewriting. It remains in the overlay and offers clipboard output. Screenshot access requires the user to enable Threadline's Accessibility service; capture is requested only on tap. Secure screens may block capture.
- Added on-device voice input in the overlay (when microphone permission and an offline recognition service are available), plus persisted TTS speed, pitch and installed voice selection.
- Removed repeated full-screen rebuilds from speech recognition and TTS status callbacks, preserved scroll position across same-tab updates, and removed a redundant Talk header microphone button.
- Serialized model inference and model replacement to avoid concurrent engine use.

## Verification boundary

Source/resource checks are performed in this environment, but the full Android Gradle build and device-level tests are not available here. The Accessibility screenshot flow, the 4B model initialization, voice recognition, runtime rollback and sustained performance still require a successful GitHub Actions build and testing on the target phone.

## 1.5.0 — High-fidelity UI and motion system

- Extracted shared semantic palette tokens into `ThreadlineDesignSystem.kt`, with matched light, dark and system-following appearances. The appearance selection persists locally.
- Rebalanced navigation to five primary workspaces and kept Talk one tap away in the header; search, floating actions and settings remain directly accessible. Vault locking remains available in Settings.
- Added gradient hero surfaces, clearer visual hierarchy and subtle card elevation in light mode, with restrained flat surfaces in dark mode.
- Added a shared native motion layer in `ThreadlineMotion.kt`: short screen transitions on navigation, staggered first entrances, tactile 0.965 press feedback and tap haptics. Navigation/record refreshes no longer re-animate the full screen repeatedly.
- Added a low-allocation shimmering skeleton while the local model initializes. It stops on detach and respects reduced-motion preferences and Android's animator setting; the status orb now follows the system animator setting too.
- Applied the same press/haptic and staged menu entrance to the floating quick-action overlay; Reduce Motion now refreshes its looping pulse live.
- System appearance tracks Android `uiMode` changes in place, and the unlock transition receives its own single entrance.
- Fixed a new shared-surface contrast regression on the vault-lock screen.
- Kept the existing Kotlin Android stack. No React Native/Reanimated dependency was added; platform property animation avoids introducing a JS runtime or framework migration to a lightweight Android app.
- Bumped Android version to 1.5.0 (version code 6).
- XML, shared palette compilation and source-level markers were checked here. The full Android Gradle build, lint, APK installation, accessibility and 60fps measurements still require the Android SDK/build pipeline and a physical-device test.

## 1.4.0 — Agent workspace and one-tap local AI

- Added a dedicated Agent workspace showing the real governed pipeline: understand → inspect → propose → validate → approve → apply.
- Exposed pending proposal count and a direct review action; the screen explicitly distinguishes current capabilities from future integrations.
- Made the compact local model download a one-tap primary action from Today and the Agent workspace, while retaining the model chooser and compatible-file import path.
- Bumped Android version to 1.4.0 so the next installed debug build is distinguishable from the previous build.
- Static source review completed; a full Android build and physical-device verification are still required in GitHub Actions/on the phone.

## 1.3.0 — Studio and connected work

- Added encrypted Studio content drafts and schema v1 → v2 migration path.
- Added output formats for posts, carousel outlines, short-video scripts, build logs, case studies, technical breakdowns, diagram briefs, website stories, portfolio proof, comments/replies, email drafts and multiple angles.
- Added persistent channel/format/tone preferences and an explicit context-inclusion switch that defaults off.
- Added source reuse from recent captures and completed work, so Studio can reuse existing material rather than requiring copy/paste from scratch.
- Added draft edit, copy, archive, restore, delete and local search.
- Added explicit Private → Public-safe review; this is not a publishing action.
- Extended Talk to propose private content drafts for approval.
- Added Studio to the floating quick-action menu.
- Added a restrained animated status orb.
- Added product system blueprint, user-needs map, feature reality check and outcome-first roadmap.
- Full Android build and device verification remain pending.

## 1.2.0 — Voice-first local assistant

- Added local LiteRT-LM model support, voice conversation, floating quick actions, OCR, task reminders and a daily nudge.
