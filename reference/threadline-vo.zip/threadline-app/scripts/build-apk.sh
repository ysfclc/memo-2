#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle is not installed. Install Gradle 8.14.4 and Android SDK platform 35, then run this script again." >&2
  echo "Alternatively, push this folder to a GitHub repository and run the included Build Threadline Android APK workflow." >&2
  exit 2
fi
if [[ -z "${ANDROID_HOME:-}" && -z "${ANDROID_SDK_ROOT:-}" ]]; then
  echo "Set ANDROID_HOME or ANDROID_SDK_ROOT to your Android SDK installation." >&2
  exit 2
fi
gradle --no-daemon testDebugUnitTest lintDebug assembleDebug
mkdir -p dist
cp app/build/outputs/apk/debug/app-debug.apk dist/threadline-debug.apk
echo "APK created at: $(pwd)/dist/threadline-debug.apk"
