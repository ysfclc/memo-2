# Keep the local JavaScript bridge discoverable by WebView.
-keepclassmembers class com.threadline.privateplanner.MainActivity$VaultBridge {
    @android.webkit.JavascriptInterface <methods>;
}
