package com.threadline.privateplanner

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Periodically checks the official LiteRT Community Hugging Face catalogue.
 * It records only repositories advertising a downloadable .litertlm artifact for in-app discovery.
 */
class ModelCatalogueWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        return try {
        val endpoint = "https://huggingface.co/api/models?author=litert-community&sort=lastModified&direction=-1&limit=80&full=true&blobs=true"
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 25_000
            requestMethod = "GET"
            setRequestProperty("User-Agent", "Threadline-Android/1.9.0")
            setRequestProperty("Accept", "application/json")
        }
        val status = connection.responseCode
        if (status !in 200..299) {
            connection.disconnect()
            return Result.retry()
        }
        val payload = connection.inputStream.bufferedReader().use { it.readText() }
        connection.disconnect()
        val raw = JSONArray(payload)
        val discoveries = JSONArray()
        for (i in 0 until raw.length()) {
            val model = raw.optJSONObject(i) ?: continue
            val repo = model.optString("id").takeIf { it.startsWith("litert-community/") } ?: continue
            val siblings = model.optJSONArray("siblings") ?: continue
            val name = model.optString("modelId", repo.substringAfter('/'))
            val gatedValue = model.opt("gated")
            val gated = gatedValue != null && gatedValue != JSONObject.NULL && gatedValue != false && gatedValue.toString() != "false"
            for (j in 0 until siblings.length()) {
                val sibling = siblings.optJSONObject(j) ?: continue
                val fileName = sibling.optString("rfilename")
                if (!fileName.endsWith(".litertlm", true) || fileName.contains('/') || fileName.contains('\\')) continue
                val lfs = sibling.optJSONObject("lfs")
                val bytes = sibling.optLong("size", lfs?.optLong("size", 0L) ?: 0L)
                // Skip suspicious catalogue entries. The installer also hard-limits files to 3 GiB.
                if (bytes > 3L * 1024 * 1024 * 1024) continue
                val stableId = "$repo::$fileName"
                val escapedRepo = repo.split('/').joinToString("/") { URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
                val escapedFile = URLEncoder.encode(fileName, "UTF-8").replace("+", "%20")
                val localRepo = repo.substringAfter('/').replace(Regex("[^A-Za-z0-9_.() -]"), "_").take(55)
                val localModelStem = fileName.replace(Regex("(?i)\\.litertlm$"), "").replace(Regex("[^A-Za-z0-9_.() -]"), "_").take(130)
                val localFileName = (localRepo + "_" + localModelStem).take(150) + ".litertlm"
                discoveries.put(JSONObject()
                    .put("id", stableId)
                    .put("name", name.replace('-', ' ') + " · " + fileName.removeSuffix(".litertlm"))
                    .put("repo", repo)
                    // Unique app-private basename prevents same-named files from different repos colliding.
                    .put("file", localFileName)
                    .put("remoteFile", fileName).put("bytes", bytes)
                    .put("url", "https://huggingface.co/$escapedRepo/resolve/main/$escapedFile")
                    .put("repoUrl", "https://huggingface.co/$repo")
                    .put("gated", gated)
                    .put("description", "Discovered in the official LiteRT Community catalogue. Check device RAM and licence before installing.")
                    .put("downloads", model.optLong("downloads", 0L))
                    .put("lastModified", model.optString("lastModified")))
            }
        }

        val prefs = applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val discoveredKeys = (0 until discoveries.length()).mapNotNull { discoveries.optJSONObject(it)?.optString("id")?.takeIf(String::isNotBlank) }
        val previousCsv = prefs.getString("known_files", null)
        val current = discoveredKeys.toSet()
        if (previousCsv == null) {
            // First run is a baseline. Avoid startling the user with dozens of old models.
            prefs.edit().putString("known_files", discoveredKeys.joinToString("\n")).apply()
        } else {
            val previous = previousCsv.split('\n').filter { it.isNotBlank() }.toSet()
            val newModels = current - previous
            if (newModels.isNotEmpty()) {
                val names = (0 until discoveries.length()).mapNotNull { discoveries.optJSONObject(it) }
                    .filter { newModels.contains(it.optString("id")) }
                    .map { it.optString("name", it.optString("id")) }
                notifyNewModels(names.size, names.take(3))
            }
            prefs.edit().putString("known_files", (previous + current).joinToString("\n")).apply()
        }
        prefs.edit()
            .putString("discovered_models", discoveries.toString())
            .putLong("catalogue_checked_at", System.currentTimeMillis())
            .apply()
        Result.success()
        } catch (_: Throwable) {
            Result.retry()
        }
    }

    private fun notifyNewModels(count: Int, names: List<String>) {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "threadline-models"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) manager.createNotificationChannel(
            NotificationChannel(channelId, "On-device model discoveries", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val launch = Intent(applicationContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("open_models", true)
        }
        val pending = PendingIntent.getActivity(applicationContext, 19881, launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val body = names.joinToString(", ") + if (count > names.size) " and ${count - names.size} more" else ""
        manager.notify(19881, NotificationCompat.Builder(applicationContext, channelId)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("New on-device models found")
            .setContentText(body.take(180))
            .setStyle(NotificationCompat.BigTextStyle().bigText("New .litertlm files appeared in the official LiteRT Community catalogue: $body. Open Threadline → Local intelligence to review their size and licence before installing."))
            .setContentIntent(pending).setAutoCancel(true).build())
    }

    companion object {
        const val PREFS = "threadline-model-catalogue"
        fun schedule(context: Context) {
            val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
            val request = PeriodicWorkRequestBuilder<ModelCatalogueWorker>(7, TimeUnit.DAYS).setConstraints(constraints).build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork("threadline-model-catalogue", ExistingPeriodicWorkPolicy.UPDATE, request)
        }
    }
}
