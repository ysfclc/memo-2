package app.synthos.fieldwork.data

import android.app.Application
import android.content.ContentResolver
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.synthos.fieldwork.automation.TaskRules
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.withContext

class SynthOsViewModel(application: Application) : AndroidViewModel(application) {
    private val vault = EncryptedVault(application)
    private val persistenceQueue = Channel<AppSnapshot>(Channel.CONFLATED)
    private val preferences = application.getSharedPreferences("synthos_preferences", Application.MODE_PRIVATE)

    private val _snapshot = MutableStateFlow(AppSnapshot())
    val snapshot: StateFlow<AppSnapshot> = _snapshot.asStateFlow()

    private val _vaultReady = MutableStateFlow(false)
    val vaultReady: StateFlow<Boolean> = _vaultReady.asStateFlow()

    private val _vaultError = MutableStateFlow<String?>(null)
    val vaultError: StateFlow<String?> = _vaultError.asStateFlow()

    private val _themeMode = MutableStateFlow(preferences.getString("theme_mode", "SYSTEM") ?: "SYSTEM")
    val themeMode: StateFlow<String> = _themeMode.asStateFlow()


    init {
        viewModelScope.launch {
            for (candidate in persistenceQueue) {
                try {
                    withContext(Dispatchers.IO) { vault.write(candidate) }
                    _vaultError.value = null
                } catch (error: Throwable) {
                    _vaultError.value = safeError(error, "Could not save the encrypted workspace. Export your data before continuing.")
                }
            }
        }
    }
    fun unlockAndLoad() {
        if (_vaultReady.value) return
        viewModelScope.launch {
            try {
                val stored = withContext(Dispatchers.IO) { vault.read() }
                val restored = stored?.recoverInterruptedTasks() ?: AppSnapshot()
                _snapshot.value = restored
                _vaultError.value = null
                _vaultReady.value = true
                if (stored == null) {
                    log("Workspace created on this device.")
                } else if (restored != stored) {
                    persist(restored)
                }
            } catch (error: Throwable) {
                _vaultError.value = safeError(error, "The encrypted workspace could not be opened.")
                _vaultReady.value = true
            }
        }
    }

    /** Clears decrypted data from UI state when the user manually locks the workspace. */
    fun clearSensitiveMemory() {
        _snapshot.value = AppSnapshot()
        _vaultReady.value = false
        _vaultError.value = null
    }

    fun setThemeMode(mode: String) {
        val normalized = mode.uppercase().takeIf { it in setOf("SYSTEM", "LIGHT", "DARK") } ?: "SYSTEM"
        _themeMode.value = normalized
        preferences.edit().putString("theme_mode", normalized).apply()
    }

    fun createTask(title: String, rawUrl: String, kind: TaskKind, query: String): String? {
        val validation = TaskRules.validate(title, rawUrl, kind, query)
        if (validation != null) return validation
        val normalizedUrl = runCatching { TaskRules.normalizeHttpsUrl(rawUrl) }.getOrElse { return it.message ?: "Invalid URL." }
        val task = TaskRecord(
            title = title.trim(),
            targetUrl = normalizedUrl,
            kind = kind,
            query = query.trim(),
            status = TaskStatus.QUEUED,
            lastMessage = if (normalizedUrl.isBlank()) "Will use the current browser page." else "Ready to open the target page."
        )
        updateSnapshot { current ->
            current.copy(tasks = (listOf(task) + current.tasks).take(200))
                .withActivity("Task created: ${task.title}", task.id)
        }
        return null
    }

    fun markTaskRunning(id: String, message: String = "Waiting for the page. Sign in if needed, then continue.") {
        updateSnapshot { current ->
            current.updateTask(id) { it.copy(status = TaskStatus.RUNNING, lastMessage = message, updatedAt = nowMillis()) }
                .withActivity("Task started: ${current.tasks.firstOrNull { it.id == id }?.title ?: "Task"}", id)
        }
    }

    fun markTaskNeedsReview(id: String, message: String) {
        updateSnapshot { current ->
            current.updateTask(id) { it.copy(status = TaskStatus.NEEDS_REVIEW, lastMessage = message, updatedAt = nowMillis()) }
                .withActivity(message, id)
        }
    }

    fun completeTask(id: String, evidence: EvidenceRecord?, message: String = "Completed and verified.") {
        updateSnapshot { current ->
            var next = current.updateTask(id) { it.copy(status = TaskStatus.COMPLETED, lastMessage = message, updatedAt = nowMillis()) }
            if (evidence != null) next = next.copy(evidence = (listOf(evidence) + next.evidence).take(150))
            next.withActivity("Task completed: $message", id)
        }
    }

    fun failTask(id: String, message: String, blocked: Boolean = false) {
        updateSnapshot { current ->
            current.updateTask(id) {
                it.copy(status = if (blocked) TaskStatus.BLOCKED else TaskStatus.FAILED, lastMessage = message, updatedAt = nowMillis())
            }.withActivity("Task ${if (blocked) "blocked" else "failed"}: $message", id, if (blocked) "WARN" else "ERROR")
        }
    }

    fun addEvidence(evidence: EvidenceRecord) {
        updateSnapshot { current -> current.copy(evidence = (listOf(evidence) + current.evidence).take(150)).withActivity("Evidence captured: ${evidence.title}", evidence.taskId) }
    }

    fun addCouncilRun(run: CouncilRunRecord) {
        updateSnapshot { current ->
            current.copy(councilRuns = (listOf(run) + current.councilRuns.filterNot { it.id == run.id }).take(60))
                .withActivity("Council completed: ${run.pattern.lowercase().replace('_', ' ')} · ${run.turns.count { it.status == "COMPLETED" }} completed turn(s)")
        }
    }

    fun updateCouncilDecision(id: String, decision: String) {
        updateSnapshot { current ->
            current.copy(councilRuns = current.councilRuns.map { run ->
                if (run.id == id) run.copy(finalDecision = decision.trim().take(4_000)) else run
            }).withActivity("Final decision updated for Council run ${id.take(8)}.")
        }
    }

    fun deleteCouncilRun(id: String) {
        updateSnapshot { current -> current.copy(councilRuns = current.councilRuns.filterNot { it.id == id }).withActivity("Council run removed from history.") }
    }

    fun deleteEvidence(id: String) {
        updateSnapshot { current -> current.copy(evidence = current.evidence.filterNot { it.id == id }).withActivity("Evidence item deleted.") }
    }

    fun deleteTask(id: String) {
        updateSnapshot { current -> current.copy(tasks = current.tasks.filterNot { it.id == id }).withActivity("Task deleted.", id) }
    }

    fun log(message: String, level: String = "INFO", taskId: String = "") {
        updateSnapshot { it.withActivity(message, taskId, level) }
    }

    fun exportTo(uri: Uri, resolver: ContentResolver, onDone: (String?) -> Unit) {
        viewModelScope.launch {
            val outcome = withContext(Dispatchers.IO) {
                runCatching {
                    val content = _snapshot.value.copy(themeMode = _themeMode.value).toJson()
                    require(content.toByteArray(Charsets.UTF_8).size <= MAX_WORKSPACE_BACKUP_BYTES) { "Export is larger than 40 MB." }
                    resolver.openOutputStream(uri, "wt")?.use { output -> output.write(content.toByteArray(Charsets.UTF_8)) }
                        ?: error("Could not open the selected destination.")
                }.exceptionOrNull()
            }
            onDone(outcome?.let { safeError(it, "Export failed.") })
            if (outcome == null) log("Workspace exported to a user-selected JSON file.")
        }
    }

    fun importFrom(uri: Uri, resolver: ContentResolver, onDone: (String?) -> Unit) {
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val text = resolver.openInputStream(uri)?.use { stream ->
                        val buffer = java.io.ByteArrayOutputStream()
                        val chunk = ByteArray(8_192)
                        var total = 0
                        while (true) {
                            val count = stream.read(chunk)
                            if (count < 0) break
                            total += count
                            require(total <= MAX_WORKSPACE_BACKUP_BYTES) { "Import file is larger than 40 MB." }
                            buffer.write(chunk, 0, count)
                        }
                        buffer.toByteArray().toString(Charsets.UTF_8)
                    } ?: error("Could not read the selected file.")
                    AppSnapshot.fromJson(text).recoverInterruptedTasks()
                }
            }
            result.fold(
                onSuccess = { imported ->
                    _snapshot.value = imported
                    setThemeMode(imported.themeMode)
                    _vaultError.value = null
                    _vaultReady.value = true
                    persist(imported)
                    log("Workspace restored from a JSON export.")
                    onDone(null)
                },
                onFailure = { onDone(safeError(it, "Import failed.")) }
            )
        }
    }

    private fun updateSnapshot(transform: (AppSnapshot) -> AppSnapshot) {
        if (!_vaultReady.value || _vaultError.value != null) return
        val next = transform(_snapshot.value)
        _snapshot.value = next
        persist(next)
    }

    private fun persist(snapshot: AppSnapshot) {
        persistenceQueue.trySend(snapshot)
    }

    private fun AppSnapshot.withActivity(message: String, taskId: String = "", level: String = "INFO"): AppSnapshot =
        copy(activity = (listOf(ActivityRecord(message = message, taskId = taskId, level = level)) + activity).take(500))

    private fun AppSnapshot.updateTask(id: String, transform: (TaskRecord) -> TaskRecord): AppSnapshot =
        copy(tasks = tasks.map { task -> if (task.id == id) transform(task) else task })

    private fun safeError(error: Throwable, fallback: String): String {
        val message = error.message?.trim().orEmpty()
        return (message.takeIf { it.isNotBlank() } ?: fallback).take(220)
    }
}
