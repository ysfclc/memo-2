package app.synthos.fieldwork.data

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

private const val MAX_TASKS = 200
private const val MAX_EVIDENCE = 150
private const val MAX_ACTIVITY = 500
private const val MAX_COUNCIL_RUNS = 60
private const val MAX_COUNCIL_TURNS = 12
private const val MAX_CONTENT_CHARS = 15_000
const val MAX_WORKSPACE_BACKUP_BYTES = 40 * 1024 * 1024
private const val MAX_SERIALIZED_BYTES = MAX_WORKSPACE_BACKUP_BYTES
private const val MAX_URL_CHARS = 2_048

fun newId(): String = UUID.randomUUID().toString()

fun nowMillis(): Long = System.currentTimeMillis()

enum class TaskKind(val label: String, val description: String) {
    CAPTURE_PAGE("Capture page", "Save readable page content and source metadata."),
    EXTRACT_LINKS("Extract links", "Collect visible links and their labels."),
    FIND_TEXT("Find text", "Find a phrase and capture its surrounding context."),
    SCROLL_CAPTURE("Review feed", "Scroll through a feed and collect visible article cards."),
    PREPARE_PROMPT("Prepare prompt", "Fill the current AI chat composer. Sending remains a separate action.");

    companion object {
        fun from(value: String?): TaskKind = entries.firstOrNull { it.name == value } ?: CAPTURE_PAGE
    }
}

enum class TaskStatus(val label: String) {
    QUEUED("Queued"),
    RUNNING("Running"),
    NEEDS_REVIEW("Needs review"),
    COMPLETED("Completed"),
    BLOCKED("Blocked"),
    FAILED("Failed");

    companion object {
        fun from(value: String?): TaskStatus = entries.firstOrNull { it.name == value } ?: QUEUED
    }
}

data class TaskRecord(
    val id: String = newId(),
    val title: String,
    val targetUrl: String = "",
    val kind: TaskKind = TaskKind.CAPTURE_PAGE,
    val query: String = "",
    val status: TaskStatus = TaskStatus.QUEUED,
    val lastMessage: String = "Ready to run",
    val createdAt: Long = nowMillis(),
    val updatedAt: Long = nowMillis()
)

data class EvidenceRecord(
    val id: String = newId(),
    val taskId: String = "",
    val title: String,
    val sourceUrl: String,
    val kind: String,
    val content: String,
    val summary: String,
    val capturedAt: Long = nowMillis(),
    val metadata: String = "{}"
)

data class ActivityRecord(
    val id: String = newId(),
    val at: Long = nowMillis(),
    val level: String = "INFO",
    val message: String,
    val taskId: String = ""
)

data class CouncilSourceRef(
    val evidenceId: String,
    val title: String,
    val sourceUrl: String = ""
)

data class CouncilTurnRecord(
    val id: String = newId(),
    val modelId: String,
    val modelName: String,
    val role: String,
    val requestSummary: String,
    val response: String = "",
    val status: String = "COMPLETED",
    val durationMs: Long = 0,
    val error: String = ""
)

data class CouncilRunRecord(
    val id: String = newId(),
    val prompt: String,
    val pattern: String,
    val turns: List<CouncilTurnRecord>,
    val synthesis: String,
    val finalDecision: String = "",
    val sources: List<CouncilSourceRef> = emptyList(),
    val cloudPermissionGranted: Boolean = false,
    val createdAt: Long = nowMillis(),
    val durationMs: Long = 0
)

data class AppSnapshot(
    val tasks: List<TaskRecord> = emptyList(),
    val evidence: List<EvidenceRecord> = emptyList(),
    val activity: List<ActivityRecord> = emptyList(),
    val themeMode: String = "SYSTEM",
    val councilRuns: List<CouncilRunRecord> = emptyList()
) {
    /** A persisted RUNNING task has lost its WebView execution context after process death. */
    fun recoverInterruptedTasks(): AppSnapshot {
        val interrupted = tasks.count { it.status == TaskStatus.RUNNING }
        if (interrupted == 0) return this
        val message = "SynthOS was closed while this task was active. Review the page and run it again."
        return copy(
            tasks = tasks.map { task ->
                if (task.status == TaskStatus.RUNNING) task.copy(
                    status = TaskStatus.NEEDS_REVIEW,
                    lastMessage = message,
                    updatedAt = nowMillis()
                ) else task
            },
            activity = (listOf(ActivityRecord(message = "Recovered $interrupted interrupted task(s); they need review before running again.", level = "WARN")) + activity).take(MAX_ACTIVITY)
        )
    }

    /** Serialize the complete bounded workspace; refuse oversized snapshots instead of silently dropping user data. */
    fun toJson(): String {
        val serialized = buildJson(
            contentLimit = MAX_CONTENT_CHARS,
            summaryLimit = 2_000,
            metadataLimit = 4_000,
            queryLimit = 8_000,
            activityMessageLimit = 1_000,
            taskLimit = MAX_TASKS,
            evidenceLimit = MAX_EVIDENCE,
            activityLimit = MAX_ACTIVITY,
            councilRunLimit = MAX_COUNCIL_RUNS
        )
        require(serialized.toByteArray(Charsets.UTF_8).size <= MAX_SERIALIZED_BYTES) {
            "Workspace backup exceeds 40 MB. Export or delete older evidence, then try again."
        }
        return serialized
    }

    private fun buildJson(
        contentLimit: Int,
        summaryLimit: Int,
        metadataLimit: Int,
        queryLimit: Int,
        activityMessageLimit: Int,
        taskLimit: Int,
        evidenceLimit: Int,
        activityLimit: Int,
        councilRunLimit: Int
    ): String {
        val root = JSONObject()
        root.put("schemaVersion", 2)
        root.put("exportedAt", nowMillis())
        root.put("themeMode", themeMode)
        root.put("tasks", JSONArray().apply {
            tasks.take(taskLimit).forEach { task ->
                put(JSONObject().apply {
                    put("id", task.id.take(128))
                    put("title", task.title.take(160))
                    put("targetUrl", task.targetUrl.take(MAX_URL_CHARS))
                    put("kind", task.kind.name)
                    put("query", task.query.take(queryLimit))
                    put("status", task.status.name)
                    put("lastMessage", task.lastMessage.take(activityMessageLimit))
                    put("createdAt", task.createdAt)
                    put("updatedAt", task.updatedAt)
                })
            }
        })
        root.put("evidence", JSONArray().apply {
            evidence.take(evidenceLimit).forEach { item ->
                put(JSONObject().apply {
                    put("id", item.id.take(128))
                    put("taskId", item.taskId.take(128))
                    put("title", item.title.take(240))
                    put("sourceUrl", item.sourceUrl.take(MAX_URL_CHARS))
                    put("kind", item.kind.take(80))
                    put("content", item.content.take(contentLimit))
                    put("summary", item.summary.take(summaryLimit))
                    put("capturedAt", item.capturedAt)
                    put("metadata", item.metadata.take(metadataLimit))
                })
            }
        })
        root.put("activity", JSONArray().apply {
            activity.take(activityLimit).forEach { item ->
                put(JSONObject().apply {
                    put("id", item.id.take(128))
                    put("at", item.at)
                    put("level", item.level.take(16))
                    put("message", item.message.take(activityMessageLimit))
                    put("taskId", item.taskId.take(128))
                })
            }
        })
        root.put("councilRuns", JSONArray().apply {
            councilRuns.take(councilRunLimit).forEach { run ->
                put(JSONObject().apply {
                    put("id", run.id.take(128))
                    put("prompt", run.prompt.take(8_000))
                    put("pattern", run.pattern.take(40))
                    put("synthesis", run.synthesis.take(24_000))
                    put("finalDecision", run.finalDecision.take(4_000))
                    put("cloudPermissionGranted", run.cloudPermissionGranted)
                    put("createdAt", run.createdAt)
                    put("durationMs", run.durationMs.coerceAtLeast(0))
                    put("turns", JSONArray().apply {
                        run.turns.take(MAX_COUNCIL_TURNS).forEach { turn ->
                            put(JSONObject().apply {
                                put("id", turn.id.take(128))
                                put("modelId", turn.modelId.take(160))
                                put("modelName", turn.modelName.take(200))
                                put("role", turn.role.take(80))
                                put("requestSummary", turn.requestSummary.take(16_000))
                                put("response", turn.response.take(24_000))
                                put("status", turn.status.take(24))
                                put("durationMs", turn.durationMs.coerceAtLeast(0))
                                put("error", turn.error.take(400))
                            })
                        }
                    })
                    put("sources", JSONArray().apply {
                        run.sources.take(20).forEach { source ->
                            put(JSONObject().apply {
                                put("evidenceId", source.evidenceId.take(128))
                                put("title", source.title.take(240))
                                put("sourceUrl", source.sourceUrl.take(MAX_URL_CHARS))
                            })
                        }
                    })
                })
            }
        })
        return root.toString(2)
    }

    companion object {
        fun fromJson(raw: String): AppSnapshot {
            require(raw.toByteArray(Charsets.UTF_8).size <= MAX_WORKSPACE_BACKUP_BYTES) { "Import file is larger than 40 MB." }
            val root = JSONObject(raw)
            val schema = root.optInt("schemaVersion", 0)
            require(schema in 1..2) { "This backup format is not supported." }

            val usedTaskIds = mutableSetOf<String>()
            val tasks = root.optJSONArray("tasks").toTypedRecords(MAX_TASKS) { row ->
                TaskRecord(
                    id = uniqueImportedId(row.safeString("id"), usedTaskIds),
                    title = row.safeString("title").take(160).ifBlank { "Untitled task" },
                    targetUrl = normalizeImportedHttpsUrl(row.safeString("targetUrl")),
                    kind = TaskKind.from(row.optString("kind")),
                    query = row.safeString("query").take(8_000),
                    status = TaskStatus.from(row.optString("status")),
                    lastMessage = row.safeString("lastMessage").take(1_000),
                    createdAt = row.optLong("createdAt", nowMillis()),
                    updatedAt = row.optLong("updatedAt", nowMillis())
                )
            }
            val usedEvidenceIds = mutableSetOf<String>()
            val evidence = root.optJSONArray("evidence").toTypedRecords(MAX_EVIDENCE) { row ->
                EvidenceRecord(
                    id = uniqueImportedId(row.safeString("id"), usedEvidenceIds),
                    taskId = row.safeString("taskId").take(128),
                    title = row.safeString("title").take(240).ifBlank { "Captured evidence" },
                    sourceUrl = normalizeImportedHttpsUrl(row.safeString("sourceUrl")),
                    kind = row.safeString("kind").take(80),
                    content = row.safeString("content").take(MAX_CONTENT_CHARS),
                    summary = row.safeString("summary").take(2_000),
                    capturedAt = row.optLong("capturedAt", nowMillis()),
                    metadata = row.safeString("metadata").take(4_000).ifBlank { "{}" }
                )
            }
            val usedActivityIds = mutableSetOf<String>()
            val activity = root.optJSONArray("activity").toTypedRecords(MAX_ACTIVITY) { row ->
                ActivityRecord(
                    id = uniqueImportedId(row.safeString("id"), usedActivityIds),
                    at = row.optLong("at", nowMillis()),
                    level = row.safeString("level").take(16).ifBlank { "INFO" },
                    message = row.safeString("message").take(1_000),
                    taskId = row.safeString("taskId")
                )
            }
            val councilRuns = if (schema < 2) emptyList() else root.optJSONArray("councilRuns").toTypedRecords(MAX_COUNCIL_RUNS) { row ->
                val usedTurnIds = mutableSetOf<String>()
                val turns = row.optJSONArray("turns").toTypedRecords(MAX_COUNCIL_TURNS) { turn ->
                    CouncilTurnRecord(
                        id = uniqueImportedId(turn.safeString("id"), usedTurnIds),
                        modelId = turn.safeString("modelId").take(160),
                        modelName = turn.safeString("modelName").take(200),
                        role = turn.safeString("role").take(80),
                        requestSummary = turn.safeString("requestSummary").take(16_000),
                        response = turn.safeString("response").take(24_000),
                        status = turn.safeString("status").take(24).ifBlank { "COMPLETED" },
                        durationMs = turn.optLong("durationMs", 0).coerceAtLeast(0),
                        error = turn.safeString("error").take(400)
                    )
                }
                val sources = row.optJSONArray("sources").toTypedRecords(20) { source ->
                    CouncilSourceRef(
                        evidenceId = source.safeString("evidenceId").take(128),
                        title = source.safeString("title").take(240),
                        sourceUrl = normalizeImportedHttpsUrl(source.safeString("sourceUrl"))
                    )
                }
                CouncilRunRecord(
                    id = row.safeString("id").ifBlank { newId() }.take(128),
                    prompt = row.safeString("prompt").take(8_000),
                    pattern = row.safeString("pattern").take(40),
                    turns = turns,
                    synthesis = row.safeString("synthesis").take(24_000),
                    finalDecision = row.safeString("finalDecision").take(4_000),
                    sources = sources,
                    cloudPermissionGranted = row.optBoolean("cloudPermissionGranted", false),
                    createdAt = row.optLong("createdAt", nowMillis()),
                    durationMs = row.optLong("durationMs", 0).coerceAtLeast(0)
                )
            }
            val theme = root.safeString("themeMode").uppercase().takeIf { it in setOf("SYSTEM", "LIGHT", "DARK") } ?: "SYSTEM"
            return AppSnapshot(tasks, evidence, activity, theme, councilRuns)
        }

        private inline fun <reified T> JSONArray?.toTypedRecords(limit: Int, crossinline map: (JSONObject) -> T): List<T> {
            if (this == null) return emptyList()
            return (0 until minOf(length(), limit)).mapNotNull { index ->
                runCatching { optJSONObject(index)?.let(map) }.getOrNull()
            }
        }
    }
}

private fun JSONObject.safeString(key: String): String = if (isNull(key)) "" else optString(key, "").takeUnless { it == "null" } ?: ""

private fun uniqueImportedId(candidate: String, used: MutableSet<String>): String {
    val normalized = candidate.trim().take(128)
    if (normalized.isNotBlank() && used.add(normalized)) return normalized
    var replacement: String
    do { replacement = newId() } while (!used.add(replacement))
    return replacement
}

private fun normalizeImportedHttpsUrl(raw: String): String {
    val input = raw.trim().take(MAX_URL_CHARS)
    if (input.isBlank()) return ""
    return runCatching {
        val candidate = if (input.contains("://")) input else "https://$input"
        val uri = java.net.URI(candidate)
        require(uri.scheme.equals("https", ignoreCase = true))
        require(!uri.host.isNullOrBlank() && uri.rawUserInfo == null)
        uri.toASCIIString().takeIf { it.length <= MAX_URL_CHARS } ?: ""
    }.getOrDefault("")
}
