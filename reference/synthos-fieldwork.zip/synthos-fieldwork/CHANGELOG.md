# SynthOS Fieldwork 2.0 — Product change log

## What changed from the browser-focused build

- Reframed the app around a native Compose Council workspace; the browser is now under Tools instead of defining the home screen.
- Added five run procedures: independent panel, sequential handoff, draft + critic, debate, and specialist panel.
- Added per-turn model/role/request/response/status/duration records, inspectable request context, failure retention, synthesis, source provenance, and a human-owned final decision.
- Added a local-model manager with install progress, cancellation, size validation, deletion, and `.litertlm` file import.
- Added built-in Qwen3 0.6B and Gemma 4 E2B options, using the standard CPU/GPU LiteRT-LM artifacts.
- Added an optional OpenAI-compatible HTTPS endpoint with Android Keystore-encrypted credentials and explicit per-run cloud-send consent.
- Added Research, Assessment, Decision, and Build prompt starters.
- Added version-2 workspace backups containing Council history, while preserving version-1 backup imports.
- Kept browser evidence, tasks, recovery, workspace export/import, and the device-authentication gate as supporting functionality.

## Important verification boundary

The source was inspected and Kotlin syntax parsing produced no syntax diagnostics in the available environment. A complete Gradle/Android compilation and on-device local-inference test were not possible here because the Android/Gradle dependency download path was unavailable. The supplied GitHub Actions workflow must pass before the APK should be considered build-verified; local inference still needs testing on the target handset.
