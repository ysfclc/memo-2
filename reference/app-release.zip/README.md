# SynthOS — Android local-AI workspace and controlled automation

SynthOS is a local-first Android workspace for on-device reasoning, model comparison, browser inspection, installed-app observation, reusable native workflows, tasks and evidence-backed run history. Model output is treated as a proposal; deterministic app code validates actions and enforces policy.

**Release status:** development source package. Android compilation and real-device acceptance have not been verified in this environment. See `PRODUCT_STATUS.md` for the honest feature matrix and remaining gates. This archive contains no APK and no model weights.

## Product surfaces

### Home and local reasoning

- Conversation-first job entry, saved chat, bounded context, versioned skills and structured proposal parsing.
- Supported proposal types include answers, app inspection, task creation/status changes, action plans, workflow drafts and requests for clarification.
- Workflow proposals are persisted for review; nothing executes merely because a model suggested it.
- Voice input uses Android's on-device speech recognizer when available; text entry remains available when it is not.

### Local model setup

- One-click setup checks SynthOS's private model directory, supports user-granted folder scanning, and offers catalogue downloads.
- Multiple `.litertlm` files can coexist. Catalogue downloads verify publisher-provided SHA-256 values; user-imported model hashes are fingerprints, not publisher authenticity proofs.
- General, planning and screen-interpretation role preferences select among installed files. One model is loaded at a time to manage memory; routing is heuristic and does not establish capabilities that a model lacks.
- Settings includes an on-device inference smoke test. A downloaded file is not considered usable until it initializes and completes inference on the device.
- Inference is local-only. GGUF/llama.cpp, ONNX, TFLite and vision adapters are not implemented. File discovery can identify formats that cannot be executed by this build.

### Local Model Council

The Home workspace provides **Independent opinions**, **Critic review**, and **Debate and synthesis**. It runs up to three installed LiteRT-LM models sequentially, keeps each contribution separate, records individual failures, and saves a report in the conversation. A stop request takes effect after the current inference returns; in-flight inference cannot be forcibly interrupted. Outputs are advisory and do not execute actions or prove consensus.

### Browser workspace

The Home workspace exposes an in-app Android WebView with HTTPS address/search, Back/Forward/Reload and bounded page inspection. Inspection extracts visible body text and basic link/control metadata; it does not read editable field values. Page contents are untrusted evidence, not instructions. This is a browsing and inspection surface—not yet a general browser-DOM automation agent or reusable browser-workflow engine.

### Android Apps and Live surface

- Lists launchable installed applications and opens the selected app as a real Android app.
- SynthOS Live uses Android Accessibility to observe the foreground app's exposed semantic controls and support constrained native workflows.
- This is not a nested Activity, virtual machine or pixel-stream mirror. Target apps can restrict accessibility; host-device automation requires the device unlocked, the target visible and the service enabled.

### Workflows and verification

- Native workflows are editable, saved and explicitly started by the user.
- Supported steps are constrained to launching a target app, tapping exact accessible text, waiting for visible text, Back and bounded delays.
- The final step must be a visible-text postcondition. Missing postconditions, ambiguous controls or execution failures are not reported as success.
- `VERIFIED` means the expected final visible text was observed; it does not prove arbitrary external side effects beyond that observation.

### Remote / guest execution

The optional `remote-runner/` Python companion controls a separately paired Android guest through ADB/UIAutomator. Android Settings accepts an HTTPS endpoint and bearer token; the token is encrypted with Android Keystore. The app can submit an explicitly approved workflow, poll status into Run history, and request guest cancellation. The guest receives the workflow definition only—not chat, prompts, attachments, model weights or AI context. AI inference remains on the phone.

The service requires a trusted TLS certificate, a 32+ character bearer token, a protected host/firewall, an ADB-authorized dedicated guest device and service supervision. It accepts only a strict native-step allowlist, rejects sensitive workflows, stores job state in SQLite, does not replay interrupted work automatically, and marks a run VERIFIED only after the final visible-text condition is observed. The service has unit/API tests but has not been validated against a real paired guest device in this delivery pass. See `REMOTE_RUNNER_PROTOCOL.md`.

### Local data and security

- Encrypted AES-GCM vault using an Android Keystore key and atomic file replacement.
- Saved chat, jobs, tasks, app capability notes, workflow definitions and run history.
- Android shares can be captured as source material where supported. Automatic OCR, PDF extraction, video parsing and image-model interpretation are not implemented.
- User-triggered JSON export is plaintext and must be stored privately. Encrypted backup/import is not implemented.
- Browser page content and shared documents are untrusted input. Models cannot directly bypass workflow validation or Android permissions.

## Build and test

Requirements: JDK 17, Android SDK Platform 35, Build Tools 35.0.0, and network access for Gradle/plugin/dependency downloads.

```bash
cd source
./gradlew --no-daemon clean testDebugUnitTest lint assembleRelease
```

APK output: `source/app/build/outputs/apk/release/app-release.apk`. The release variant uses the generated debug signing key for sideload testing; it is not a production Play Store signing configuration.

Run the guest-runner suite:

```bash
cd remote-runner
python3 -m unittest discover -s tests -v
```

The preserved workflow is at `.github/workflows/build-apk.yml` and is copied to `ci/build-apk.yml`. It runs the guest-runner suite and attempts Android unit tests, lint and release assembly. A successful workflow and real-device acceptance are required before treating the app as shippable.

## Known incomplete areas

- No verified Android build/APK in this environment; Gradle download failed due unavailable DNS/network.
- No GGUF/llama.cpp or vision-capable runtime; no concurrent model inference.
- No general typed entity/relationship graph browser or full mission system.
- No reusable browser DOM workflow engine.
- No automated OCR/PDF/video extraction or image understanding.
- No encrypted backup/import, production signing setup or comprehensive Android instrumentation suite.
- Remote-runner app integration is source-level only until the Android build and paired-device end-to-end tests pass.
