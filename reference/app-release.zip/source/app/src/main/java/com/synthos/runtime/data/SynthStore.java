package com.synthos.runtime.data;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Encrypted, offline-first store. The AES-GCM key is generated and retained by Android Keystore. */
public final class SynthStore {
    private static final String KEY_ALIAS = "synthos.runtime.store.v1";
    private static final String FILE_NAME = "synthos-vault.bin";
    private static volatile SynthStore sharedInstance;
    private final Context appContext;
    private final File storeFile;
    private JSONObject cached;

    public static synchronized SynthStore shared(Context context) throws IOException {
        if (sharedInstance == null) sharedInstance = new SynthStore(context);
        return sharedInstance;
    }

    public SynthStore(Context context) throws IOException {
        appContext = context.getApplicationContext();
        storeFile = new File(appContext.getFilesDir(), FILE_NAME);
        synchronized (this) { cached = readFile(); }
    }

    private JSONObject emptyData() {
        JSONObject o = new JSONObject();
        try { o.put("schemaVersion", 1); o.put("workflows", new JSONArray()); o.put("runs", new JSONArray());
            o.put("jobs", new JSONArray()); o.put("chatMessages", new JSONArray()); o.put("tasks", new JSONArray()); o.put("appCapabilities", new JSONArray()); o.put("updatedAt", System.currentTimeMillis()); }
        catch (JSONException ignored) {}
        return o;
    }

    private SecretKey getOrCreateKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        java.security.Key existing = ks.getKey(KEY_ALIAS, null);
        if (existing instanceof SecretKey) return (SecretKey) existing;
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .setKeySize(256)
                .build());
        return generator.generateKey();
    }

    private JSONObject readFile() throws IOException {
        if (!storeFile.exists()) return emptyData();
        try (FileInputStream in = new FileInputStream(storeFile); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096]; int n; while ((n = in.read(buffer)) >= 0) out.write(buffer, 0, n);
            byte[] payload = out.toByteArray();
            if (payload.length < 14) throw new IOException("Encrypted workspace is incomplete.");
            int ivLength = payload[0] & 0xff;
            if (ivLength < 12 || ivLength > 16 || payload.length <= ivLength + 1) throw new IOException("Encrypted workspace has an invalid header.");
            byte[] iv = new byte[ivLength]; System.arraycopy(payload, 1, iv, 0, ivLength);
            byte[] cipherText = new byte[payload.length - 1 - ivLength]; System.arraycopy(payload, 1 + ivLength, cipherText, 0, cipherText.length);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), new GCMParameterSpec(128, iv));
            byte[] plain = cipher.doFinal(cipherText);
            JSONObject result = new JSONObject(new String(plain, StandardCharsets.UTF_8));
            if (result.optInt("schemaVersion", 0) != 1) throw new IOException("Unsupported workspace schema version.");
            return result;
        } catch (IOException e) { throw e; }
        catch (Exception e) { throw new IOException("Could not decrypt workspace. It was not overwritten; export or restore a valid backup if available.", e); }
    }

    private void persist() throws IOException {
        try {
            cached.put("updatedAt", System.currentTimeMillis());
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey());
            byte[] iv = cipher.getIV(); byte[] encrypted = cipher.doFinal(cached.toString().getBytes(StandardCharsets.UTF_8));
            File temp = new File(storeFile.getParentFile(), FILE_NAME + ".tmp");
            try (FileOutputStream out = new FileOutputStream(temp)) {
                out.write(iv.length); out.write(iv); out.write(encrypted); out.flush(); out.getFD().sync();
            }
            android.system.Os.rename(temp.getAbsolutePath(), storeFile.getAbsolutePath());
        } catch (IOException e) { throw e; }
        catch (Exception e) { throw new IOException("Could not encrypt workspace with Android Keystore.", e); }
    }

    public synchronized List<Workflow> getWorkflows() {
        JSONArray a = cached.optJSONArray("workflows"); ArrayList<Workflow> out = new ArrayList<>();
        if (a != null) for (int i=0;i<a.length();i++) { JSONObject o=a.optJSONObject(i); if(o!=null) out.add(Workflow.fromJson(o)); }
        Collections.sort(out, (x,y) -> Long.compare(y.updatedAt, x.updatedAt)); return out;
    }
    public synchronized Workflow getWorkflow(String id) {
        for (Workflow w : getWorkflows()) if (w.id.equals(id)) return w; return null;
    }
    public synchronized void saveWorkflow(Workflow workflow) throws IOException {
        workflow.updatedAt = System.currentTimeMillis(); JSONArray a = cached.optJSONArray("workflows"); if(a==null) a = new JSONArray();
        JSONArray next = new JSONArray(); boolean replaced = false;
        try {
            for(int i=0;i<a.length();i++) { JSONObject o=a.optJSONObject(i); if(o==null) continue; if(o.optString("id").equals(workflow.id)) { next.put(workflow.toJson()); replaced=true; } else next.put(o); }
            if(!replaced) next.put(workflow.toJson()); cached.put("workflows", next); persist();
        } catch(JSONException e) { throw new IOException("Could not serialize workflow.",e); }
    }
    public synchronized void deleteWorkflow(String id) throws IOException {
        JSONArray a=cached.optJSONArray("workflows"), next=new JSONArray();
        if(a!=null) for(int i=0;i<a.length();i++){ JSONObject o=a.optJSONObject(i); if(o!=null&&!o.optString("id").equals(id)) next.put(o); }
        try { cached.put("workflows",next); persist(); } catch(JSONException e){ throw new IOException(e); }
    }
    public synchronized void saveRun(RunRecord run) throws IOException {
        JSONArray a=cached.optJSONArray("runs"), next=new JSONArray(); boolean replaced=false;
        try {
            if(a!=null) for(int i=0;i<a.length();i++){ JSONObject o=a.optJSONObject(i); if(o==null) continue; if(o.optString("id").equals(run.id)){next.put(run.toJson());replaced=true;}else next.put(o);}
            if(!replaced) next.put(run.toJson());
            while(next.length()>60) { JSONArray trimmed=new JSONArray(); for(int i=next.length()-60;i<next.length();i++) trimmed.put(next.get(i)); next=trimmed; }
            cached.put("runs",next); cached.put("activeRunId", (RunRecord.RUNNING.equals(run.status)||RunRecord.PAUSED_LOCKED.equals(run.status)||RunRecord.PAUSED_EXTERNAL.equals(run.status)) ? run.id : ""); persist();
        } catch(JSONException e) { throw new IOException("Could not save run history.", e); }
    }
    public synchronized List<RunRecord> getRuns() {
        JSONArray a=cached.optJSONArray("runs"); ArrayList<RunRecord> out=new ArrayList<>();
        if(a!=null) for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null)out.add(RunRecord.fromJson(o));}
        out.sort((x,y)->Long.compare(y.startedAt,x.startedAt)); return out;
    }
    public synchronized void recoverInterruptedRuns() throws IOException {
        boolean changed=false;
        for(RunRecord run:getRuns()) if(RunRecord.RUNNING.equals(run.status)||RunRecord.PAUSED_LOCKED.equals(run.status)||RunRecord.PAUSED_EXTERNAL.equals(run.status)) {
            run.status=RunRecord.INTERRUPTED; run.finishedAt=System.currentTimeMillis(); run.addEvent("App process restarted; execution did not resume automatically."); saveRun(run); changed=true;
        }
        if(!changed && cached.optString("activeRunId", "").length()>0) { try { cached.put("activeRunId",""); persist(); } catch(JSONException e){ throw new IOException(e); } }
    }
    public synchronized String exportPlainJson() {
        try { return cached.toString(2); }
        catch (JSONException e) { return cached.toString(); }
    }

    public synchronized List<JobRecord> getJobs() {
        JSONArray a = cached.optJSONArray("jobs"); ArrayList<JobRecord> out = new ArrayList<>();
        if (a != null) for (int i=0;i<a.length();i++) { JSONObject o=a.optJSONObject(i); if (o != null) out.add(JobRecord.fromJson(o)); }
        out.sort((x,y) -> Long.compare(y.updatedAt, x.updatedAt)); return out;
    }
    public synchronized JobRecord getJob(String id) {
        for (JobRecord job : getJobs()) if (job.id.equals(id)) return job;
        return null;
    }
    public synchronized void saveJob(JobRecord job) throws IOException {
        job.updatedAt = System.currentTimeMillis(); JSONArray a = cached.optJSONArray("jobs"); if (a == null) a = new JSONArray();
        JSONArray next = new JSONArray(); boolean replaced = false;
        try {
            for (int i=0;i<a.length();i++) { JSONObject o=a.optJSONObject(i); if (o==null) continue;
                if (o.optString("id").equals(job.id)) { next.put(job.toJson()); replaced=true; } else next.put(o); }
            if (!replaced) next.put(job.toJson());
            while (next.length() > 80) { JSONArray trimmed = new JSONArray(); for (int i=next.length()-80;i<next.length();i++) trimmed.put(next.get(i)); next=trimmed; }
            cached.put("jobs", next); persist();
        } catch (JSONException e) { throw new IOException("Could not save local AI job.", e); }
    }
    public synchronized List<ChatMessage> getChatMessages() {
        JSONArray a = cached.optJSONArray("chatMessages"); ArrayList<ChatMessage> out = new ArrayList<>();
        if (a != null) for (int i=0;i<a.length();i++) { JSONObject o=a.optJSONObject(i); if (o != null) out.add(ChatMessage.fromJson(o)); }
        return out;
    }
    public synchronized void appendChatMessage(ChatMessage message) throws IOException {
        JSONArray a = cached.optJSONArray("chatMessages"); if (a == null) a = new JSONArray();
        JSONArray next = new JSONArray();
        try {
            for (int i=0;i<a.length();i++) { JSONObject o=a.optJSONObject(i); if (o!=null) next.put(o); }
            next.put(message.toJson());
            while (next.length() > 100) { JSONArray trimmed = new JSONArray(); for (int i=next.length()-100;i<next.length();i++) trimmed.put(next.get(i)); next=trimmed; }
            cached.put("chatMessages", next); persist();
        } catch (JSONException e) { throw new IOException("Could not save conversation message.", e); }
    }
    public synchronized void clearChatMessages() throws IOException {
        try { cached.put("chatMessages", new JSONArray()); persist(); } catch (JSONException e) { throw new IOException(e); }
    }


    public synchronized List<TaskRecord> getTasks() {
        JSONArray a = cached.optJSONArray("tasks"); ArrayList<TaskRecord> out = new ArrayList<>();
        if (a != null) for (int i=0;i<a.length();i++) { JSONObject o=a.optJSONObject(i); if (o != null) out.add(TaskRecord.fromJson(o)); }
        out.sort((x,y) -> Long.compare(y.updatedAt, x.updatedAt)); return out;
    }
    public synchronized void saveTask(TaskRecord task) throws IOException {
        task.updatedAt = System.currentTimeMillis(); JSONArray a = cached.optJSONArray("tasks"); if (a == null) a = new JSONArray();
        JSONArray next = new JSONArray(); boolean replaced = false;
        try {
            for (int i=0;i<a.length();i++) { JSONObject o=a.optJSONObject(i); if (o==null) continue;
                if (o.optString("id").equals(task.id)) { next.put(task.toJson()); replaced=true; } else next.put(o); }
            if (!replaced) next.put(task.toJson());
            while (next.length() > 100) { JSONArray trimmed = new JSONArray(); for (int i=next.length()-100;i<next.length();i++) trimmed.put(next.get(i)); next=trimmed; }
            cached.put("tasks", next); persist();
        } catch (JSONException e) { throw new IOException("Could not save task.", e); }
    }

    public synchronized List<AppCapability> getAppCapabilities() {
        JSONArray a = cached.optJSONArray("appCapabilities"); ArrayList<AppCapability> out = new ArrayList<>();
        if (a != null) for (int i=0;i<a.length();i++) { JSONObject o=a.optJSONObject(i); if (o != null) out.add(AppCapability.fromJson(o)); }
        out.sort((x,y) -> Long.compare(y.observedAt, x.observedAt)); return out;
    }
    public synchronized void saveAppCapability(AppCapability capability) throws IOException {
        JSONArray a = cached.optJSONArray("appCapabilities"); if (a == null) a = new JSONArray();
        JSONArray next = new JSONArray(); boolean replaced = false;
        try {
            for (int i=0;i<a.length();i++) {
                JSONObject o = a.optJSONObject(i); if (o == null) continue;
                boolean same = o.optString("packageName").equals(capability.packageName)
                        && o.optString("name").trim().equalsIgnoreCase(capability.name.trim());
                if (same) { capability.id = o.optString("id", capability.id); next.put(capability.toJson()); replaced=true; }
                else next.put(o);
            }
            if (!replaced) next.put(capability.toJson());
            while (next.length() > 120) { JSONArray trimmed = new JSONArray(); for (int i=next.length()-120;i<next.length();i++) trimmed.put(next.get(i)); next=trimmed; }
            cached.put("appCapabilities", next); persist();
        } catch (JSONException e) { throw new IOException("Could not save app capability evidence.", e); }
    }

    public synchronized void recoverInterruptedJobs() throws IOException {
        for (JobRecord job : getJobs()) {
            if (JobRecord.PREPARING.equals(job.state)) {
                job.state = JobRecord.REVIEW_REQUIRED;
                job.result = "The app process ended while the local model was working. This job was not replayed automatically. Review and submit it again if needed.";
                saveJob(job);
            }
        }
    }

    public synchronized boolean hasWorkflows() { JSONArray a=cached.optJSONArray("workflows"); return a!=null && a.length()>0; }
}
