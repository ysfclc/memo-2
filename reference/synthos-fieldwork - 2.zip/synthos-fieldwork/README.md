# SynthOS 3.1 — AI Chats, Frontier Workflows and Runtimes

SynthOS is a local-first Android workspace that connects AI conversations, applications, jobs and structured outcomes. It keeps the source conversation, resulting entities, relationships and job trace together, with an explicit boundary between native SynthOS workspaces and browser sessions.

## Main workspaces

### AI Chats

- Create, search, rename and revisit persistent conversations.
- Send prompts through a selected installed LiteRT-LM local model or an explicitly configured OpenAI-compatible HTTPS endpoint.
- Local model requests stay on device. Remote requests require a per-request consent toggle.
- Import pasted transcripts or use Android's Share action to bring text from another app into SynthOS.
- Imported conversation content is labelled as user-provided source material. The app does not claim direct access to private ChatGPT, Claude or other provider histories.
- Ask the selected model to extract outcome candidates from a conversation. Candidates are accepted only when the model supplies a verbatim source excerpt that matches the conversation (whitespace-normalized, case-insensitive). They remain proposals until the user approves them.

### Frontier browser workflows

- Local AI is the coordinator, not the domain expert: it structures the original intent, preserves constraints and maps outputs from frontier models.
- SynthOS can use selected frontier services through their actual websites inside the separate, visible browser runtime. It does not call a hidden provider API or bypass sign-in, account limits, challenges, or site restrictions.
- **Consult and compare** sends the original intent independently to each selected provider in turn, captures each answer, then uses the selected local model to compare agreements, disagreements, unsupported claims, evidence gaps and next actions.
- **Critique and refine** passes earlier captured answers into later provider prompts to create a visible debate/critique chain.
- Each captured provider response is stored as browser evidence and as a `FRONTIER_RESPONSE` entity, linked to the consultation. The local model may also propose typed project, task, decision, knowledge, person, organization or artifact entities. The app accepts those proposals only when each includes an exact excerpt found in the captured provider-response corpus; they remain in review state until the user approves them.
- Saved workflows retain their provider selection and interaction mode. One visible browser session is used and providers are visited one at a time; this is coordinated multi-chat execution, not hidden simultaneous browser sessions. Each provider step returns to its configured entry/new-chat route instead of reusing a page merely because its host matches, reducing the risk of appending a new task to an old consultation. Website UI changes can interrupt automation; SynthOS pauses for user intervention rather than claiming success or blindly resending a prompt.
- Provider websites may change their composer, Send controls or response markup. If SynthOS cannot safely identify an action or a stable answer, the user must take over and continue manually. Direct conversation history from a provider is accessible only to the extent the user is signed in and the website exposes it in that session.

### Work graph

The encrypted workspace persists typed entities, relationships and source references. Initial types include Conversation, Project, Task, Decision, Knowledge, Person, Organization and Artifact; additional types can be created. Entity IDs are stable, duplicate type/name pairs are rejected, and relationships are stored as first-class records. Proposed items can be approved or rejected, entities can be edited and linked, and approved same-type records can be merged. A merge redirects relationships while retaining the source record and its evidence in Archive.

The outcome extraction loop is implemented as a persisted job with visible steps: gather source context, ask the selected model for structured candidates, validate candidate evidence, and wait for human review. Failed parsing, unmatched evidence and duplicate proposals do not become successful entity creation. After approving a project or another work entity, the user can create a follow-up task from its detail view. SynthOS records a separate app-runtime job, creates a typed TASK entity, links it to the source and available conversation, and verifies the resulting workspace records.

### Runtime separation

SynthOS registers native workspaces (Chats, Work/Entities, Jobs, Models, Council and Settings) separately from the **Browser runtime**. The registry describes each runtime's capabilities and indicates operations that require user approval.

The browser runtime owns its WebView session, navigation, page inspection, bounded browser tasks and captured page evidence. Websites can be opened from quick links and used manually. Browser automation is limited to supported HTTPS page operations and does not provide native Android screen control.

The app runtime is the native SynthOS UI and its registered internal workspace capabilities. The first executable app-runtime workflow is a deterministic, source-linked follow-up task; it records each step and checks the resulting entities and relationships. The job workbench does not yet offer a general-purpose executor for arbitrary user-defined jobs, generic pause/resume, or automatic skill learning. This build does **not** virtualize arbitrary third-party APK interfaces. Other Android apps can share text into SynthOS through Android's share sheet. This build does not yet provide a general installed-app launcher or third-party UI automation; those need their own explicit integration and permission design.

### Council and local models

Five traceable multi-model patterns remain available: independent panel, sequential handoff, draft + critic, debate and specialist panel. Individual turns, failures, synthesis, source references and human-owned final decisions are retained.

Model weights are downloaded only on explicit request, stored in private app storage and never bundled in the APK. The build supports compatible `.litertlm` artifacts through Google's LiteRT-LM Android API; GGUF files and Ollama model directories are not directly supported.

Built-in model choices:

| Model | Approximate file size | Intended use |
|---|---:|---|
| Qwen3 0.6B INT8 | About 586 MB | Lightweight offline analysis and extraction |
| Gemma 4 E2B mixed quantized | About 2.6 GB | Higher-capability local option on compatible devices |

Peak runtime memory varies by device and backend. Download size does not guarantee that a model will fit in available RAM. The local runner tries the GPU backend and falls back to CPU when initialization or execution fails.

### Browser tasks and evidence

Existing bounded browser tasks remain available: capture page, extract links, find text, review a feed, and prepare a prompt. Preparing a prompt does not automatically send it. Tasks can require review or become blocked or failed; persisted tasks interrupted by a process restart need review before retrying. Captured evidence retains its source URL and timestamp.

## Privacy and persistence

- The core workspace is encrypted locally using AES-256-GCM with a key held by Android Keystore.
- Remote provider credentials are stored separately, encrypted with Android Keystore, and excluded from workspace backups.
- Remote requests require explicit per-request consent. The app does not make remote inference mandatory for data storage or browsing.
- Imported chat history is only as complete as the content the user supplies or a supported integration can actually access.
- JSON backup files contain readable workspace data. Choose a trusted destination and protect the exported file.
- There is no built-in analytics or product telemetry.

## Build

- JDK 17
- Android SDK platform 35 and build-tools 35.0.0
- Gradle 8.14.6
- Android Gradle Plugin 8.13.0
- Kotlin 2.4.0

Run from this directory:

```bash
./gradlew --no-daemon testDebugUnitTest lintDebug assembleDebug
```

The debug APK is expected at `app/build/outputs/apk/debug/app-debug.apk`.

The repository's GitHub Actions workflow is maintained separately and expects the root zip file to remain named **`synthos-fieldwork.zip`**, containing the `synthos-fieldwork/` directory at its root.

## Current scope and verification

Version 3.1 adds visible browser-backed frontier consultations, independent multi-provider comparison, critique chains, persistent provider-response entities, local output mapping and source-checked entity proposals. Version 3.0 added persistent AI chats, share/import, a typed entity/relationship store, durable job traces, a verified follow-up-task workflow, separate runtime capability descriptors, and Chats/Work navigation. Council, local models and existing browser tasks remain available.

This build does not claim universal app virtualization or universal automation across third-party applications. Local inference and browser behavior still require device testing. An Android Gradle build and lint/test run must pass in the project build environment before the APK is considered release-verified.
