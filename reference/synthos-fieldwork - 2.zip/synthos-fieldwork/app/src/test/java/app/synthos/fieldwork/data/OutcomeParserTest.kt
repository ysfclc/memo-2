package app.synthos.fieldwork.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class OutcomeParserTest {
    @Test fun onlySourceGroundedProposalsAreReturned() {
        val source = "We decided to launch the Polish store in November. Yusuf will compare three suppliers by Friday."
        val raw = """```json
          {"entities":[
            {"type":"PROJECT","title":"Polish store launch","description":"Launch plan","evidence":"launch the Polish store in November"},
            {"type":"TASK","title":"Compare suppliers","description":"Compare three suppliers","evidence":"compare three suppliers by Friday"},
            {"type":"PERSON","title":"Invented person","description":"No evidence","evidence":"Alice owns all operations in perpetuity"}
          ]}
        ```"""
        val result = OutcomeParser.parse(raw, source)
        assertEquals(2, result.size)
        assertTrue(result.all { it.evidence.isNotBlank() })
    }

    @Test fun invalidTypesAndDuplicateNamesAreIgnored() {
        val source = "Create an online store before December."
        val raw = """{"entities":[
          {"type":"EXECUTE_CODE","title":"Online store","evidence":"online store before December"},
          {"type":"PROJECT","title":"Online store","evidence":"online store before December"},
          {"type":"PROJECT","title":" online store ","evidence":"online store before December"}
        ]}"""
        assertEquals(1, OutcomeParser.parse(raw, source).size)
    }
}
