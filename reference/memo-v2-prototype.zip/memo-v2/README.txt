MEMO — CONCEPT RESET PROTOTYPE

Files
- index.html: conversational, mobile-responsive workspace prototype. Includes Conversation, Work, Browser, Memory, Sources and Models areas plus an interactive architecture contract inspector.
- explainer.html: self-contained 7-scene architecture walkthrough with autoplay, timeline, keyboard controls and reduced-motion fallback.

Run
Open index.html in a modern desktop or mobile browser. No build step, framework, network call or external asset is required. Local demo-created records are stored in this browser's localStorage.

What is interactive
- Send messages; simple local rules create tasks or entities and navigate to relevant workspace areas.
- Start, pause, resume, block and mark demo tasks complete.
- Toggle active context references.
- Navigate between simulated internal browser pages, capture them as local sources, or reference the page in chat.
- Add source excerpts and entities; inspect the memory graph.
- Run a simulated model-routing trace and inspect component contracts in the architecture modal.

Important limits
This is a design prototype, not a live Memo runtime. It does not connect to an Android app, installed Qwen/Llama model, browser profile, frontier-model website, local files, or remote worker. The Browser view deliberately does not navigate to external sites or claim to perform authenticated actions. Production source and architecture must still be reconciled with the authoritative release ZIP.
