# SynthOS 1.5.0 — Preserve sources, connect missions

**Keep the thread of work intact as you move between your context, AI models, apps and the real world.**

SynthOS is a private Android workspace for people who work across AI chats, browser pages, files and notes. A mission is the persistent unit: one goal, a deliberately selected context, local reasoning, specialist handoffs, returned work and the next useful decision.

The product direction is now deliberately **capture-first, with missions as durable continuity rather than the mandatory entry point**. The main workspace keeps three destinations—Work (capture and Inbox), Library and Settings. Collaboration is part of the mission itself rather than a separate Council mini-app.

## Shipped in this source snapshot

- **Capture-first home and review Inbox:** quick capture is the first action, new items are shown in Inbox, and an item can be opened for review/edit before being chosen as mission context.
- **Immutable original source:** editing a capture creates a working copy while retaining the first-captured text. The original appears in the editor once the working copy diverges, survives encrypted persistence and backup/restore, and is seeded from the best available content when older backups are imported.
- **Attach an existing source to a mission:** from any non-mission item’s editor, choose “Attach to mission”. The editor saves pending edits first; the selected source is linked into the mission’s durable context without duplicating the library record. Inbox sources move to Active, archived items cannot be linked, duplicate links are avoided, and each mission is capped at eight context sources.
- **Share-in for multiple files:** Android `ACTION_SEND` and `ACTION_SEND_MULTIPLE` accept text plus supported content URIs. Shared files are reviewed by filename/type/size and copied into the encrypted workspace only when the user saves. Limits are explicit: up to five files, 2 MB each and 6 MB total. Unsupported or expired streams fail without saving a partial record.
- **Attachment-aware backup schema v3:** attachment bytes and metadata round-trip with a backup, now alongside the preserved original source. Schema v1 and v2 backups remain readable; exports remain plaintext by design and carry the existing warning. Total backup/workspace JSON limit is 20 MB.
- **Persistent missions:** start and reopen a goal with durable Collaborate, Compete or Converge strategy; missions are optional continuity workspaces, not the only way to capture.
- **A local conversation inside each mission:** a replaceable on-device inference runtime using Google's LiteRT-LM Android Kotlin API. The app streams responses, restores a bounded conversation history, and supplies the mission goal, only selected context and linked specialist work as the model's instruction context.
- **One-tap local model installation:** Settings includes three ready-to-run LiteRT-LM downloads: Qwen3 0.6B INT4 (~329 MB), Qwen3 0.6B higher-precision (~586 MB), and Qwen3 1.7B INT4 (~977 MB). Tap **Download & use**; SynthOS downloads directly into private app storage, verifies that the transfer completed, then selects the model. A custom `.litertlm` import is still available. Model files are not bundled in the APK. Model size, latency, available RAM and device compatibility differ; larger models can require several GB of available memory. GGUF and MediaPipe `.task` files are not interchangeable with `.litertlm`.
- **Tracked external sessions:** create source-aware research, architecture and challenge briefs; SynthOS saves each handoff to the current mission before opening Android's system destination chooser. The chosen destination is recorded when Android reports the user's selection, and responses shared back to SynthOS can be attached to the same active mission. Imported chat transcripts can become resumable missions with their source conversation saved as context.
- **Return path:** share text or a URL back from a compatible app, review before saving, and link a model response to its mission. Local conversations and returned work are retained in encrypted storage and included in portable backups.
- **Durable context selection:** each mission remembers the exact library records selected for it. Removing a source clears its context links instead of leaving stale references.
- **Library and backups:** search, filter, edit and delete source records; export/import a versioned JSON backup. Exported JSON is plaintext by design and is preceded by a warning.
- **Privacy foundation:** AES-256-GCM encrypted workspace with a non-exportable Android Keystore key and device authentication; no analytics or ads SDK. Internet access is used for explicit one-tap model downloads only; inference is on-device and prompts are not sent to SynthOS servers. External sharing happens only after a user chooses a destination in Android's system chooser.
- **Professional native presentation:** warm paper / evergreen palette, light/dark/system themes, readable type, 48 dp target convention, restrained Compose transitions and honest loading/error states.

## What is real—and what is not yet connected

The local model is real runtime integration, but actual generation must be validated on a target phone. SynthOS does not bundle model weights; it offers explicit one-tap downloads and an import path for compatible files. It never downloads weights without a user action. The first local response can take several seconds while the model initializes; inference speed and memory requirements depend on the model and the device.

External models are **not** automatically called in parallel yet. SynthOS saves source-aware briefs as tracked session records, then opens Android's system destination chooser; the user chooses ChatGPT, Claude, Gemini or another app, runs the work there, then shares the result back to the originating mission. The local model can use the saved transcript and returned results when it next answers. An optional, user-enabled floating capture bubble brings copied text from another app into SynthOS for review; it never saves clipboard text without the user choosing Save or Make a mission. API-based concurrent execution, provider-specific browser automation and automated debate rounds are future work—not hidden or simulated integrations.

SynthOS cannot silently read private histories from arbitrary apps, control every native app, bypass CAPTCHA, or inspect unrestricted browser tabs. The reliable foundation is Android share-in/share-out plus the visible app workspace. The optional floating capture bubble needs the user to grant display-over-other-apps permission (and notification permission on Android 13+) and shows an ongoing notification; no broad Accessibility Service is used.

## Core loop

1. **State the goal.** Start a mission that remains in the encrypted workspace.
2. **Choose the working style.** Collaborate splits the work across roles; Compete asks for independent proposals; Converge asks for challenge and reconciliation without manufactured agreement.
3. **Select context.** Choose up to eight saved records. This selection is stored with the mission and is the only library material added to a handoff or local context packet.
4. **Talk to SynthOS locally.** Once a compatible `.litertlm` file is imported, the on-device model can help compare evidence, critique assumptions and plan the next move without sending the conversation to a cloud provider.
5. **Branch out.** Generate a role-specific brief and share it to an AI app. The UI never says that an external provider is running unless the user actually invoked it.
6. **Bring results back.** Share the response to SynthOS, review it and save it linked to the mission.
7. **Continue.** The local assistant sees selected sources and linked returned work; the mission retains the goal, its strategy and context across sessions.

## Architecture choices

- **Native stack:** Kotlin, Jetpack Compose, Material 3 and Android Storage Access Framework. No web shell for the core experience.
- **Local inference:** `com.google.ai.edge.litertlm:litertlm-android:0.18.0`, CPU backend initially, with native generation/lifecycle serialized on a dedicated background dispatcher. The runtime is a replaceable boundary, not the product identity.
- **Storage:** encrypted local records with explicit `relatedToId`, `missionMode` and `contextIds` fields, plus immutable `originalContent`; original captures remain distinct from derived AI responses.
- **Context compilation:** deterministic, bounded composition with source labels, optional URL, selected source excerpts and explicit uncertainty rules. It never grants the model network or other-app access.
- **Motion:** fast, functional transitions that communicate state changes; no decorative “AI is working” simulation.

## Build and release

The source archive is `synthos-pocket.zip` with a top-level `synthos-pocket/` directory. Keep it at the repository root alongside `build-synthos.yml`. The existing GitHub Actions workflow provisions JDK 17, Android SDK Platform 35 and Gradle 8.13, then runs:

```bash
gradle --no-daemon testDebugUnitTest lintDebug assembleDebug
```

It uploads the APK under the established artifact name **`synthos-pocket-debug-apk`** for 14 days. The build is not reported as passing until that workflow completes successfully. In the current editing runtime, no Android SDK is installed and build downloads are unavailable; the source archive can be verified here, but Android compilation and device inference remain CI/device checks.

## Before relying on this build

- Run the GitHub Actions workflow and inspect the actual build result.
- On the target phone, import a known-compatible small `.litertlm` model and verify the first reply, streaming, second-turn history, switching missions, locking during generation and removing/replacing the model.
- Benchmark memory, startup latency, generation latency, heat and battery. Do not infer acceptable performance from the model file extension alone.
- Run the share-in/share-out loop with at least two AI apps and confirm each response lands in the intended mission.
- Test biometric/Keystore behavior, backup recovery, TalkBack, increased font sizes, low storage and small-screen layout.

See [Product direction](docs/PRODUCT_DIRECTION.md), [Design and motion](docs/DESIGN_MOTION.md) and [QA](docs/QA.md). The source ZIP is not a prebuilt or signed release APK.
