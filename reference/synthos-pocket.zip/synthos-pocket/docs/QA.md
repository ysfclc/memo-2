# Release QA checklist

## Automated checks — GitHub Actions

The existing root workflow runs `testDebugUnitTest`, `lintDebug` and `assembleDebug`, then uploads `synthos-pocket-debug-apk`. A run is the source of truth for Android compilation. These commands have not been reported as passing in the current editing runtime because the Android SDK is absent and dependencies cannot be downloaded here.

Unit tests cover prompt composition, independent/convergence role rules, selected-context bounds, backup compatibility, mission links/context IDs, local chat history/context assembly, and attachment payload/size validation. The attachment importer is capped at five files, 2 MB each, and 6 MB total.

## Local model and mission checks (physical Android device required)

1. Install the debug APK over the previous debug build. Verify the encrypted workspace remains available.
2. Start a mission, choose a mode and select two sources. Leave the screen, reopen the mission and verify goal, mode and selected sources persist.
3. In Settings, import a known-compatible small `.litertlm` model. Reject unrelated extensions; cancel the picker; try an unreadable or malformed model file. A failed import must not delete a previously working model.
4. Ask a local question. Verify initialization happens off the main thread, genuine tokens stream, the question is persisted before inference, and a completed answer is persisted with the correct mission link.
5. Send a second turn. Verify the bounded previous user/assistant turns are restored in chronological order and no duplicate turns appear.
6. Switch tabs and return while generation is running. Verify the result is either visibly still in progress or saved and surfaced, never duplicated or presented as completed before the model finishes.
7. Lock the workspace during generation. Verify generation cancellation, engine/conversation teardown, and clearing of sensitive in-memory captures. Re-unlock; ensure the question is retained and no partial answer is mislabelled as complete.
8. Replace the model while idle. Confirm the old engine closes before replacement. Test a failed replacement and verify the prior model remains usable.
9. Remove the local model. Confirm mission history, local chat turns and captured sources remain. Restart the app and confirm the setup state is correct.
10. Benchmark first-load latency, sustained token speed, memory use, heat and battery for the chosen device/model. Try a model too large for available RAM and verify the failure is clear and recoverable.

## Handoffs and return loop

11. Share a URL or text from a browser to SynthOS. Inspect/edit the incoming capture, then save or make a mission. Restart and find the source in Inbox/Library.
12. Share one image, one PDF and multiple small files using Android Sharesheet. Verify the filename, MIME type and reported size appear before saving, then confirm the byte payload and metadata survive process restart and backup/restore. Try an oversized stream and an expired/unreadable URI; no partial capture should be committed.
13. Share more than five files at once and confirm the UI explicitly states that additional files were omitted. Share the remaining files separately.
14. Open an existing mission, prepare a Researcher/Architect/Challenger brief, inspect it and share to an installed AI app. Confirm the brief contains only selected records and explicit source labels.
15. Run the external prompt manually. Share its answer back to SynthOS and save it linked to the originating mission. Confirm a later local conversation can refer to the linked result.
16. For Compete, get independent answers without exposing the other answer first. For Converge, check the prompt preserves unresolved objections instead of demanding consensus.
17. Try a long shared message and plain URL; handle absent MIME metadata and cancellation without crash.

## Storage and accessibility

18. Export a backup and inspect the warning that JSON is plaintext, including saved attachment bytes. Restore into a separate instance and verify parent links, mode and selected context survive. Legacy schema-v1 records with missing attachment fields should still decode.
19. Delete a selected source and verify it is removed from mission context without clearing other records.
20. Check storage-full/read-write errors: never report success when persistence fails, and don't replace a readable workspace after a failed decrypt/read.
21. Verify biometric/device authentication, lock/unlock and process recreation on supported phones.
22. Check light/dark/system themes, narrow screen, large system font, TalkBack focus order and labels, 48 dp target convention, keyboard resize and scrolling with the IME open.

## Known verification gap

The deliverable is a source ZIP plus the existing build workflow, not a built or signed release APK. No emulator or physical device was available in this runtime. CI compilation and all native LiteRT-LM model inference, latency, thermal, accessibility and lifecycle checks must still be completed before relying on this build.


## Model downloads and external session continuity

23. In Settings, start the smallest Qwen3 model download. Confirm progress updates, that the installed model is selected automatically, and that canceling another download removes its partial file without removing installed models.
24. Download another catalog model and switch between installed models. Confirm files are retained independently. Test offline local inference after a model has been downloaded.
25. From a mission, start an external session. Confirm the session brief is saved before Android's destination chooser opens. Select an app, return to SynthOS, and confirm the chosen destination label is attached to that session.
26. Share an existing chat transcript from another app into SynthOS and select Make a mission. Confirm the original transcript remains saved and selected as mission context after restarting the app. Share a reply back while that mission is active and confirm it is linked to that mission.
27. Enable the floating capture bubble, grant Android's overlay permission and, on Android 13+, notification permission; confirm it remains available with a visible ongoing notification. Copy text in another app, tap the bubble, review the text, and verify it is not saved unless the user chooses an explicit save action. Stop the bubble from the notification and confirm it stays off after returning to SynthOS.

## SynthOS 1.5.0 regression checks

- Edit a newly captured item, save it, reopen it and confirm the original-source block is visible while the working copy contains the edited text.
- Export and re-import a backup containing edited content; confirm original and working copy remain distinct.
- Import schema v1 and v2 backups without an `originalContent` field; confirm the available content is preserved as the best recoverable original.
- From a non-mission item, choose **Attach to mission**. Confirm the current editor draft is saved before the picker opens, choosing a mission adds the existing source to its context, and the source is not duplicated in the library.
- Confirm an Inbox source becomes Active after linking, an already-linked source is not duplicated, archived sources/missions are rejected, and a mission with eight selected sources rejects a ninth.
- Run `testDebugUnitTest`, `lintDebug` and `assembleDebug` using the unchanged GitHub Actions workflow; install the uploaded APK and verify the visible version is 1.5.0-debug.

