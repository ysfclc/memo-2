# Design and motion system

## Direction

Quiet editorial utility: warm paper/off-white surfaces, deep evergreen action color, restrained cool secondary tone, minimal borders, and a clear typographic hierarchy. It should feel like a serious working instrument, not an AI marketplace or a gaming dashboard. No neon gradients, decorative data visualizations, or fake agent activity.

## Information architecture

Three destinations only: **Work, Library, Settings**.

- **Work:** goal composer, recent missions and recently captured material. Android share-in arrives as a review surface, never an automatic save.
- **Mission room:** the working thread: goal, durable strategy, explicitly selected context, the local SynthOS chat, specialist handoffs and linked returned work. Council behavior is inside the mission, not a separate destination.
- **Library:** source of truth for captures; search, inspect, edit, delete and reuse in context.
- **Settings:** workspace security/privacy explanation, on-device model import/removal, themes and backup/restore.

## Tokens

| Token | Light | Dark | Purpose |
|---|---|---|---|
| Primary | `#315B45` | `#BED8C4` | Primary actions and selected state |
| Primary container | `#D7E8D9` | `#2E5140` | Mission context and focused surfaces |
| Secondary | `#4E6578` | `#BED0E0` | Supporting information |
| Accent | `#984A27` | `#FFB596` | Rare emphasis, not decoration |
| Background | `#F6F7F2` | `#121914` | App canvas |
| Surface | `#FFFEFA` | `#1A231C` | Cards and dialogs |
| Main text | `#19211B` | `#E5EDE6` | Body and headings |
| Secondary text | `#414A42` | `#CBD5CC` | Secondary text |

Typography uses Android system sans with SP units: 32/28/24/21sp display/headline steps; 19/16/14sp titles; 16/14/12sp body; 14/12/11sp labels. Line heights are configured in `SynthOsTheme.kt`. Spacing follows a 4 dp base with 8, 12, 16, 20, 24 and 30 dp rhythm. Main content uses 20 dp horizontal margins. Interactive controls target at least 48 dp where appropriate.

## Component rules

- One dominant action per surface. Secondary actions use outlined buttons/text buttons.
- Selections use both a visual state and readable label; status is never communicated only by color.
- Prefer outcome labels: “Start mission”, “Prepare handoff”, “Ask SynthOS locally”, “Save and link to mission”.
- Context disclosure is explicit and countable before external handoff or local inference.
- Model setup says when local inference is not available; a file's presence is not represented as a successful model load.
- Loading and error states must correspond to actual work or a real failure.
- Icon-only actions need meaningful content descriptions. Text remains system-scalable.

## Motion system

- **Destination transition:** 180 ms crossfade. It communicates a surface change without cinematic page turns.
- **Mission content expansion:** 180 ms animated size change, keeping context and strategy changes legible.
- **Incoming shared item:** 180 ms fade plus a small vertical offset (about one twelfth of the surface height) to acknowledge the user-triggered capture.
- **Local inference:** show a progress indicator only while model initialization or generation is genuinely active. Stream model output as it arrives; never animate a fake response. Errors remain visible and retryable.
- **Handoff:** use Android's native Sharesheet transition. SynthOS must not impersonate an external provider or imply that it is still running after handing the prompt off.
- **Easing:** Compose fast-out/slow-in default timing for content transitions. Avoid looping idle motion.
- **Haptics:** no custom haptics in this snapshot; follow Android system behavior. Consider a light confirmation tick only after a real persisted mission and device verification.
- **Reduced motion:** Compose transitions should honor Android animator-duration scale. No custom perpetual animation is required to understand state.

## Accessibility and performance

Use Material 3 semantics, TalkBack labels, a 48 dp target convention, SP typography and adaptive wrapping. Avoid baked text images. Bound local input/history/context packets to control memory; initialize/run/teardown native inference on a dedicated background dispatcher. No remote images, background polling or internet permission. Real-device checks are required for low-memory model failures, keyboard resize, TalkBack order, dynamic font sizing, model load performance and thermal behavior.
