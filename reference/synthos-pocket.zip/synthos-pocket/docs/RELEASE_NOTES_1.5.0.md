# SynthOS 1.5.0

This release addresses two gaps in the capture-to-mission workflow.

## Original capture and working copy

Every new capture records its initial text in `originalContent`. Editing affects `content`, while `CaptureEditingPolicy` retains the original text, source label/URL, creation timestamp, selected-context links and saved attachments from the persisted record. After a content edit is saved, the item editor shows the original text separately from the working copy. This applies to encrypted workspace persistence and schema-v3 backups.

Legacy schema-v1/v2 backups do not contain the extra field. During import, the current saved content is used as the only available original; prior revisions that were already overwritten cannot be reconstructed.

## Attach existing source to mission

The item editor has an **Attach to mission** action for non-mission records. Pending title/content/type/status edits are saved before the mission picker opens. Selecting a mission links the existing source ID into its selected context rather than duplicating the source. An Inbox source transitions to Active. Duplicate links are idempotent; archived source/mission records, self-links and a ninth context source are rejected. The relationship decision is pure Kotlin and covered by unit tests; workspace persistence writes the resulting item list in one save.

## Compatibility and verification

- Android version: 1.5.0 (`versionCode` 6).
- Backup schema: v3; reads schema v1 and v2.
- GitHub Actions workflow contract remains unchanged: root file `synthos-pocket.zip`, top-level extracted directory `synthos-pocket/`, Gradle task sequence `testDebugUnitTest lintDebug assembleDebug`, artifact `synthos-pocket-debug-apk`.
- The source archive structure and checksum are verified when packaged.
- A local Gradle test run was attempted but could not start because this runtime cannot resolve `services.gradle.org`; there is no Android SDK in this runtime. Therefore, Android compilation/lint/APK generation and device behavior are **not yet verified**. Run the existing GitHub Actions workflow against this exact ZIP before installing it.
