# Gson reads and writes the explicit Capture schema through CaptureCodec.
# Keep model fields stable in minified builds so exported backups remain compatible.
-keep class app.synthos.pocket.data.Capture { *; }
-keepclassmembers class app.synthos.pocket.data.Capture { <fields>; }
-keepattributes Signature
