package app.synthos.pocket.data

import java.util.UUID

/** A user-owned piece of work captured with its provenance. */
data class Capture(
    val id: String,
    val title: String,
    val content: String,
    val kind: CaptureKind,
    val status: CaptureStatus,
    val sourceLabel: String,
    val sourceUrl: String?,
    val createdAt: Long,
    val updatedAt: Long,
    /** Stable relationship to a parent mission/source; null for standalone captures. */
    val relatedToId: String? = null,
    /** Collaboration strategy for mission records; optional for legacy captures. */
    val missionMode: String? = null,
    /** Selected library record IDs that form durable context for a mission. */
    val contextIds: List<String> = emptyList(),
    /** Small, bounded share-in files copied into the encrypted record; empty for text-only captures. */
    val attachments: List<CaptureAttachment> = emptyList(),
    /** Immutable first-captured text; edits change content but never this original source. */
    val originalContent: String? = null
)

enum class CaptureKind(val label: String) {
    IDEA("Idea"), RESEARCH("Research"), TASK("Task"), REFERENCE("Reference"), DECISION("Decision");

    companion object {
        fun fromStored(value: String): CaptureKind = entries.firstOrNull { it.name == value }
            ?: throw IllegalArgumentException("The backup contains an unknown capture type.")
    }
}

enum class CaptureStatus(val label: String) {
    INBOX("Inbox"), ACTIVE("Active"), DONE("Done"), ARCHIVED("Archived");

    companion object {
        fun fromStored(value: String): CaptureStatus = entries.firstOrNull { it.name == value }
            ?: throw IllegalArgumentException("The backup contains an unknown item status.")
    }
}

/** Pure edit policy, separated so source/provenance preservation can be regression-tested. */
object CaptureEditingPolicy {
    fun prepare(existing: Capture, draft: Capture, nowMillis: Long): Capture {
        val nextTimestamp = if (existing.updatedAt < Long.MAX_VALUE) existing.updatedAt + 1L else existing.updatedAt
        return existing.copy(
            title = draft.title.trim().take(CaptureFactory.MAX_TITLE_LENGTH),
            content = draft.content.trim().take(CaptureFactory.MAX_CONTENT_LENGTH),
            kind = draft.kind,
            status = draft.status,
            // Preserve identity and provenance fields from the stored record, not an editor draft.
            sourceLabel = existing.sourceLabel,
            sourceUrl = existing.sourceUrl,
            createdAt = existing.createdAt,
            updatedAt = maxOf(nowMillis, existing.createdAt, nextTimestamp),
            relatedToId = existing.relatedToId,
            missionMode = existing.missionMode,
            contextIds = existing.contextIds,
            attachments = existing.attachments,
            originalContent = existing.originalContent ?: existing.content
        )
    }
}

object CaptureFactory {
    const val MAX_TITLE_LENGTH = 180
    const val MAX_CONTENT_LENGTH = 50_000
    private val urlPattern = Regex("https?://[^\\s<>\\\"']+", RegexOption.IGNORE_CASE)

    fun create(content: String, kind: CaptureKind, sourceLabel: String = "Quick capture"): Capture {
        val cleanContent = content.trim().take(MAX_CONTENT_LENGTH)
        require(cleanContent.isNotEmpty()) { "Add a note or share some text first." }
        val firstLine = cleanContent.lineSequence().firstOrNull { it.isNotBlank() }.orEmpty()
        val title = firstLine.replace(Regex("\\s+"), " ").take(MAX_TITLE_LENGTH).ifBlank { "Untitled capture" }
        val now = System.currentTimeMillis().coerceAtLeast(1L)
        return Capture(
            id = UUID.randomUUID().toString(),
            title = title,
            content = cleanContent,
            kind = kind,
            status = CaptureStatus.INBOX,
            sourceLabel = sourceLabel.take(120).ifBlank { "Quick capture" },
            sourceUrl = urlPattern.find(cleanContent)?.value?.trimEnd('.', ',', ')', ']', ';')?.takeIf {
                it.length <= 2048 && (it.startsWith("https://", ignoreCase = true) || it.startsWith("http://", ignoreCase = true))
            },
            createdAt = now,
            updatedAt = now,
            originalContent = cleanContent
        )
    }
}
