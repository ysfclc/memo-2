package app.synthos.pocket.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** AES-256-GCM encrypted-at-rest store backed by a non-exportable Android Keystore key. */
class SecureStore(context: Context) {
    private val appContext = context.applicationContext
    private val dataFile = File(appContext.filesDir, "synthos-v1.enc")
    private val alias = "synthos_workspace_aes256_v1"
    private val magic = byteArrayOf(0x53, 0x59, 0x4e, 0x31) // SYN1
    private val ivLength = 12

    @Synchronized
    fun load(): List<Capture> {
        if (!dataFile.exists()) return emptyList()
        val length = dataFile.length()
        require(length in (magic.size + ivLength + 16).toLong()..(CaptureCodec.MAX_BACKUP_BYTES + 64).toLong()) {
            "The encrypted workspace file has an invalid size. Your original file was left untouched."
        }
        val bytes = FileInputStream(dataFile).use { it.readBytes() }
        require(bytes.copyOfRange(0, magic.size).contentEquals(magic)) {
            "The workspace format is not recognized. Your original file was left untouched."
        }
        val iv = bytes.copyOfRange(magic.size, magic.size + ivLength)
        val encrypted = bytes.copyOfRange(magic.size + ivLength, bytes.size)
        val key = getExistingKey()
            ?: throw IllegalStateException("The encryption key is missing. The saved workspace was left untouched; restore from a backup if available.")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        val cleartext = try { cipher.doFinal(encrypted) } catch (_: Exception) {
            throw IllegalStateException("The workspace could not be decrypted. Data was not changed.")
        }
        return CaptureCodec.decode(String(cleartext, Charsets.UTF_8))
    }

    @Synchronized
    fun save(items: List<Capture>) {
        val cleartext = CaptureCodec.encode(items).toByteArray(Charsets.UTF_8)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val iv = cipher.iv
        require(iv.size == ivLength) { "The secure storage provider returned an unexpected IV length." }
        val encrypted = cipher.doFinal(cleartext)
        val output = magic + iv + encrypted
        val temporary = File(appContext.filesDir, "synthos-v1.enc.tmp")
        try {
            FileOutputStream(temporary).use { stream ->
                stream.write(output)
                stream.fd.sync()
            }
            Files.move(temporary.toPath(), dataFile.toPath(), StandardCopyOption.REPLACE_EXISTING)
        } finally {
            if (temporary.exists()) temporary.delete()
        }
    }

    private fun getExistingKey(): SecretKey? {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        return keyStore.getKey(alias, null) as? SecretKey
    }

    private fun getOrCreateKey(): SecretKey {
        getExistingKey()?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                alias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setKeySize(256)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }
}
