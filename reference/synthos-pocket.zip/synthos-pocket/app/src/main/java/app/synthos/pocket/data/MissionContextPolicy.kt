package app.synthos.pocket.data

/** Result of a mission/source relationship decision. A null item list means the request was rejected. */
data class MissionAttachDecision(
    val updatedItems: List<Capture>?,
    val message: String? = null
) {
    val accepted: Boolean get() = updatedItems != null
}

/** Pure relationship rules shared by the workspace mutation and unit tests. */
object MissionContextPolicy {
    const val MAX_CONTEXT_SOURCES = 8
    const val MISSION_SOURCE_LABEL = "SynthOS mission"

    fun attach(items: List<Capture>, sourceId: String, missionId: String, nowMillis: Long): MissionAttachDecision {
        if (sourceId == missionId) {
            return MissionAttachDecision(null, "A mission cannot use itself as a source.")
        }
        val source = items.firstOrNull { it.id == sourceId }
        val mission = items.firstOrNull { it.id == missionId && it.sourceLabel == MISSION_SOURCE_LABEL }
        if (source == null || mission == null || source.status == CaptureStatus.ARCHIVED ||
            mission.status == CaptureStatus.ARCHIVED || source.sourceLabel == MISSION_SOURCE_LABEL
        ) {
            return MissionAttachDecision(null, "The source or mission is no longer available. Refresh and try again.")
        }
        if (sourceId in mission.contextIds) return MissionAttachDecision(items)
        if (mission.contextIds.size >= MAX_CONTEXT_SOURCES) {
            return MissionAttachDecision(null, "This mission already has 8 selected sources. Remove one before attaching another.")
        }

        val nextTimestamp = maxOf(nowMillis, nextTimestamp(mission.updatedAt), nextTimestamp(source.updatedAt))
        val updatedMission = mission.copy(contextIds = mission.contextIds + sourceId, updatedAt = nextTimestamp)
        val updatedSource = if (source.status == CaptureStatus.INBOX) {
            source.copy(status = CaptureStatus.ACTIVE, updatedAt = nextTimestamp)
        } else source
        val updatedItems = items.map { item ->
            when (item.id) {
                mission.id -> updatedMission
                source.id -> updatedSource
                else -> item
            }
        }.sortedByDescending { it.updatedAt }
        return MissionAttachDecision(updatedItems)
    }

    private fun nextTimestamp(value: Long): Long = if (value < Long.MAX_VALUE) value + 1L else value
}
