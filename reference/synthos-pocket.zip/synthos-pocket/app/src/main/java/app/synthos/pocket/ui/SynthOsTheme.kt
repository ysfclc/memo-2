package app.synthos.pocket.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** A single, centralized theme. Screens use MaterialTheme tokens; no local color palette is allowed. */
enum class ThemeMode(val label: String) {
    SYSTEM("System"), LIGHT("Light"), DARK("Dark");

    companion object {
        fun parse(value: String?): ThemeMode = entries.firstOrNull { it.name == value } ?: SYSTEM
    }
}

object SynthSemantic {
    val successLight = Color(0xFF2D6A4F)
    val warningLight = Color(0xFF805D16)
    val infoLight = Color(0xFF345F82)
    val successDark = Color(0xFFB1DCC4)
    val warningDark = Color(0xFFE8C477)
    val infoDark = Color(0xFFB7D7F0)
}

private val LightColors = lightColorScheme(
    primary = Color(0xFF315B45), onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFD7E8D9), onPrimaryContainer = Color(0xFF173B28),
    secondary = Color(0xFF4E6578), onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFD8E5F0), onSecondaryContainer = Color(0xFF1C3445),
    tertiary = Color(0xFF984A27), onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFFFDCCB), onTertiaryContainer = Color(0xFF62250A),
    background = Color(0xFFF6F7F2), onBackground = Color(0xFF19211B),
    surface = Color(0xFFFFFEFA), onSurface = Color(0xFF19211B),
    surfaceVariant = Color(0xFFE7EAE2), onSurfaceVariant = Color(0xFF414A42),
    outline = Color(0xFF747E75), outlineVariant = Color(0xFFC5CDC4),
    error = Color(0xFFBA1A1A), onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFFFDAD6), onErrorContainer = Color(0xFF410002),
    surfaceTint = Color(0xFF315B45)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFBED8C4), onPrimary = Color(0xFF183B28),
    primaryContainer = Color(0xFF2E5140), onPrimaryContainer = Color(0xFFD7E8D9),
    secondary = Color(0xFFBED0E0), onSecondary = Color(0xFF243746),
    secondaryContainer = Color(0xFF3B5264), onSecondaryContainer = Color(0xFFD8E5F0),
    tertiary = Color(0xFFFFB596), onTertiary = Color(0xFF61250A),
    tertiaryContainer = Color(0xFF7D3517), onTertiaryContainer = Color(0xFFFFDCCB),
    background = Color(0xFF121914), onBackground = Color(0xFFE5EDE6),
    surface = Color(0xFF1A231C), onSurface = Color(0xFFE5EDE6),
    surfaceVariant = Color(0xFF303A32), onSurfaceVariant = Color(0xFFCBD5CC),
    outline = Color(0xFF8B978D), outlineVariant = Color(0xFF424D44),
    error = Color(0xFFFFB4AB), onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A), onErrorContainer = Color(0xFFFFDAD6),
    surfaceTint = Color(0xFFBED8C4)
)

private val SynthTypography = Typography(
    displayLarge = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Bold, fontSize = 32.sp, lineHeight = 38.sp),
    headlineLarge = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 34.sp),
    headlineMedium = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.SemiBold, fontSize = 24.sp, lineHeight = 30.sp),
    headlineSmall = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.SemiBold, fontSize = 21.sp, lineHeight = 27.sp),
    titleLarge = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.SemiBold, fontSize = 19.sp, lineHeight = 25.sp),
    titleMedium = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp),
    titleSmall = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 20.sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 17.sp),
    labelLarge = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 20.sp),
    labelMedium = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp),
    labelSmall = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 15.sp)
)

private val SynthShapes = Shapes(
    extraSmall = androidx.compose.foundation.shape.RoundedCornerShape(8.dp),
    small = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
    medium = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
    large = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
    extraLarge = androidx.compose.foundation.shape.RoundedCornerShape(30.dp)
)

@Composable
fun SynthOsTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = SynthTypography,
        shapes = SynthShapes,
        content = content
    )
}
