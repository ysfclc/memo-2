package app.synthos.pocket.data

import com.google.gson.GsonBuilder
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import java.util.Base64

/** Versioned backup format. Strict validation avoids silently importing malformed data. */
object CaptureCodec {
    const val SCHEMA_VERSION = 3
    const val MAX_BACKUP_BYTES = 20 * 1024 * 1024
    const val MAX_ITEMS = 10_000
    private val gson = GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create()

    fun encode(items: List<Capture>): String {
        require(items.size <= MAX_ITEMS) { "This workspace is too large to export." }
        items.forEach { item ->
            require(item.id.isNotBlank() && item.id.length <= 100) { "An item ID is invalid." }
            require(item.title.isNotBlank() && item.title.length <= CaptureFactory.MAX_TITLE_LENGTH) { "An item title is invalid." }
            require(item.content.isNotBlank() && item.content.length <= CaptureFactory.MAX_CONTENT_LENGTH) { "An item's content is invalid." }
            require(item.originalContent == null || (item.originalContent.isNotBlank() && item.originalContent.length <= CaptureFactory.MAX_CONTENT_LENGTH)) { "An item's original source is invalid." }
            require(item.sourceLabel.length <= 120) { "An item's source label is too long." }
            require(item.relatedToId == null || item.relatedToId.length in 1..100) { "An item's related record ID is invalid." }
            require(item.missionMode == null || item.missionMode.length <= 30) { "An item's mission mode is invalid." }
            require(item.contextIds.size <= 8 && item.contextIds.all { it.length in 1..100 }) { "An item's context links are invalid." }
            validateAttachments(item.attachments)
            require(item.sourceUrl == null || (item.sourceUrl.length <= 2048 && (item.sourceUrl.startsWith("https://", true) || item.sourceUrl.startsWith("http://", true)))) {
                "An item's source URL is invalid."
            }
            require(item.createdAt > 0L && item.updatedAt >= item.createdAt) { "An item's timestamps are invalid." }
        }
        // Estimate encoded size before Gson allocates the complete backup; account for JSON escaping.
        val estimatedBytes = items.sumOf { item ->
            estimateJsonStringBytes(item.content) + estimateJsonStringBytes(item.originalContent.orEmpty()) + estimateJsonStringBytes(item.title) +
                estimateJsonStringBytes(item.sourceLabel) + estimateJsonStringBytes(item.sourceUrl.orEmpty()) +
                item.contextIds.sumOf { estimateJsonStringBytes(it) } +
                item.attachments.sumOf { estimateJsonStringBytes(it.fileName) + estimateJsonStringBytes(it.mimeType) + estimateJsonStringBytes(it.dataBase64) + 160L } + 256L
        }
        require(estimatedBytes <= MAX_BACKUP_BYTES.toLong()) { "The backup would exceed the 20 MB limit. Archive or remove older items before exporting." }
        val root = JsonObject().apply {
            addProperty("format", "synthos-backup")
            addProperty("schemaVersion", SCHEMA_VERSION)
            addProperty("exportedAt", System.currentTimeMillis())
            add("items", JsonArray().also { array -> items.forEach { array.add(toJson(it)) } })
        }
        val result = gson.toJson(root)
        require(result.toByteArray(Charsets.UTF_8).size <= MAX_BACKUP_BYTES) { "The backup exceeds the 20 MB limit." }
        return result
    }

    fun decode(text: String): List<Capture> {
        require(text.toByteArray(Charsets.UTF_8).size <= MAX_BACKUP_BYTES) { "The backup exceeds the 20 MB limit." }
        val root = try { JsonParser.parseString(text).asJsonObject } catch (_: Exception) {
            throw IllegalArgumentException("This file is not a valid SynthOS backup.")
        }
        require(root.stringOrNull("format") == "synthos-backup") { "This file is not a SynthOS backup." }
        val schemaVersion = root.intOrNull("schemaVersion")
        require(schemaVersion != null && schemaVersion in 1..SCHEMA_VERSION) { "This backup version is not supported." }
        val array = root.get("items")
        require(array != null && array.isJsonArray) { "The backup has no item list." }
        require(array.asJsonArray.size() <= MAX_ITEMS) { "The backup contains too many items." }

        val ids = HashSet<String>()
        return array.asJsonArray.map { element ->
            require(element.isJsonObject) { "The backup contains an invalid item." }
            val obj = element.asJsonObject
            val id = obj.stringOrNull("id")?.trim().orEmpty()
            val title = obj.stringOrNull("title")?.trim().orEmpty()
            val content = obj.stringOrNull("content").orEmpty()
            // v1/v2 backups do not contain originalContent; their current content is the best recoverable original.
            val originalContent = obj.stringOrNull("originalContent") ?: content
            val sourceLabel = obj.stringOrNull("sourceLabel")?.trim().orEmpty()
            val sourceUrl = obj.stringOrNull("sourceUrl")?.trim()?.takeIf { it.isNotEmpty() }
            val kind = CaptureKind.fromStored(obj.stringOrNull("kind").orEmpty())
            val status = CaptureStatus.fromStored(obj.stringOrNull("status").orEmpty())
            val createdAt = obj.longOrNull("createdAt") ?: 0L
            val updatedAt = obj.longOrNull("updatedAt") ?: 0L
            val relatedToId = obj.stringOrNull("relatedToId")?.trim()?.takeIf { it.isNotEmpty() }
            val missionMode = obj.stringOrNull("missionMode")?.trim()?.takeIf { it.isNotEmpty() }
            val attachments = decodeAttachments(obj.get("attachments"))
            val contextIds = obj.get("contextIds")?.let { element ->
                require(element.isJsonArray) { "An item's context links are invalid." }
                element.asJsonArray.map { link ->
                    require(link.isJsonPrimitive && link.asJsonPrimitive.isString) { "An item's context link is invalid." }
                    link.asString
                }
            }.orEmpty()

            require(id.length in 1..100 && ids.add(id)) { "The backup contains a missing or duplicate item ID." }
            require(title.isNotBlank() && title.length <= CaptureFactory.MAX_TITLE_LENGTH) { "An item title is missing or too long." }
            require(content.isNotBlank() && content.length <= CaptureFactory.MAX_CONTENT_LENGTH) { "An item is empty or exceeds the content limit." }
            require(originalContent.isNotBlank() && originalContent.length <= CaptureFactory.MAX_CONTENT_LENGTH) { "An item's original source is invalid." }
            require(sourceLabel.length <= 120) { "An item's source label is too long." }
            require(relatedToId == null || relatedToId.length in 1..100) { "An item's related record ID is invalid." }
            require(missionMode == null || missionMode.length <= 30) { "An item's mission mode is invalid." }
            require(contextIds.size <= 8 && contextIds.all { it.length in 1..100 }) { "An item's context links are invalid." }
            require(createdAt > 0L && updatedAt >= createdAt) { "An item's timestamps are invalid." }
            require(sourceUrl == null || (sourceUrl.length <= 2048 && (sourceUrl.startsWith("https://", ignoreCase = true) || sourceUrl.startsWith("http://", ignoreCase = true)))) {
                "An item's source URL is invalid."
            }
            validateAttachments(attachments)
            Capture(id, title, content, kind, status, sourceLabel.ifBlank { "Imported" }, sourceUrl, createdAt, updatedAt, relatedToId, missionMode, contextIds, attachments, originalContent)
        }
    }


    private fun decodeAttachments(value: com.google.gson.JsonElement?): List<CaptureAttachment> {
        if (value == null || value.isJsonNull) return emptyList() // schema v1 compatibility
        require(value.isJsonArray) { "An item's attachments are invalid." }
        require(value.asJsonArray.size() <= SharedAttachmentImport.MAX_ATTACHMENTS) { "An item contains too many attachments." }
        return value.asJsonArray.map { entry ->
            require(entry.isJsonObject) { "An item's attachment is invalid." }
            val obj = entry.asJsonObject
            val id = obj.stringOrNull("id")?.trim().orEmpty()
            val fileName = obj.stringOrNull("fileName")?.trim().orEmpty()
            val mimeType = obj.stringOrNull("mimeType")?.trim().orEmpty()
            val byteLength = obj.longOrNull("byteLength") ?: 0L
            val data = obj.stringOrNull("dataBase64")?.trim().orEmpty()
            require(id.length in 1..100 && fileName.isNotBlank() && fileName.length <= 240) { "An attachment name or ID is invalid." }
            require(mimeType.length in 1..160 && !mimeType.contains('\n') && !mimeType.contains('\r')) { "An attachment media type is invalid." }
            require(byteLength in 1..SharedAttachmentImport.MAX_ATTACHMENT_BYTES.toLong()) { "An attachment size is invalid." }
            require(data.isNotBlank() && data.length <= ((SharedAttachmentImport.MAX_ATTACHMENT_BYTES * 4L / 3L) + 8L)) { "An attachment payload is invalid or too large." }
            val bytes = try { Base64.getDecoder().decode(data) } catch (_: Exception) { throw IllegalArgumentException("An attachment payload is not valid Base64.") }
            require(bytes.size.toLong() == byteLength) { "An attachment payload does not match its recorded size." }
            CaptureAttachment(id, fileName, mimeType, byteLength, data)
        }
    }

    private fun validateAttachments(attachments: List<CaptureAttachment>) {
        require(attachments.size <= SharedAttachmentImport.MAX_ATTACHMENTS) { "An item contains too many attachments." }
        require(attachments.sumOf { it.byteLength } <= SharedAttachmentImport.MAX_TOTAL_BYTES) { "An item's attachments exceed the combined size limit." }
        require(attachments.map { it.id }.distinct().size == attachments.size) { "An item's attachment IDs are duplicated." }
        attachments.forEach { item ->
            require(item.id.length in 1..100 && item.fileName.isNotBlank() && item.fileName.length <= 240) { "An attachment name or ID is invalid." }
            require(item.mimeType.length in 1..160 && !item.mimeType.contains('\n') && !item.mimeType.contains('\r')) { "An attachment media type is invalid." }
            require(item.byteLength in 1..SharedAttachmentImport.MAX_ATTACHMENT_BYTES.toLong()) { "An attachment size is invalid." }
            require(item.dataBase64.isNotBlank() && item.dataBase64.length <= ((SharedAttachmentImport.MAX_ATTACHMENT_BYTES * 4L / 3L) + 8L)) { "An attachment payload is invalid or too large." }
            val decoded = try { Base64.getDecoder().decode(item.dataBase64) } catch (_: Exception) { throw IllegalArgumentException("An attachment payload is not valid Base64.") }
            require(decoded.size.toLong() == item.byteLength) { "An attachment payload does not match its recorded size." }
        }
    }

    private fun estimateJsonStringBytes(value: String): Long {
        var extra = 0L
        value.forEach { char ->
            extra += when {
                char == '"' || char == '\\' || char == '\n' || char == '\r' || char == '\t' -> 1L
                char.code < 0x20 -> 5L
                else -> 0L
            }
        }
        return value.toByteArray(Charsets.UTF_8).size.toLong() + extra
    }

    private fun toJson(item: Capture) = JsonObject().apply {
        addProperty("id", item.id)
        addProperty("title", item.title)
        addProperty("content", item.content)
        if (item.originalContent != null) addProperty("originalContent", item.originalContent)
        addProperty("kind", item.kind.name)
        addProperty("status", item.status.name)
        addProperty("sourceLabel", item.sourceLabel)
        if (item.sourceUrl == null) add("sourceUrl", com.google.gson.JsonNull.INSTANCE) else addProperty("sourceUrl", item.sourceUrl)
        addProperty("createdAt", item.createdAt)
        addProperty("updatedAt", item.updatedAt)
        if (item.relatedToId != null) addProperty("relatedToId", item.relatedToId)
        if (item.missionMode != null) addProperty("missionMode", item.missionMode)
        if (item.contextIds.isNotEmpty()) add("contextIds", JsonArray().also { array -> item.contextIds.forEach { link -> array.add(link) } })
        if (item.attachments.isNotEmpty()) add("attachments", JsonArray().also { array ->
            item.attachments.forEach { attachment ->
                array.add(JsonObject().apply {
                    addProperty("id", attachment.id)
                    addProperty("fileName", attachment.fileName)
                    addProperty("mimeType", attachment.mimeType)
                    addProperty("byteLength", attachment.byteLength)
                    addProperty("dataBase64", attachment.dataBase64)
                })
            }
        })
    }

    private fun JsonObject.stringOrNull(key: String): String? {
        val value = get(key) ?: return null
        if (value.isJsonNull || !value.isJsonPrimitive || !value.asJsonPrimitive.isString) return null
        return value.asString
    }

    private fun JsonObject.intOrNull(key: String): Int? {
        return try {
            val value = get(key) ?: return null
            if (!value.isJsonPrimitive || !value.asJsonPrimitive.isNumber) null else value.asInt
        } catch (_: Exception) { null }
    }

    private fun JsonObject.longOrNull(key: String): Long? {
        return try {
            val value = get(key) ?: return null
            if (!value.isJsonPrimitive || !value.asJsonPrimitive.isNumber) null else value.asLong
        } catch (_: Exception) { null }
    }
}
