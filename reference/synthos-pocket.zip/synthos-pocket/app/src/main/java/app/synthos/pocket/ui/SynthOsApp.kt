package app.synthos.pocket.ui

import android.content.Intent
import android.content.ClipboardManager
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountTree
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.ArrowForward
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.CheckCircleOutline
import androidx.compose.material.icons.outlined.CloudOff
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.FileDownload
import androidx.compose.material.icons.outlined.FileUpload
import androidx.compose.material.icons.outlined.Forum
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Lightbulb
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.PhoneAndroid
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Job
import app.synthos.pocket.data.Capture
import app.synthos.pocket.data.IncomingAttachment
import app.synthos.pocket.data.SharedAttachmentImport
import app.synthos.pocket.data.CaptureCodec
import app.synthos.pocket.data.CaptureKind
import app.synthos.pocket.data.CaptureStatus
import app.synthos.pocket.data.MissionMode
import app.synthos.pocket.data.WorkstreamDefinition
import app.synthos.pocket.data.PromptComposer
import app.synthos.pocket.data.LocalAiRuntime
import app.synthos.pocket.data.LocalAiPromptComposer
import app.synthos.pocket.data.WorkspaceState
import app.synthos.pocket.data.ModelCatalog
import app.synthos.pocket.data.ModelDownloader
import app.synthos.pocket.data.ModelOption
import app.synthos.pocket.capture.ShareTargetChosenReceiver
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

private enum class MainTab(val label: String) { WORK("Work"), LIBRARY("Library"), SETTINGS("Settings") }

/** Opens Android's system share sheet for an explicitly requested specialist handoff. */
private fun shareTextToApp(
    context: android.content.Context,
    subject: String,
    text: String,
    sessionId: String,
    onNotify: (String) -> Unit
) {
    if (text.isBlank()) {
        onNotify("This handoff is empty. Add a goal or context before sharing it.")
        return
    }

    val sendIntent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, subject.take(180))
        putExtra(Intent.EXTRA_TEXT, text)
    }

    try {
        val callbackIntent = Intent(context, ShareTargetChosenReceiver::class.java).putExtra(ShareTargetChosenReceiver.EXTRA_SESSION_ID, sessionId)
        val mutableFlag = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) android.app.PendingIntent.FLAG_MUTABLE else 0
        val callback = android.app.PendingIntent.getBroadcast(
            context,
            sessionId.hashCode(),
            callbackIntent,
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or mutableFlag
        )
        context.startActivity(Intent.createChooser(sendIntent, "Choose the app for this tracked session", callback.intentSender))
    } catch (_: Exception) {
        onNotify("Android couldn't open the system destination chooser. The session brief is still saved in this mission.")
    }
}

@Composable
fun SynthOsApp(
    unlocked: Boolean,
    authenticationMessage: String?,
    sharedText: String,
    sharedAttachments: List<IncomingAttachment>,
    floatingCaptureRequested: Boolean,
    shareTargetUpdate: Pair<String, String>?,
    floatingCaptureEnabled: Boolean,
    themeMode: ThemeMode,
    onUnlock: () -> Unit,
    onOpenDeviceSecurity: () -> Unit,
    onSharedTextConsumed: () -> Unit,
    onFloatingCaptureConsumed: () -> Unit,
    onShareTargetUpdateConsumed: () -> Unit,
    onFloatingCaptureChanged: (Boolean) -> Unit,
    onThemeModeChanged: (ThemeMode) -> Unit
) {
    val context = LocalContext.current
    val workspace = remember(context) { WorkspaceState(context.applicationContext) }
    val modelPreferences = remember(context) { context.getSharedPreferences("synthos-models", android.content.Context.MODE_PRIVATE) }
    val legacyModelFile = remember(context) { File(context.filesDir, "models/synthos-local.litertlm") }
    var activeModelId by rememberSaveable { mutableStateOf(modelPreferences.getString("active_model_id", if (legacyModelFile.isFile && legacyModelFile.length() > 0L) ModelCatalog.CUSTOM_ID else "") ?: "") }
    val modelFile = remember(context, activeModelId) { ModelCatalog.fileFor(context, activeModelId) }
    val customModelFile = remember(context) { ModelCatalog.fileFor(context, ModelCatalog.CUSTOM_ID) }
    val localAiRuntime = remember(context) { LocalAiRuntime(File(context.cacheDir, "litertlm")) }
    var localModelInstalled by remember(modelFile) { mutableStateOf(modelFile.isFile && modelFile.length() > 0L) }
    var customModelInstalled by remember(customModelFile) { mutableStateOf(customModelFile.isFile && customModelFile.length() > 10_000_000L) }
    var installedModelIds by remember(context) { mutableStateOf(ModelCatalog.installedIds(context)) }
    var modelDownloadId by rememberSaveable { mutableStateOf<String?>(null) }
    var modelDownloadPercent by rememberSaveable { mutableStateOf(0) }
    var modelDownloadBytes by rememberSaveable { mutableStateOf(0L) }
    var modelDownloadTotal by rememberSaveable { mutableStateOf(0L) }
    val modelDownloadJob = remember { mutableStateOf<Job?>(null) }
    var modelImporting by rememberSaveable { mutableStateOf(false) }
    var modelToRemoveId by rememberSaveable { mutableStateOf<String?>(null) }
    var tab by rememberSaveable { mutableStateOf(MainTab.WORK) }
    var missionDraft by rememberSaveable { mutableStateOf("") }
    var captureDraft by rememberSaveable { mutableStateOf("") }
    var captureSource by rememberSaveable { mutableStateOf("Quick capture") }
    var pendingAttachments by remember { mutableStateOf<List<IncomingAttachment>>(emptyList()) }
    // Keep IDs after a partial mission-creation failure so retry resumes the saved records instead of duplicating them.
    var pendingExternalCaptureId by rememberSaveable { mutableStateOf<String?>(null) }
    var pendingExternalMissionId by rememberSaveable { mutableStateOf<String?>(null) }
    var missionId by rememberSaveable { mutableStateOf<String?>(null) }
    var missionModeName by rememberSaveable { mutableStateOf(MissionMode.COLLABORATE.name) }
    var showQuickCapture by rememberSaveable { mutableStateOf(false) }
    var showContextPicker by rememberSaveable { mutableStateOf(false) }
    var editingCapture by remember { mutableStateOf<Capture?>(null) }
    var attachingCapture by remember { mutableStateOf<Capture?>(null) }
    var showExportWarning by rememberSaveable { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    val notify: (String) -> Unit = { message -> scope.launchInSnackbar(snackbar, message) }
    LaunchedEffect(unlocked) {
        if (unlocked) {
            if (!workspace.isLoaded) workspace.load()
            // A source may already be persisted while mission/link creation needs a retry.
            // Reconstruct the review surface from that encrypted source after lock/process recreation.
            pendingExternalCaptureId?.let { id ->
                workspace.items.firstOrNull { it.id == id }?.let { savedSource ->
                    captureDraft = savedSource.content
                    captureSource = "External app share"
                    tab = MainTab.WORK
                }
            }
        } else {
            localAiRuntime.requestCancel()
            workspace.lock()
            // The lock screen and in-memory data clearing are immediate; native teardown
            // completes independently so a slow model cannot stall the lock transition.
            scope.launch { runCatching { localAiRuntime.close() } }
            missionDraft = ""
            captureDraft = ""
            pendingAttachments = emptyList()
            editingCapture = null
            attachingCapture = null
            showExportWarning = false
            showQuickCapture = false
            showContextPicker = false
        }
    }
    if (!unlocked) {
        LockScreen(authenticationMessage, onUnlock, onOpenDeviceSecurity)
        return
    }
    LaunchedEffect(sharedText, sharedAttachments) {
        if (sharedText.isNotBlank() || sharedAttachments.isNotEmpty()) {
            captureDraft = sharedText.take(50_000).ifBlank {
                sharedAttachments.joinToString(separator = "\n") { it.fileName }.take(50_000)
            }
            pendingAttachments = sharedAttachments
            pendingExternalCaptureId = null
            pendingExternalMissionId = null
            captureSource = "External app share"
            tab = MainTab.WORK
            onSharedTextConsumed()
        }
    }
    LaunchedEffect(floatingCaptureRequested, unlocked) {
        if (floatingCaptureRequested && unlocked) {
            // This is a fresh capture intent, not a retry of any previous external session.
            pendingExternalCaptureId = null
            pendingExternalMissionId = null
            val clipboardText = runCatching {
                val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(context)?.toString().orEmpty()
            }.getOrDefault("").trim()
            captureSource = "Floating capture"
            captureDraft = clipboardText.take(50_000)
            tab = MainTab.WORK
            if (clipboardText.isBlank()) showQuickCapture = true
            else notify("Clipboard text is ready to review. Nothing is saved until you choose.")
            onFloatingCaptureConsumed()
        }
    }
    LaunchedEffect(shareTargetUpdate, unlocked, workspace.isLoaded) {
        if (shareTargetUpdate != null && unlocked && workspace.isLoaded) {
            val (sessionId, targetLabel) = shareTargetUpdate
            val session = workspace.items.firstOrNull { it.id == sessionId }
            if (session != null && session.sourceLabel.startsWith("External session")) {
                workspace.update(session.copy(sourceLabel = "External session · sent to ${targetLabel}".take(120)))
                notify("Destination tracked: $targetLabel. Share its reply back into this mission to continue the same thread.")
            }
            onShareTargetUpdateConsumed()
        }
    }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                val json = CaptureCodec.encode(workspace.items)
                val output = context.contentResolver.openOutputStream(uri) ?: error("Android couldn't open the selected export destination.")
                output.use { it.write(json.toByteArray(Charsets.UTF_8)) }
            }.onSuccess { notify("Backup exported. Keep it somewhere private.") }
                .onFailure { notify(it.message ?: "The backup could not be exported.") }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                val input = context.contentResolver.openInputStream(uri) ?: error("Android couldn't open that file.")
                val json = input.use { readBoundedText(it, CaptureCodec.MAX_BACKUP_BYTES) }
                workspace.importBackup(json)
            }.onSuccess { count ->
                notify(if (count == 0) "No new items found. Existing items were kept." else "$count item${if (count == 1) "" else "s"} restored.")
            }.onFailure { notify(it.message ?: "That backup couldn't be restored.") }
        }
    }

    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                modelImporting = true
                try {
                    withContext(Dispatchers.IO) {
                        val displayName = context.contentResolver.query(
                            uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null
                        )?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0).orEmpty() else "" }.orEmpty()
                        require(displayName.endsWith(".litertlm", ignoreCase = true)) {
                            "Choose a model file in LiteRT-LM .litertlm format. GGUF and .task files are not interchangeable."
                        }
                        val input = context.contentResolver.openInputStream(uri) ?: error("Android couldn't open that model file.")
                        val modelDirectory = checkNotNull(customModelFile.parentFile)
                        if (!modelDirectory.exists() && !modelDirectory.mkdirs()) error("SynthOS couldn't create private model storage.")
                        val pending = File(modelDirectory, "synthos-custom-model.pending")
                        val previous = File(modelDirectory, "synthos-custom-model.previous")
                        pending.delete()
                        input.use { source -> FileOutputStream(pending).use { destination -> copyModelBounded(source, destination) } }
                        require(pending.isFile && pending.length() > 1_000_000L) { "That file is empty or too small to be a valid language model." }
                        localAiRuntime.requestCancel()
                        localAiRuntime.close()
                        previous.delete()
                        if (customModelFile.exists() && !customModelFile.renameTo(previous)) {
                            pending.delete()
                            error("SynthOS couldn't replace the previous model safely. It has been kept.")
                        }
                        if (!pending.renameTo(customModelFile)) {
                            if (previous.exists()) previous.renameTo(customModelFile)
                            error("SynthOS couldn't move the model into private storage. The previous model was restored where possible.")
                        }
                        previous.delete()
                    }
                    localAiRuntime.requestCancel()
                    localAiRuntime.close()
                    activeModelId = ModelCatalog.CUSTOM_ID
                    modelPreferences.edit().putString("active_model_id", activeModelId).apply()
                    localModelInstalled = customModelFile.isFile && customModelFile.length() > 0L
                    installedModelIds = ModelCatalog.installedIds(context)
                    customModelInstalled = true
                    notify("Custom local model imported. Its first reply will load it into memory.")
                } catch (error: Exception) {
                    runCatching { File(customModelFile.parentFile, "synthos-custom-model.pending").delete() }
                    localModelInstalled = modelFile.isFile && modelFile.length() > 0L
                    notify(error.message ?: "The model could not be imported.")
                } finally {
                    modelImporting = false
                }
            }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                MainTab.entries.forEach { destination ->
                    NavigationBarItem(
                        selected = tab == destination,
                        onClick = { tab = destination },
                        icon = {
                            Icon(
                                imageVector = when (destination) {
                                    MainTab.WORK -> Icons.Outlined.Home
                                    MainTab.LIBRARY -> Icons.Outlined.Search
                                    MainTab.SETTINGS -> Icons.Outlined.Settings
                                },
                                contentDescription = destination.label
                            )
                        },
                        label = { Text(destination.label) }
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when {
                !workspace.isLoaded -> LoadingScreen()
                workspace.error != null -> StorageErrorScreen(workspace.error.orEmpty(), workspace::load)
                else -> Crossfade(targetState = tab, animationSpec = tween(180), label = "main-destination") { destination ->
                    when (destination) {
                        MainTab.WORK -> {
                            val mission = workspace.items.firstOrNull { it.id == missionId && it.sourceLabel == "SynthOS mission" }
                            Crossfade(targetState = mission, animationSpec = tween(180), label = "work-surface") { currentMission ->
                                if (currentMission == null) {
                                    WorkScreen(
                                        workspace = workspace,
                                        missionDraft = missionDraft,
                                        onMissionDraftChanged = { missionDraft = it },
                                        modeName = missionModeName,
                                        onModeChanged = { missionModeName = it.name },
                                        captureDraft = captureDraft,
                                        captureSource = captureSource,
                                        pendingAttachments = pendingAttachments,
                                        onCaptureDraftChanged = { captureDraft = it },
                                        onSaveCapture = {
                                            val isExternal = captureSource.startsWith("External") || captureSource == "Floating capture"
                                            val kind = if (isExternal) CaptureKind.REFERENCE else CaptureKind.IDEA
                                            val sourceLabel = when (captureSource) {
                                                "External app share" -> "External session · imported material"
                                                "Floating capture" -> "External session · floating capture"
                                                else -> captureSource
                                            }
                                            scope.launch {
                                                try {
                                                    val existingSource = pendingExternalCaptureId?.let { id -> workspace.items.firstOrNull { it.id == id } }
                                                    if (existingSource != null) {
                                                        captureDraft = ""
                                                        pendingAttachments = emptyList()
                                                        pendingExternalCaptureId = null
                                                        pendingExternalMissionId = null
                                                        captureSource = "Quick capture"
                                                        notify("The source was already saved in Inbox; no duplicate was created.")
                                                    } else {
                                                        val attachments = withContext(Dispatchers.IO) { SharedAttachmentImport.read(context, pendingAttachments) }
                                                        val content = captureDraft.trim().ifBlank { attachments.joinToString(prefix = "Shared attachments: ") { it.fileName } }
                                                        val saved = workspace.addCapture(content, kind, sourceLabel, attachments = attachments)
                                                        if (saved != null) {
                                                            captureDraft = ""
                                                            pendingAttachments = emptyList()
                                                            pendingExternalCaptureId = null
                                                            pendingExternalMissionId = null
                                                            captureSource = "Quick capture"
                                                            notify("Saved locally. Shared file data is now inside the encrypted workspace.")
                                                        } else notify(workspace.operationMessage ?: "The capture could not be saved.")
                                                    }
                                                } catch (error: Exception) {
                                                    notify(error.message ?: "The shared content could not be copied safely. Nothing was saved.")
                                                }
                                            }
                                        },
                                        onUseCaptureAsMission = {
                                            scope.launch {
                                                try {
                                                    val existingSource = pendingExternalCaptureId?.let { id -> workspace.items.firstOrNull { it.id == id } }
                                                    val externalSource = existingSource ?: run {
                                                        val attachments = withContext(Dispatchers.IO) { SharedAttachmentImport.read(context, pendingAttachments) }
                                                        val transcript = captureDraft.trim().ifBlank { attachments.joinToString(prefix = "Shared attachments: ") { it.fileName } }
                                                        workspace.addCapture(
                                                            transcript,
                                                            CaptureKind.REFERENCE,
                                                            if (captureSource == "Floating capture") "External session · floating capture" else "External session · imported conversation",
                                                            attachments = attachments
                                                        )?.also { pendingExternalCaptureId = it.id }
                                                    }
                                                    if (externalSource == null) {
                                                        notify(workspace.operationMessage ?: "The external session could not be saved.")
                                                    } else {
                                                        val missionGoal = "Continue external session: ${externalSource.title.take(130)}\n\nUse the attached conversation or material as prior context. Preserve decisions already made, continue the original task, and ask only when something essential is missing."
                                                        val existingMission = pendingExternalMissionId?.let { id -> workspace.items.firstOrNull { it.id == id } }
                                                        val item = existingMission ?: workspace.addCapture(missionGoal, CaptureKind.TASK, "SynthOS mission", missionMode = missionModeName)
                                                            ?.also { pendingExternalMissionId = it.id }
                                                        if (item != null) {
                                                            val linkedMission = if (item.status == CaptureStatus.ACTIVE && item.contextIds == listOf(externalSource.id)) item
                                                                else item.copy(status = CaptureStatus.ACTIVE, contextIds = listOf(externalSource.id))
                                                            val missionSaved = linkedMission == item || workspace.update(linkedMission)
                                                            val sourceLinked = externalSource.relatedToId == item.id || workspace.update(externalSource.copy(relatedToId = item.id))
                                                            if (missionSaved && sourceLinked) {
                                                                missionId = item.id
                                                                captureDraft = ""
                                                                pendingAttachments = emptyList()
                                                                pendingExternalCaptureId = null
                                                                pendingExternalMissionId = null
                                                                captureSource = "Quick capture"
                                                                notify("Shared source and attachments saved; its context is attached to the new mission.")
                                                            } else notify(workspace.operationMessage ?: "The session was saved, but its links could not be completed. Retry to finish linking the saved records.")
                                                        } else notify(workspace.operationMessage ?: "The session was saved, but the mission could not be created. Retry to continue from the saved source.")
                                                    }
                                                } catch (error: Exception) {
                                                    notify(error.message ?: "The shared content could not be copied safely. Nothing was saved.")
                                                }
                                            }
                                        },
                                        onDismissCapture = { captureDraft = ""; pendingAttachments = emptyList(); pendingExternalCaptureId = null; pendingExternalMissionId = null; captureSource = "Quick capture" },
                                        onStartMission = { goal ->
                                            val mode = MissionMode.fromStored(missionModeName)
                                            val item = workspace.addCapture(goal, CaptureKind.TASK, "SynthOS mission", missionMode = mode.name)
                                            if (item != null) {
                                                if (workspace.update(item.copy(status = CaptureStatus.ACTIVE))) {
                                                    missionId = item.id
                                                    missionDraft = ""
                                                    notify("Mission saved. Prepare a specialist handoff when you are ready.")
                                                } else notify(workspace.operationMessage ?: "The mission could not be activated.")
                                            } else notify(workspace.operationMessage ?: "Add a goal and try again.")
                                        },
                                        onOpenMission = { item -> missionId = item.id; missionModeName = item.missionMode ?: MissionMode.COLLABORATE.name },
                                        onEditCapture = { editingCapture = it },
                                        onOpenLibrary = { tab = MainTab.LIBRARY },
                                        onOpenQuickCapture = { showQuickCapture = true },
                                        onNotify = notify
                                    )
                                } else {
                                    MissionWorkspaceScreen(
                                        mission = currentMission,
                                        workspace = workspace,
                                        modelFile = modelFile,
                                        localAiRuntime = localAiRuntime,
                                        localModelInstalled = localModelInstalled,
                                        workScope = scope,
                                        onOpenModelSettings = { tab = MainTab.SETTINGS },
                                        captureDraft = captureDraft,
                                        captureSource = captureSource,
                                        onCaptureDraftChanged = { captureDraft = it },
                                        onSaveResponse = {
                                            val response = workspace.addCapture(
                                                captureDraft,
                                                CaptureKind.RESEARCH,
                                                if (captureSource.startsWith("External") || captureSource == "Floating capture") "External session · returned material" else "Model response",
                                                relatedToId = currentMission.id
                                            )
                                            if (response != null) {
                                                captureDraft = ""
                                                captureSource = "Quick capture"
                                                notify("Response saved and linked to this mission.")
                                            } else notify(workspace.operationMessage ?: "The response could not be saved.")
                                        },
                                        onModeChanged = { mode ->
                                            if (workspace.update(currentMission.copy(missionMode = mode.name))) {
                                                missionModeName = mode.name
                                                notify("Mission mode changed to ${mode.label}.")
                                            } else notify(workspace.operationMessage ?: "The mode could not be changed.")
                                        },
                                        onOpenContextPicker = { showContextPicker = true },
                                        onOpenLibrary = { tab = MainTab.LIBRARY },
                                        onBack = { missionId = null },
                                        onEditCapture = { editingCapture = it },
                                        onNotify = notify
                                    )
                                }
                            }
                        }
                        MainTab.LIBRARY -> LibraryScreen(workspace, onEdit = { editingCapture = it })
                        MainTab.SETTINGS -> SettingsScreen(
                            themeMode = themeMode,
                            onThemeModeChanged = onThemeModeChanged,
                            localModelInstalled = localModelInstalled,
                            activeModelId = activeModelId,
                            installedModelIds = installedModelIds,
                            modelImporting = modelImporting,
                            downloadingModelId = modelDownloadId,
                            downloadPercent = modelDownloadPercent,
                            downloadedBytes = modelDownloadBytes,
                            totalBytes = modelDownloadTotal,
                            floatingCaptureEnabled = floatingCaptureEnabled,
                            onFloatingCaptureChanged = onFloatingCaptureChanged,
                            onDownloadModel = { option ->
                                if (modelDownloadJob.value?.isActive == true) {
                                    notify("One model downloads at a time. Cancel it before starting another.")
                                } else {
                                    modelDownloadId = option.id
                                    modelDownloadPercent = 0
                                    modelDownloadBytes = 0L
                                    modelDownloadTotal = 0L
                                    modelDownloadJob.value = scope.launch {
                                        try {
                                            ModelDownloader.download(context, option) { percent, received, total ->
                                                modelDownloadPercent = percent
                                                modelDownloadBytes = received
                                                modelDownloadTotal = total
                                            }
                                            localAiRuntime.requestCancel()
                                            localAiRuntime.close()
                                            installedModelIds = ModelCatalog.installedIds(context)
                                            activeModelId = option.id
                                            modelPreferences.edit().putString("active_model_id", option.id).apply()
                                            localModelInstalled = true
                                            notify("${option.name} installed and selected. The first reply loads it locally.")
                                        } catch (cancelled: CancellationException) {
                                            notify("Model download cancelled. Any incomplete file was removed; installed models were kept.")
                                            throw cancelled
                                        } catch (error: Exception) {
                                            notify(error.message ?: "The model couldn't be downloaded. Check the connection and retry.")
                                        } finally {
                                            installedModelIds = ModelCatalog.installedIds(context)
                                            modelDownloadId = null
                                            modelDownloadPercent = 0
                                            modelDownloadBytes = 0L
                                            modelDownloadTotal = 0L
                                            modelDownloadJob.value = null
                                        }
                                    }
                                }
                            },
                            onCancelDownload = { modelDownloadJob.value?.cancel() },
                            onSelectModel = { id ->
                                scope.launch {
                                    val file = ModelCatalog.fileFor(context, id)
                                    if (file.isFile && file.length() > 10_000_000L) {
                                        localAiRuntime.requestCancel()
                                        localAiRuntime.close()
                                        activeModelId = id
                                        modelPreferences.edit().putString("active_model_id", id).apply()
                                        localModelInstalled = true
                                        notify("${ModelCatalog.options.firstOrNull { it.id == id }?.name ?: "Custom model"} selected.")
                                    } else notify("That model isn't installed yet.")
                                }
                            },
                            onImportModel = { modelPicker.launch(arrayOf("*/*")) },
                            customModelInstalled = customModelInstalled,
                            onRemoveModel = { id -> modelToRemoveId = id },
                            onExport = { showExportWarning = true },
                            onImport = { importLauncher.launch(arrayOf("application/json", "text/json", "text/plain")) }
                        )
                    }
                }
            }
        }
    }

    if (showQuickCapture) {
        QuickCaptureDialog(
            onDismiss = { showQuickCapture = false },
            onSave = { content, kind ->
                val sourceLabel = if (captureSource == "Floating capture") "External session · floating capture" else "Quick capture"
                val saved = workspace.addCapture(content, kind, sourceLabel)
                if (saved != null) {
                    showQuickCapture = false
                    captureSource = "Quick capture"
                    notify("Saved to your encrypted library.")
                } else notify(workspace.operationMessage ?: "The capture could not be saved.")
            }
        )
    }

    if (showContextPicker) {
        val contextMission = workspace.items.firstOrNull { it.id == missionId && it.sourceLabel == "SynthOS mission" }
        if (contextMission != null) {
            ContextPickerDialog(
                workspace = workspace,
                mission = contextMission,
                onDismiss = { showContextPicker = false },
                onNotify = notify
            )
        } else {
            showContextPicker = false
        }
    }

    if (editingCapture != null && workspace.error == null) {
        CaptureEditorDialog(
            capture = editingCapture!!,
            onDismiss = { editingCapture = null },
            onSave = { edited ->
                val saved = workspace.update(edited)
                if (saved) {
                    editingCapture = null
                    notify("Changes saved securely.")
                } else notify(workspace.operationMessage ?: "The change could not be saved.")
            },
            onDelete = { id ->
                val deleted = workspace.delete(id)
                if (deleted) {
                    editingCapture = null
                    notify("Item deleted.")
                } else notify(workspace.operationMessage ?: "The item could not be deleted.")
            },
            onAttachToMission = { draft ->
                // Save the editor draft first so attaching cannot silently discard pending edits.
                if (workspace.update(draft)) {
                    attachingCapture = workspace.items.firstOrNull { it.id == draft.id } ?: draft
                    editingCapture = null
                } else notify(workspace.operationMessage ?: "The source could not be saved before attaching.")
            }
        )
    }

    if (attachingCapture != null && workspace.error == null) {
        val source = attachingCapture!!
        AttachSourceToMissionDialog(
            source = source,
            missions = workspace.items.filter { it.sourceLabel == "SynthOS mission" && it.status != CaptureStatus.ARCHIVED },
            onDismiss = { attachingCapture = null },
            onAttach = { mission ->
                if (workspace.attachSourceToMission(source.id, mission.id)) {
                    attachingCapture = null
                    notify("${source.title.take(70)} attached to ${mission.title.take(70)}. The source stays in your encrypted library.")
                } else notify(workspace.operationMessage ?: "The source could not be attached.")
            }
        )
    }

    if (modelToRemoveId != null) {
        val removingId = modelToRemoveId!!
        val removingName = ModelCatalog.options.firstOrNull { it.id == removingId }?.name ?: "Custom imported model"
        AlertDialog(
            onDismissRequest = { modelToRemoveId = null },
            icon = { Icon(Icons.Outlined.DeleteOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("Remove $removingName?") },
            text = { Text("This removes only this model file. Your encrypted missions, conversations, captured sources and other installed models remain untouched.") },
            confirmButton = {
                Button(onClick = {
                    modelToRemoveId = null
                    scope.launch {
                        val removingActiveModel = activeModelId == removingId
                        modelImporting = true
                        try {
                            if (removingActiveModel) {
                                localAiRuntime.requestCancel()
                                localAiRuntime.close()
                            }
                            val fileToRemove = ModelCatalog.fileFor(context, removingId)
                            withContext(Dispatchers.IO) {
                                if (fileToRemove.exists() && !fileToRemove.delete()) error("Android couldn't remove this model file.")
                            }
                            if (removingId == ModelCatalog.CUSTOM_ID) customModelInstalled = false
                            if (removingActiveModel) {
                                activeModelId = ""
                                modelPreferences.edit().remove("active_model_id").apply()
                                localModelInstalled = false
                            }
                            installedModelIds = ModelCatalog.installedIds(context)
                            notify("$removingName removed. Other installed models and saved mission data were kept.")
                        } catch (error: Exception) {
                            installedModelIds = ModelCatalog.installedIds(context)
                            customModelInstalled = customModelFile.isFile && customModelFile.length() > 10_000_000L
                            notify(error.message ?: "The model file couldn't be removed.")
                        } finally {
                            modelImporting = false
                        }
                    }
                }) { Text("Remove model") }
            },
            dismissButton = { TextButton(onClick = { modelToRemoveId = null }) { Text("Keep model") } }
        )
    }

    if (showExportWarning) {
        AlertDialog(
            onDismissRequest = { showExportWarning = false },
            icon = { Icon(Icons.Outlined.FileDownload, contentDescription = null, tint = warningSemanticColor()) },
            title = { Text("Export a backup?") },
            text = { Text("The chosen JSON backup is not encrypted and includes any saved attachment bytes. Anyone who can read that file can read its contents. Save it to a trusted location.") },
            confirmButton = {
                Button(onClick = {
                    showExportWarning = false
                    exportLauncher.launch("synthos-backup.json")
                }) { Text("Choose location") }
            },
            dismissButton = { TextButton(onClick = { showExportWarning = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun LockScreen(message: String?, onUnlock: () -> Unit, onOpenDeviceSecurity: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 28.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.Start
    ) {
        Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(76.dp)) {
            Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(38.dp))
            }
        }
        Spacer(Modifier.height(24.dp))
        Text("SynthOS", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(8.dp))
        Text("Your work, connected.", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(12.dp))
        Text("A private workspace for the ideas, sources and decisions you want to keep.", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(24.dp))
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Outlined.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Encrypted on this device", style = MaterialTheme.typography.titleMedium)
                    Text("Unlock with a strong biometric or your device lock. Your workspace doesn't need a cloud account.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        if (!message.isNullOrBlank()) {
            Spacer(Modifier.height(16.dp))
            Surface(color = MaterialTheme.colorScheme.errorContainer, shape = MaterialTheme.shapes.medium) {
                Text(message, modifier = Modifier.padding(14.dp), color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodyMedium)
            }
        }
        Spacer(Modifier.height(24.dp))
        Button(onClick = onUnlock, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)) {
            Icon(Icons.Outlined.Lock, contentDescription = null)
            Spacer(Modifier.width(10.dp))
            Text("Unlock workspace")
        }
        TextButton(onClick = onOpenDeviceSecurity, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
            Text("Device security settings")
        }
    }
}

@Composable
private fun LoadingScreen() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
            CircularProgressIndicator()
            Text("Unlocking your workspace…", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun StorageErrorScreen(message: String, onRetry: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.Start
    ) {
        Icon(Icons.Outlined.Security, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(40.dp))
        Spacer(Modifier.height(16.dp))
        Text("Workspace not available", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        Text(message, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(20.dp))
        Button(onClick = onRetry, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
            Text("Retry loading")
        }
        Spacer(Modifier.height(8.dp))
        Text("SynthOS will not replace a workspace it cannot read.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun WorkScreen(
    workspace: WorkspaceState,
    missionDraft: String,
    onMissionDraftChanged: (String) -> Unit,
    modeName: String,
    onModeChanged: (MissionMode) -> Unit,
    captureDraft: String,
    captureSource: String,
    pendingAttachments: List<IncomingAttachment>,
    onCaptureDraftChanged: (String) -> Unit,
    onSaveCapture: () -> Unit,
    onUseCaptureAsMission: () -> Unit,
    onDismissCapture: () -> Unit,
    onStartMission: (String) -> Unit,
    onOpenMission: (Capture) -> Unit,
    onEditCapture: (Capture) -> Unit,
    onOpenLibrary: () -> Unit,
    onOpenQuickCapture: () -> Unit,
    onNotify: (String) -> Unit
) {
    val currentMode = MissionMode.fromStored(modeName)
    val missions = workspace.items.filter { it.sourceLabel == "SynthOS mission" && it.status != CaptureStatus.ARCHIVED }
    val externalSessions = workspace.items.filter {
        it.sourceLabel.startsWith("External session") && it.status != CaptureStatus.ARCHIVED
    }.take(8)
    val recentSources = workspace.items.filter {
        it.sourceLabel != "SynthOS mission" &&
            it.sourceLabel != LocalAiPromptComposer.USER_SOURCE &&
            it.sourceLabel != LocalAiPromptComposer.ASSISTANT_SOURCE &&
            it.status != CaptureStatus.ARCHIVED
    }.take(3)
    val contextCount = workspace.items.count {
        it.status != CaptureStatus.ARCHIVED &&
            it.sourceLabel != "SynthOS mission" &&
            it.sourceLabel != LocalAiPromptComposer.USER_SOURCE &&
            it.sourceLabel != LocalAiPromptComposer.ASSISTANT_SOURCE
    }
    val inboxItems = workspace.items.filter {
        it.status == CaptureStatus.INBOX &&
            it.sourceLabel != "SynthOS mission" &&
            it.sourceLabel != LocalAiPromptComposer.USER_SOURCE &&
            it.sourceLabel != LocalAiPromptComposer.ASSISTANT_SOURCE
    }.sortedByDescending { it.updatedAt }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        item { BrandHeader(onQuickCapture = onOpenQuickCapture) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("CAPTURE FIRST", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, letterSpacing = 1.5.sp)
                Text("Keep what matters. Continue when ready.", style = MaterialTheme.typography.headlineLarge)
                Text(
                    "Save a thought, source, file, or decision first. Turn it into a mission when you need a longer working thread.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = MaterialTheme.shapes.large
            ) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(Icons.Outlined.BookmarkBorder, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(25.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text("Capture something", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text("Text, links and small shared files stay local until you save them.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                    }
                    Button(onClick = onOpenQuickCapture, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
                        Text("Quick capture")
                    }
                    Text("${inboxItems.size} item${if (inboxItems.size == 1) "" else "s"} waiting in Inbox", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
        }
        if (captureDraft.isNotBlank() && (captureSource == "External app share" || captureSource == "Floating capture")) {
            item {
                AnimatedVisibility(
                    visible = true,
                    enter = fadeIn(tween(180)) + slideInVertically(tween(180)) { it / 12 },
                    exit = fadeOut(tween(120)) + slideOutVertically(tween(120)) { it / 12 }
                ) {
                    Card(
                        modifier = Modifier.fillMaxWidth().animateContentSize(tween(180)),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        shape = MaterialTheme.shapes.large
                    ) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Outlined.BookmarkBorder, contentDescription = null, tint = MaterialTheme.colorScheme.onSecondaryContainer)
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(if (captureSource == "Floating capture") "Floating capture" else "Shared into SynthOS", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSecondaryContainer)
                                    Text("Review it before it enters your library. Nothing is stored automatically.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSecondaryContainer)
                                }
                            }
                            OutlinedTextField(
                                value = captureDraft,
                                onValueChange = onCaptureDraftChanged,
                                modifier = Modifier.fillMaxWidth().heightIn(min = 100.dp, max = 220.dp),
                                minLines = 3,
                                maxLines = 8,
                                shape = MaterialTheme.shapes.medium,
                                label = { Text("Captured content") }
                            )
                            if (pendingAttachments.isNotEmpty()) {
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("Files to keep (${pendingAttachments.size})", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSecondaryContainer)
                                    pendingAttachments.forEach { attachment ->
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Icon(Icons.Outlined.BookmarkBorder, contentDescription = null, tint = MaterialTheme.colorScheme.onSecondaryContainer, modifier = Modifier.size(18.dp))
                                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                                                Text(attachment.fileName, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSecondaryContainer, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                                Text("${attachment.mimeType} · ${attachment.reportedByteLength?.let(::formatBytes) ?: "size unknown"}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSecondaryContainer)
                                            }
                                        }
                                    }
                                    Text("Each file is copied into the encrypted workspace when saved. Maximum 2 MB per file, 6 MB combined.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSecondaryContainer)
                                    val omitted = pendingAttachments.firstOrNull()?.omittedCount ?: 0
                                    if (omitted > 0) {
                                        Text("$omitted additional shared file${if (omitted == 1) " was" else "s were"} not included. Share those separately.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                Button(onClick = onSaveCapture, enabled = captureDraft.isNotBlank() || pendingAttachments.isNotEmpty(), modifier = Modifier.weight(1f).heightIn(min = 48.dp)) {
                                    Text("Save source")
                                }
                                OutlinedButton(onClick = onUseCaptureAsMission, enabled = captureDraft.isNotBlank() || pendingAttachments.isNotEmpty(), modifier = Modifier.weight(1f).heightIn(min = 48.dp)) {
                                    Text("Make a mission")
                                }
                            }
                            TextButton(onClick = onDismissCapture, modifier = Modifier.align(Alignment.End)) { Text("Discard") }
                        }
                    }
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("Inbox", style = MaterialTheme.typography.titleLarge)
                    Text("Review, edit or discard before items become working context.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (inboxItems.isNotEmpty()) Text("${inboxItems.size}", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            }
        }
        if (inboxItems.isEmpty()) {
            item {
                EmptyState(
                    icon = Icons.Outlined.CheckCircleOutline,
                    title = "Inbox is clear",
                    body = "Use Quick capture or Android Share. New material stays here for review before you connect it to a mission."
                )
            }
        } else {
            items(inboxItems.take(4), key = { "inbox-${it.id}" }) { capture ->
                CaptureCard(capture, onClick = { onEditCapture(capture) })
            }
            if (inboxItems.size > 4) {
                item {
                    TextButton(onClick = onOpenLibrary, modifier = Modifier.fillMaxWidth()) {
                        Text("Review all ${inboxItems.size} Inbox items")
                    }
                }
            }
        }
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.primaryContainer
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.primary, modifier = Modifier.size(38.dp)) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Outlined.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(21.dp))
                            }
                        }
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text("Start a mission", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text("Your goal becomes a persistent thread of work.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                    }
                    OutlinedTextField(
                        value = missionDraft,
                        onValueChange = { onMissionDraftChanged(it.take(6_000)) },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 128.dp),
                        placeholder = { Text("Find opportunities, build an app, investigate a question…") },
                        minLines = 3,
                        maxLines = 7,
                        shape = MaterialTheme.shapes.medium
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("HOW SHOULD THE WORK HAPPEN?", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimaryContainer, letterSpacing = 1.0.sp)
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            MissionMode.entries.forEach { mode ->
                                FilterChip(
                                    selected = currentMode == mode,
                                    onClick = { onModeChanged(mode) },
                                    label = { Text(mode.label) }
                                )
                            }
                        }
                        Text(currentMode.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Icon(Icons.Outlined.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(16.dp))
                        Text(
                            "$contextCount saved sources available · nothing is shared until you choose a destination",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                    Button(
                        onClick = { onStartMission(missionDraft.trim()) },
                        enabled = missionDraft.isNotBlank(),
                        modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)
                    ) {
                        Icon(Icons.Outlined.ArrowForward, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Start mission")
                    }
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("Your missions", style = MaterialTheme.typography.titleLarge)
                    Text("Pick up a thread without rebuilding its context.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (missions.isNotEmpty()) Text("${missions.size}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            }
        }
        if (missions.isEmpty()) {
            item {
                EmptyState(
                    icon = Icons.Outlined.AccountTree,
                    title = "Your first mission starts here",
                    body = "A mission keeps the original goal, chosen context and returned model work together. Nothing runs behind your back."
                )
            }
        } else {
            items(missions.take(6), key = { "mission-${it.id}" }) { mission ->
                MissionListCard(
                    mission = mission,
                    responseCount = workspace.items.count { it.relatedToId == mission.id && it.sourceLabel != LocalAiPromptComposer.USER_SOURCE && it.sourceLabel != LocalAiPromptComposer.ASSISTANT_SOURCE },
                    onClick = { onOpenMission(mission) }
                )
            }
        }
        if (externalSessions.isNotEmpty()) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("Tracked external sessions", style = MaterialTheme.typography.titleLarge)
                        Text("Prompts and imported chat context stay linked to their mission.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text("${externalSessions.size}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                }
            }
            items(externalSessions, key = { "external-session-${it.id}" }) { session ->
                val linkedMission = missions.firstOrNull { it.id == session.relatedToId }
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    shape = MaterialTheme.shapes.large
                ) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text(session.title, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(session.sourceLabel, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        Text(session.content.replace(Regex("\\s+"), " "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Updated ${formatDate(session.updatedAt)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                            TextButton(onClick = { if (linkedMission != null) onOpenMission(linkedMission) else onOpenLibrary() }) {
                                Text(if (linkedMission != null) "Continue session" else "Open source")
                            }
                        }
                    }
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("Recently captured", style = MaterialTheme.typography.titleLarge)
                    Text("Sources and notes you can bring into a mission.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                TextButton(onClick = onOpenLibrary) { Text("Library") }
            }
        }
        if (recentSources.isEmpty()) {
            item {
                EmptyState(
                    icon = Icons.Outlined.BookmarkBorder,
                    title = "Bring useful context in",
                    body = "Use Android Share from a webpage or AI conversation, or capture a thought here. Originals are kept for later use."
                )
            }
        } else {
            items(recentSources, key = { "recent-${it.id}" }) { capture ->
                CaptureCard(capture, onClick = { onNotify("Open Library to edit or select this source for a mission."); onOpenLibrary() })
            }
        }
        item { Spacer(Modifier.height(4.dp)) }
    }
}

@Composable
private fun MissionListCard(mission: Capture, responseCount: Int, onClick: () -> Unit) {
    val mode = MissionMode.fromStored(mission.missionMode)
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().animateContentSize(tween(180)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        shape = MaterialTheme.shapes.large
    ) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(42.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Outlined.AccountTree, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(mission.title, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(mission.content.replace(Regex("\\s+"), " "), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text(mode.label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    Text("·", color = MaterialTheme.colorScheme.outline)
                    Text("$responseCount returns", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("·", color = MaterialTheme.colorScheme.outline)
                    Text(formatDate(mission.updatedAt), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Icon(Icons.Outlined.ArrowForward, contentDescription = "Open mission", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

@Composable
private fun MissionWorkspaceScreen(
    mission: Capture,
    workspace: WorkspaceState,
    modelFile: File,
    localAiRuntime: LocalAiRuntime,
    localModelInstalled: Boolean,
    workScope: CoroutineScope,
    onOpenModelSettings: () -> Unit,
    captureDraft: String,
    captureSource: String,
    onCaptureDraftChanged: (String) -> Unit,
    onSaveResponse: () -> Unit,
    onModeChanged: (MissionMode) -> Unit,
    onOpenContextPicker: () -> Unit,
    onOpenLibrary: () -> Unit,
    onBack: () -> Unit,
    onEditCapture: (Capture) -> Unit,
    onNotify: (String) -> Unit
) {
    val context = LocalContext.current
    val mode = MissionMode.fromStored(mission.missionMode)
    val contextItems = workspace.items.filter { it.id in mission.contextIds && it.id != mission.id && it.status != CaptureStatus.ARCHIVED }
    val externalSessions = workspace.items.filter { it.relatedToId == mission.id && it.sourceLabel.startsWith("External session") }.sortedByDescending { it.updatedAt }
    val responses = workspace.items.filter {
        it.relatedToId == mission.id &&
            it.sourceLabel != LocalAiPromptComposer.USER_SOURCE &&
            it.sourceLabel != LocalAiPromptComposer.ASSISTANT_SOURCE &&
            !it.sourceLabel.startsWith("External session")
    }.sortedByDescending { it.updatedAt }
    val workstreams = PromptComposer.workstreams(mode)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                IconButton(onClick = onBack, modifier = Modifier.size(44.dp)) { Icon(Icons.Outlined.ArrowBack, contentDescription = "Back to all work") }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("SYNTHOS · MISSION", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, letterSpacing = 1.4.sp)
                    Text("Working thread", style = MaterialTheme.typography.titleLarge)
                }
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer) {
                    Icon(Icons.Outlined.Lock, contentDescription = "Private local workspace", tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.padding(10.dp).size(17.dp))
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("THE GOAL", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 1.3.sp)
                Text(mission.title, style = MaterialTheme.typography.headlineLarge)
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    shape = MaterialTheme.shapes.large
                ) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(mission.content, style = MaterialTheme.typography.bodyLarge)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Created ${formatDate(mission.createdAt)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                            TextButton(onClick = { onEditCapture(mission) }) { Text("Edit goal") }
                        }
                    }
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Collaboration strategy", style = MaterialTheme.typography.titleLarge)
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MissionMode.entries.forEach { option ->
                        FilterChip(selected = mode == option, onClick = { onModeChanged(option) }, label = { Text(option.label) })
                    }
                }
                Text(mode.description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                shape = MaterialTheme.shapes.large
            ) {
                Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Outlined.AccountTree, contentDescription = null, tint = MaterialTheme.colorScheme.onSecondaryContainer)
                        Text("Context for this mission", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSecondaryContainer, modifier = Modifier.weight(1f))
                        Text("${contextItems.size}", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSecondaryContainer)
                    }
                    Text(
                        if (contextItems.isEmpty()) "No library items are being sent. Choose only the sources this work actually needs."
                        else contextItems.joinToString(" · ") { it.title }.take(240),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                    OutlinedButton(onClick = onOpenContextPicker, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
                        Icon(Icons.Outlined.BookmarkBorder, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (contextItems.isEmpty()) "Choose context" else "Manage selected context")
                    }
                }
            }
        }
        item {
            LocalAiChatPanel(
                mission = mission,
                workspace = workspace,
                modelFile = modelFile,
                runtime = localAiRuntime,
                modelInstalled = localModelInstalled,
                contextItems = contextItems,
                workScope = workScope,
                onOpenSettings = onOpenModelSettings,
                onNotify = onNotify
            )
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("Start an external session", style = MaterialTheme.typography.titleLarge)
                Text(
                    "SynthOS saves the brief to this mission first, then opens Android's system destination chooser. The app you select is recorded on return; replies can be shared back into the same mission.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        items(workstreams, key = { "workstream-${mission.id}-${it.id}" }) { stream ->
            WorkstreamCard(
                definition = stream,
                onSend = {
                    runCatching { PromptComposer.composeMissionBrief(mission, contextItems, mode, stream) }
                        .onSuccess { packet ->
                            val tracked = workspace.addCapture(
                                packet,
                                CaptureKind.REFERENCE,
                                "External session · ${stream.title}",
                                relatedToId = mission.id,
                                missionMode = mode.name
                            )
                            if (tracked != null) {
                                shareTextToApp(context, "SynthOS · ${mission.title.take(100)} · ${stream.title}", packet, tracked.id, onNotify)
                            } else onNotify(workspace.operationMessage ?: "The external session couldn't be saved.")
                        }
                        .onFailure { onNotify(it.message ?: "This handoff couldn't be prepared.") }
                }
            )
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("Tracked external sessions", style = MaterialTheme.typography.titleLarge)
                    Text("Handoffs and imported chat transcripts remain attached to this mission and are available as context when you continue locally.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text("${externalSessions.size}", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            }
        }
        if (externalSessions.isEmpty()) {
            item {
                Text("No external sessions yet. Prepare a handoff below or share an existing conversation into SynthOS and choose Make a mission.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            items(externalSessions, key = { "tracked-session-${it.id}" }) { session ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    shape = MaterialTheme.shapes.large
                ) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Outlined.Forum, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Column(Modifier.weight(1f)) {
                                Text(session.title, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text("${session.sourceLabel} · ${formatDate(session.updatedAt)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Text(session.content.replace(Regex("\\s+"), " "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        TextButton(onClick = { onEditCapture(session) }, modifier = Modifier.align(Alignment.End)) { Text("Inspect / edit session context") }
                    }
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("Returned work", style = MaterialTheme.typography.titleLarge)
                    Text("Responses stay linked to their original mission.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text("${responses.size}", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            }
        }
        if (responses.isEmpty()) {
            item {
                EmptyState(
                    icon = Icons.Outlined.Forum,
                    title = "No responses yet",
                    body = "Send a specialist brief, work in that AI app, then use Android Share to bring its response back here. Review it before saving."
                )
            }
        } else {
            items(responses, key = { "response-${it.id}" }) { response ->
                Card(
                    onClick = { onEditCapture(response) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    shape = MaterialTheme.shapes.large
                ) {
                    Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Outlined.Forum, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Column(Modifier.weight(1f)) {
                                Text(response.title, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text("Captured ${formatDate(response.createdAt)} · original preserved", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Text(response.content.replace(Regex("\\s+"), " "), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 4, overflow = TextOverflow.Ellipsis)
                        TextButton(onClick = { onEditCapture(response) }, modifier = Modifier.align(Alignment.End)) { Text("Inspect source") }
                    }
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if ((captureSource == "External app share" || captureSource == "Floating capture") && captureDraft.isNotBlank()) "Review returned session material" else "Bring a response back", style = MaterialTheme.typography.titleLarge)
                Text(
                    if ((captureSource == "External app share" || captureSource == "Floating capture") && captureDraft.isNotBlank()) "This shared content will be attached to the active mission as a tracked external-session event when you save it."
                    else "Paste a response here, or share content from another app into SynthOS and return to this mission.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = captureDraft,
                    onValueChange = onCaptureDraftChanged,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp),
                    placeholder = { Text("Paste model output, findings or a decision…") },
                    minLines = 3,
                    maxLines = 9,
                    shape = MaterialTheme.shapes.large
                )
                Button(onClick = onSaveResponse, enabled = captureDraft.isNotBlank(), modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp)) {
                    Icon(Icons.Outlined.BookmarkBorder, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Save and link to mission")
                }
                OutlinedButton(onClick = onOpenLibrary, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
                    Icon(Icons.Outlined.Search, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Browse the connected library")
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
}

@Composable
private fun LocalAiChatPanel(
    mission: Capture,
    workspace: WorkspaceState,
    modelFile: File,
    runtime: LocalAiRuntime,
    modelInstalled: Boolean,
    contextItems: List<Capture>,
    workScope: CoroutineScope,
    onOpenSettings: () -> Unit,
    onNotify: (String) -> Unit
) {
    var question by rememberSaveable(mission.id) { mutableStateOf("") }
    val runtimeState by runtime.state.collectAsState()
    val sending = runtimeState.isGenerating && runtimeState.missionId == mission.id
    val anotherMissionBusy = runtimeState.isGenerating && runtimeState.missionId != mission.id
    val replyPreview = runtimeState.preview.takeIf { runtimeState.missionId == mission.id }.orEmpty()
    val generationError = runtimeState.error.takeIf { runtimeState.missionId == mission.id }
    val chatItems = workspace.items
        .filter { it.relatedToId == mission.id && (it.sourceLabel == LocalAiPromptComposer.USER_SOURCE || it.sourceLabel == LocalAiPromptComposer.ASSISTANT_SOURCE) }
        .sortedBy { it.createdAt }

    Card(
        modifier = Modifier.fillMaxWidth().animateContentSize(tween(180)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        shape = MaterialTheme.shapes.large
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(42.dp)) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Outlined.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(22.dp))
                    }
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("Talk to SynthOS", style = MaterialTheme.typography.titleLarge)
                    Text("Private, on-device coordinator", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surfaceVariant) {
                    Text(if (modelInstalled) "LOCAL" else "SETUP", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            if (!modelInstalled) {
                Text("Import a compatible .litertlm model in Settings to enable local chat. SynthOS won't send this mission to a cloud model. You can still prepare specialist handoffs below and bring their answers back here.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedButton(onClick = onOpenSettings, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
                    Icon(Icons.Outlined.Settings, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Set up local model")
                }
            } else {
                Text("SynthOS sees the mission goal, selected sources and returned specialist work below. It can help compare answers and plan the next round. First use may take several seconds while the model loads.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (anotherMissionBusy) {
                    Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = MaterialTheme.shapes.medium) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            Text("SynthOS is still working on another mission. Its conversation will remain saved there.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSecondaryContainer)
                        }
                    }
                }
                if (chatItems.isEmpty()) {
                    Text("No local conversation yet. Ask a question, or bring external model results into this mission first.", style = MaterialTheme.typography.bodyMedium)
                }
                chatItems.takeLast(10).forEach { item ->
                    val fromUser = item.sourceLabel == LocalAiPromptComposer.USER_SOURCE
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (fromUser) Arrangement.End else Arrangement.Start) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(0.94f),
                            shape = MaterialTheme.shapes.medium,
                            color = if (fromUser) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(if (fromUser) "YOU" else "SYNTHOS · LOCAL", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 0.8.sp)
                                Text(item.content, style = MaterialTheme.typography.bodyMedium)
                                if (!fromUser) Text("Saved to this mission", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
                if (sending) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = MaterialTheme.shapes.medium,
                        color = MaterialTheme.colorScheme.secondaryContainer
                    ) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                CircularProgressIndicator(modifier = Modifier.size(17.dp), strokeWidth = 2.dp)
                                Text(if (replyPreview.isBlank()) "Loading or reasoning locally…" else "SynthOS is responding", style = MaterialTheme.typography.labelMedium)
                            }
                            if (replyPreview.isNotBlank()) Text(replyPreview, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
                generationError?.let { error ->
                    Surface(color = MaterialTheme.colorScheme.errorContainer, shape = MaterialTheme.shapes.medium) {
                        Text(error, modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer)
                    }
                }
                OutlinedTextField(
                    value = question,
                    onValueChange = { question = it.take(3_000) },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 100.dp),
                    enabled = !runtimeState.isGenerating,
                    placeholder = { Text("Ask SynthOS to compare the answers, challenge an assumption, or suggest the next move…") },
                    minLines = 3,
                    maxLines = 6,
                    shape = MaterialTheme.shapes.medium
                )
                Button(
                    onClick = {
                        val userMessage = question.trim()
                        val previousChat = chatItems
                        val history = LocalAiPromptComposer.history(previousChat)
                        val savedQuestion = workspace.addCapture(
                            userMessage,
                            CaptureKind.IDEA,
                            LocalAiPromptComposer.USER_SOURCE,
                            relatedToId = mission.id
                        )
                        if (savedQuestion == null) {
                            onNotify(workspace.operationMessage ?: "The message could not be saved.")
                        } else {
                            question = ""
                            workScope.launch {
                                try {
                                    val returnedWork = workspace.items.filter { it.relatedToId == mission.id }
                                    val systemInstruction = LocalAiPromptComposer.systemInstruction(mission, contextItems, returnedWork)
                                    var generatedText = ""
                                    runtime.streamReply(modelFile, mission.id, systemInstruction, history, userMessage).collect { current ->
                                        generatedText = current
                                    }
                                    val finalAnswer = generatedText.trim()
                                    if (finalAnswer.isBlank()) error("The local model returned no text. Check the model file and device memory, then try again.")
                                    val savedAnswer = workspace.addCapture(
                                        finalAnswer,
                                        CaptureKind.RESEARCH,
                                        LocalAiPromptComposer.ASSISTANT_SOURCE,
                                        relatedToId = mission.id
                                    )
                                    if (savedAnswer == null) error(workspace.operationMessage ?: "The response couldn't be saved securely.")
                                    onNotify("Local reply saved to this mission.")
                                } catch (cancelled: CancellationException) {
                                    throw cancelled
                                } catch (error: Exception) {
                                    onNotify(error.message ?: "Local reply failed. The question remains saved in this mission.")
                                }
                            }
                        }
                    },
                    enabled = question.isNotBlank() && !runtimeState.isGenerating,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp)
                ) {
                    Icon(Icons.Outlined.ArrowForward, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (sending) "Generating locally…" else if (anotherMissionBusy) "Local model is busy" else "Ask SynthOS locally")
                }
            }
        }
    }
}

@Composable
private fun WorkstreamCard(definition: WorkstreamDefinition, onSend: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().animateContentSize(tween(180)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        shape = MaterialTheme.shapes.large
    ) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(11.dp)) {
                Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(42.dp)) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(definition.id.take(1).uppercase(), style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.SemiBold)
                    }
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(definition.title, style = MaterialTheme.typography.titleMedium)
                    Text(definition.subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surfaceVariant) {
                    Icon(Icons.Outlined.Forum, contentDescription = "External session", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(8.dp).size(16.dp))
                }
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Saved before handoff", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                TextButton(onClick = onSend, modifier = Modifier.heightIn(min = 48.dp)) {
                    Text("Choose destination")
                    Spacer(Modifier.width(5.dp))
                    Icon(Icons.Outlined.ArrowForward, contentDescription = null, modifier = Modifier.size(17.dp))
                }
            }
        }
    }
}

@Composable
private fun QuickCaptureDialog(onDismiss: () -> Unit, onSave: (String, CaptureKind) -> Unit) {
    var content by rememberSaveable { mutableStateOf("") }
    var kindName by rememberSaveable { mutableStateOf(CaptureKind.IDEA.name) }
    val kind = CaptureKind.entries.firstOrNull { it.name == kindName } ?: CaptureKind.IDEA
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Outlined.BookmarkBorder, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
        title = { Text("Capture a thought") },
        text = {
            Column(Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it.take(50_000) },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp),
                    placeholder = { Text("A note, a decision, a useful URL…") },
                    minLines = 3,
                    maxLines = 8
                )
                Text("Type", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CaptureKind.entries.forEach { option ->
                        FilterChip(selected = kind == option, onClick = { kindName = option.name }, label = { Text(option.label) })
                    }
                }
                Text("Saved only on this device. Nothing is sent to an AI app automatically.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = { Button(onClick = { onSave(content, kind) }, enabled = content.isNotBlank()) { Text("Save locally") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun ContextPickerDialog(
    workspace: WorkspaceState,
    mission: Capture,
    onDismiss: () -> Unit,
    onNotify: (String) -> Unit
) {
    val available = workspace.items.filter {
        it.id != mission.id && (it.relatedToId != mission.id || it.id in mission.contextIds) && it.status != CaptureStatus.ARCHIVED
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Choose mission context") },
        text = {
            Column(Modifier.heightIn(max = 470.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Only checked items will be included in specialist handoffs. Choose up to ${PromptComposer.MAX_SELECTED_ITEMS} sources.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (available.isEmpty()) {
                    Text("Your library is empty. Share a source into SynthOS or capture a note first.", style = MaterialTheme.typography.bodyMedium)
                }
                available.forEach { item ->
                    val checked = item.id in mission.contextIds
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Checkbox(checked = checked, onCheckedChange = { next ->
                            val current = mission.contextIds
                            if (next && !checked && current.size >= PromptComposer.MAX_SELECTED_ITEMS) {
                                onNotify("Select up to ${PromptComposer.MAX_SELECTED_ITEMS} context items.")
                            } else {
                                val updatedLinks = if (next) (current + item.id).distinct() else current - item.id
                                if (!workspace.update(mission.copy(contextIds = updatedLinks))) {
                                    onNotify(workspace.operationMessage ?: "The context selection could not be saved.")
                                }
                            }
                        })
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(item.title, style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text("${item.kind.label} · ${item.sourceLabel}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        },
        confirmButton = { Button(onClick = onDismiss) { Text("Use selected context") } },
        dismissButton = { TextButton(onClick = {
            if (workspace.update(mission.copy(contextIds = emptyList()))) onDismiss()
            else onNotify(workspace.operationMessage ?: "The context selection could not be cleared.")
        }) { Text("Clear all") } }
    )
}

@Composable
private fun BrandHeader(onQuickCapture: (() -> Unit)? = null) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Surface(shape = MaterialTheme.shapes.small, color = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp)) {
            Box(contentAlignment = Alignment.Center) {
                Text("S", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold)
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
            Text("SynthOS", style = MaterialTheme.typography.titleLarge)
            Text("PERSONAL INTELLIGENCE", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 1.1.sp)
        }
        Spacer(Modifier.weight(1f))
        if (onQuickCapture != null) {
            IconButton(onClick = onQuickCapture, modifier = Modifier.size(48.dp)) {
                Icon(Icons.Outlined.BookmarkBorder, contentDescription = "Capture a thought", tint = MaterialTheme.colorScheme.primary)
            }
        }
        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer) {
            Row(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                Icon(Icons.Outlined.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(14.dp))
                Text("On device", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
            }
        }
    }
}

@Composable
private fun LibraryScreen(workspace: WorkspaceState, onEdit: (Capture) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    var selectedStatus by rememberSaveable { mutableStateOf("All") }
    val statuses = listOf("All") + CaptureStatus.entries.map { it.label }
    val filtered = workspace.items.filter { capture ->
        val matchesQuery = query.isBlank() || listOf(capture.title, capture.content, capture.sourceLabel, capture.kind.label).any { it.contains(query, ignoreCase = true) }
        val matchesStatus = selectedStatus == "All" || capture.status.label == selectedStatus
        matchesQuery && matchesStatus
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            PageHeader("Library", "Find the source, idea or decision you saved.")
        }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it.take(300) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                placeholder = { Text("Search titles, notes and sources") },
                shape = MaterialTheme.shapes.large
            )
        }
        item {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                statuses.forEach { status ->
                    FilterChip(selected = selectedStatus == status, onClick = { selectedStatus = status }, label = { Text(status) })
                }
            }
        }
        item { Text("${filtered.size} item${if (filtered.size == 1) "" else "s"}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        if (filtered.isEmpty()) {
            item {
                EmptyState(
                    icon = if (query.isBlank()) Icons.Outlined.MenuBook else Icons.Outlined.Search,
                    title = if (query.isBlank()) "Nothing here yet" else "No matches",
                    body = if (query.isBlank()) "Capture something on Today, or share selected text from any app." else "Try a shorter search or another status filter."
                )
            }
        }
        items(filtered, key = { it.id }) { capture -> CaptureCard(capture, onClick = { onEdit(capture) }) }
    }
}

@Composable
private fun RadioDot(selected: Boolean) {
    Surface(
        shape = CircleShape,
        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
        border = if (selected) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.size(20.dp)
    ) {
        if (selected) Box(Modifier.padding(5.dp), contentAlignment = Alignment.Center) {
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(10.dp)) {}
        }
    }
}

@Composable
private fun SettingsScreen(
    themeMode: ThemeMode,
    onThemeModeChanged: (ThemeMode) -> Unit,
    localModelInstalled: Boolean,
    activeModelId: String,
    installedModelIds: Set<String>,
    modelImporting: Boolean,
    downloadingModelId: String?,
    downloadPercent: Int,
    downloadedBytes: Long,
    totalBytes: Long,
    floatingCaptureEnabled: Boolean,
    customModelInstalled: Boolean,
    onFloatingCaptureChanged: (Boolean) -> Unit,
    onDownloadModel: (ModelOption) -> Unit,
    onCancelDownload: () -> Unit,
    onSelectModel: (String) -> Unit,
    onImportModel: () -> Unit,
    onRemoveModel: (String) -> Unit,
    onExport: () -> Unit,
    onImport: () -> Unit
) {
    val context = LocalContext.current
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        PageHeader("Settings", "Private by design. No account, ads or analytics.")
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(Icons.Outlined.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(26.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("Encrypted local workspace", style = MaterialTheme.typography.titleMedium)
                        Text("AES-256-GCM encryption with a non-exportable Android Keystore key. Biometric or device-lock authentication gates access.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(Icons.Outlined.CloudOff, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(26.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("Local-first, with explicit model downloads", style = MaterialTheme.typography.titleMedium)
                        Text("Internet is used when you choose to download model weights. Prompts and saved workspace data stay on-device unless you explicitly send or export them.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(Icons.Outlined.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(25.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("On-device AI model", style = MaterialTheme.typography.titleMedium)
                        Text(
                            if (localModelInstalled) "A local model file is installed in private app storage. The first message loads it into memory; speed depends on your device."
                            else "Download a model from the one-tap library below, or import a compatible .litertlm file. Weights are not bundled with the APK.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Text("Model files can be hundreds of megabytes or larger. Start with a small model compatible with your phone. Other formats such as GGUF or MediaPipe .task are not interchangeable with .litertlm.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (modelImporting) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        Text("Updating private model storage…", style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Button(onClick = onImportModel, enabled = !modelImporting, modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp)) {
                    Icon(Icons.Outlined.FileUpload, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Import a custom .litertlm file")
                }
                TextButton(onClick = {
                    runCatching {
                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://developers.google.com/edge/litert-lm/android")))
                    }.onFailure { /* The local chat remains usable without opening documentation. */ }
                }, modifier = Modifier.align(Alignment.Start)) { Text("Model format and runtime guide") }
            }
        }
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            shape = MaterialTheme.shapes.large
        ) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                Text("One-tap model library", style = MaterialTheme.typography.titleLarge)
                Text("Choose Download & use once. SynthOS downloads the ready-to-run LiteRT-LM file directly into private storage and selects it automatically. These public Qwen models use the Apache 2.0 license.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                ModelCatalog.options.forEach { option ->
                    val installed = option.id in installedModelIds
                    val isDownloading = downloadingModelId == option.id
                    Column(verticalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                        Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Icon(Icons.Outlined.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 2.dp).size(23.dp))
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(option.name, style = MaterialTheme.typography.titleMedium)
                                Text("${option.sizeLabel} · ${option.recommendation}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                Text(option.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                if (isDownloading) {
                                    Text(
                                        if (totalBytes > 0L) "Downloading $downloadPercent% · ${formatBytes(downloadedBytes)} of ${formatBytes(totalBytes)}" else "Downloading · ${formatBytes(downloadedBytes)} received",
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                    if (downloadPercent in 1..99) androidx.compose.material3.LinearProgressIndicator(progress = downloadPercent / 100f, modifier = Modifier.fillMaxWidth()) else androidx.compose.material3.LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                                }
                            }
                        }
                        when {
                            isDownloading -> OutlinedButton(onClick = onCancelDownload, modifier = Modifier.fillMaxWidth().heightIn(min = 46.dp)) { Text("Cancel download") }
                            installed && activeModelId == option.id -> Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.secondaryContainer) {
                                    Text("Selected for local chat", modifier = Modifier.fillMaxWidth().padding(12.dp), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSecondaryContainer)
                                }
                                TextButton(onClick = { onRemoveModel(option.id) }, enabled = !modelImporting, modifier = Modifier.align(Alignment.End)) { Text("Remove stored model") }
                            }
                            installed -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                OutlinedButton(onClick = { onSelectModel(option.id) }, enabled = !modelImporting, modifier = Modifier.weight(1f).heightIn(min = 46.dp)) { Text("Use installed model") }
                                TextButton(onClick = { onRemoveModel(option.id) }, enabled = !modelImporting) { Text("Remove") }
                            }
                            else -> Button(onClick = { onDownloadModel(option) }, enabled = downloadingModelId == null && !modelImporting, modifier = Modifier.fillMaxWidth().heightIn(min = 46.dp)) {
                                Icon(Icons.Outlined.FileDownload, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text("Download & use")
                            }
                        }
                    }
                    if (option != ModelCatalog.options.last()) HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                }
                if (customModelInstalled) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(Icons.Outlined.FileUpload, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(23.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("Custom imported model", style = MaterialTheme.typography.titleMedium)
                            Text(if (activeModelId == ModelCatalog.CUSTOM_ID) "Selected for local chat" else "Installed in private app storage", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    if (activeModelId == ModelCatalog.CUSTOM_ID) {
                        TextButton(onClick = { onRemoveModel(ModelCatalog.CUSTOM_ID) }, enabled = !modelImporting, modifier = Modifier.align(Alignment.End)) { Text("Remove custom model") }
                    } else {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedButton(onClick = { onSelectModel(ModelCatalog.CUSTOM_ID) }, enabled = !modelImporting, modifier = Modifier.weight(1f).heightIn(min = 46.dp)) { Text("Use custom model") }
                            TextButton(onClick = { onRemoveModel(ModelCatalog.CUSTOM_ID) }, enabled = !modelImporting) { Text("Remove") }
                        }
                    }
                }
                Text("A model may need 1–3 GB of free memory while generating, even when the file itself is smaller. Actual speed and compatibility depend on the phone. Downloads can use hundreds of MB of mobile data.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            shape = MaterialTheme.shapes.large
        ) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Outlined.BookmarkBorder, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(26.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Floating capture bubble", style = MaterialTheme.typography.titleMedium)
                    Text("Keep a small SynthOS bubble above other apps. Tap it to bring copied text into SynthOS for review, or open quick capture. Nothing is saved automatically.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Android will ask for ‘Display over other apps’ permission. On Android 13+, allow notifications too so the ongoing Stop bubble action stays visible. You can turn the feature off here or from its notification.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = floatingCaptureEnabled, onCheckedChange = onFloatingCaptureChanged)
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Appearance", style = MaterialTheme.typography.titleLarge)
            Text("Choose how SynthOS looks on this device.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemeMode.entries.forEach { mode ->
                    FilterChip(
                        modifier = Modifier.weight(1f),
                        selected = themeMode == mode,
                        onClick = { onThemeModeChanged(mode) },
                        label = { Text(mode.label) }
                    )
                }
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Backup and restore", style = MaterialTheme.typography.titleLarge)
            Text("Backups are portable JSON. Import adds only items whose IDs are not already in your workspace.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(onClick = onExport, modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp)) {
                Icon(Icons.Outlined.FileDownload, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Export backup")
            }
            OutlinedButton(onClick = onImport, modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp)) {
                Icon(Icons.Outlined.FileUpload, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Restore from backup")
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
                Icon(Icons.Outlined.PhoneAndroid, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Built for your workflow", style = MaterialTheme.typography.titleMedium)
                    Text("Capture from any app, search your own context, and prepare research or challenge briefs for the AI tools you already use. No API key or subscription is required.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Text("SynthOS · 1.5.0", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun CaptureEditorDialog(
    capture: Capture,
    onDismiss: () -> Unit,
    onSave: (Capture) -> Unit,
    onDelete: (String) -> Unit,
    onAttachToMission: (Capture) -> Unit
) {
    var title by remember(capture.id) { mutableStateOf(capture.title) }
    var content by remember(capture.id) { mutableStateOf(capture.content) }
    var kind by remember(capture.id) { mutableStateOf(capture.kind) }
    var status by remember(capture.id) { mutableStateOf(capture.status) }
    var confirmDelete by remember(capture.id) { mutableStateOf(false) }
    var validationError by remember(capture.id) { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit item") },
        text = {
            Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it.take(180) }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth(), singleLine = false)
                if (capture.originalContent != null && capture.originalContent != capture.content) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                        shape = MaterialTheme.shapes.medium
                    ) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("Original source · preserved", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSecondaryContainer)
                            Text(capture.originalContent, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSecondaryContainer)
                            Text("Edits change the working copy, not the original capture.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSecondaryContainer)
                        }
                    }
                }
                OutlinedTextField(value = content, onValueChange = { content = it.take(50_000) }, label = { Text("Working copy") }, modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp), minLines = 4, maxLines = 12)
                if (capture.attachments.isNotEmpty()) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Saved attachments", style = MaterialTheme.typography.titleSmall)
                        capture.attachments.forEach { attachment ->
                            Column(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(attachment.fileName, style = MaterialTheme.typography.bodyMedium)
                                Text("${attachment.mimeType} · ${formatBytes(attachment.byteLength)} · stored in encrypted workspace", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
                Text("Type", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CaptureKind.entries.forEach { option -> FilterChip(selected = kind == option, onClick = { kind = option }, label = { Text(option.label) }) }
                }
                Text("Status", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CaptureStatus.entries.forEach { option -> FilterChip(selected = status == option, onClick = { status = option }, label = { Text(option.label) }) }
                }
                Text("Source: ${capture.sourceLabel}${capture.sourceUrl?.let { " · $it" } ?: ""}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Created ${formatDate(capture.createdAt)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (validationError != null) Text(validationError!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (capture.sourceLabel != "SynthOS mission") {
                    TextButton(
                        enabled = status != CaptureStatus.ARCHIVED,
                        onClick = {
                            if (title.isBlank() || content.isBlank()) validationError = "Add a title and some content before attaching."
                            else onAttachToMission(capture.copy(title = title.trim(), content = content.trim(), kind = kind, status = status))
                        }
                    ) { Text("Attach to mission") }
                }
                Button(onClick = {
                    if (title.isBlank() || content.isBlank()) validationError = "Add a title and some content before saving."
                    else onSave(capture.copy(title = title.trim(), content = content.trim(), kind = kind, status = status))
                }) { Text("Save changes") }
            }
        },
        dismissButton = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { confirmDelete = true }, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Outlined.DeleteOutline, contentDescription = "Delete item", tint = MaterialTheme.colorScheme.error)
                }
                TextButton(onClick = onDismiss) { Text("Close") }
            }
        }
    )
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            icon = { Icon(Icons.Outlined.DeleteOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("Delete this item?") },
            text = { Text("This permanently removes the item from the encrypted workspace. Export a backup first if you may need it later.") },
            confirmButton = { Button(onClick = { confirmDelete = false; onDelete(capture.id) }) { Text("Delete permanently") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Keep item") } }
        )
    }
}

@Composable
private fun AttachSourceToMissionDialog(
    source: Capture,
    missions: List<Capture>,
    onDismiss: () -> Unit,
    onAttach: (Capture) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Attach source to a mission") },
        text = {
            Column(
                Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    "${source.title} stays in your library. Choose a mission to add it as selected context; an Inbox source becomes Active.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (missions.isEmpty()) {
                    EmptyState(
                        icon = Icons.Outlined.AccountTree,
                        title = "No missions yet",
                        body = "Create a mission from the Work screen first. Your source is already saved; nothing has been lost."
                    )
                } else {
                    missions.sortedByDescending { it.updatedAt }.take(30).forEach { mission ->
                        Card(
                            onClick = { onAttach(mission) },
                            modifier = Modifier.fillMaxWidth(),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(mission.title, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "${mission.contextIds.size}/8 sources linked · ${mission.status.label}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                    if (missions.size > 30) Text("Showing the 30 most recently updated missions.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
private fun CaptureCard(capture: Capture, onClick: () -> Unit) {
    val darkSurface = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val statusTint = when (capture.status) {
        CaptureStatus.DONE -> if (darkSurface) SynthSemantic.successDark else SynthSemantic.successLight
        CaptureStatus.ACTIVE -> if (darkSurface) SynthSemantic.infoDark else SynthSemantic.infoLight
        CaptureStatus.ARCHIVED -> MaterialTheme.colorScheme.onSurfaceVariant
        CaptureStatus.INBOX -> MaterialTheme.colorScheme.primary
    }
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
            Surface(shape = MaterialTheme.shapes.small, color = MaterialTheme.colorScheme.secondaryContainer, modifier = Modifier.size(40.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(kindIcon(capture.kind), contentDescription = capture.kind.label, tint = MaterialTheme.colorScheme.onSecondaryContainer, modifier = Modifier.size(21.dp))
                }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(capture.title, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(capture.content.replace(Regex("\\s+"), " "), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(capture.kind.label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    Text("·", color = MaterialTheme.colorScheme.outline)
                    Text(capture.status.label, style = MaterialTheme.typography.labelSmall, color = statusTint)
                    Text("·", color = MaterialTheme.colorScheme.outline)
                    Text(formatDate(capture.updatedAt), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (capture.sourceUrl != null) Text(capture.sourceUrl, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (capture.attachments.isNotEmpty()) {
                    Text("${capture.attachments.size} attachment${if (capture.attachments.size == 1) "" else "s"} · ${capture.attachments.joinToString { it.fileName }}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
private fun PageHeader(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(bottom = 4.dp)) {
        Text(title, style = MaterialTheme.typography.headlineLarge)
        Text(subtitle, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun EmptyState(icon: ImageVector, title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 26.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(30.dp))
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun kindIcon(kind: CaptureKind): ImageVector = when (kind) {
    CaptureKind.IDEA -> Icons.Outlined.Lightbulb
    CaptureKind.RESEARCH -> Icons.Outlined.Search
    CaptureKind.TASK -> Icons.Outlined.TaskAlt
    CaptureKind.REFERENCE -> Icons.Outlined.MenuBook
    CaptureKind.DECISION -> Icons.Outlined.CheckCircleOutline
}

@Composable
private fun warningSemanticColor() = if (MaterialTheme.colorScheme.background.luminance() < 0.5f) SynthSemantic.warningDark else SynthSemantic.warningLight

private fun formatBytes(bytes: Long): String = when {
    bytes >= 1024L * 1024L * 1024L -> "%.2f GB".format(bytes / (1024.0 * 1024.0 * 1024.0))
    bytes >= 1024L * 1024L -> "%.0f MB".format(bytes / (1024.0 * 1024.0))
    bytes >= 1024L -> "%.0f KB".format(bytes / 1024.0)
    else -> "$bytes B"
}

private fun formatDate(timestamp: Long): String = try {
    DateTimeFormatter.ofPattern("d MMM yyyy").withZone(ZoneId.systemDefault()).format(Instant.ofEpochMilli(timestamp))
} catch (_: Exception) { "Saved" }

private fun copyModelBounded(input: InputStream, output: FileOutputStream): Long {
    val maximumBytes = 4L * 1024L * 1024L * 1024L
    val buffer = ByteArray(1024 * 1024)
    var copied = 0L
    while (true) {
        val read = input.read(buffer)
        if (read < 0) break
        copied += read.toLong()
        require(copied <= maximumBytes) { "Model files larger than 4 GB are not accepted by this importer." }
        output.write(buffer, 0, read)
    }
    output.flush()
    return copied
}

private fun readBoundedText(input: InputStream, limit: Int): String {
    val output = ByteArrayOutputStream()
    val buffer = ByteArray(8192)
    var total = 0
    while (true) {
        val read = input.read(buffer)
        if (read < 0) break
        total += read
        require(total <= limit) { "The selected file exceeds the 20 MB import limit." }
        output.write(buffer, 0, read)
    }
    return output.toString(Charsets.UTF_8.name())
}

private fun kotlinx.coroutines.CoroutineScope.launchInSnackbar(host: SnackbarHostState, message: String) {
    launch { host.showSnackbar(message) }
}
