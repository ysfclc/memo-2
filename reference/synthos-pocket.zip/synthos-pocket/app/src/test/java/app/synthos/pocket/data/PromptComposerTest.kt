package app.synthos.pocket.data

import org.junit.Assert.assertTrue
import org.junit.Assert.assertThrows
import org.junit.Test

class PromptComposerTest {
    private fun item(id: String, body: String = "A source note") = Capture(
        id = id,
        title = "Title $id",
        content = body,
        kind = CaptureKind.IDEA,
        status = CaptureStatus.INBOX,
        sourceLabel = "Quick capture",
        sourceUrl = null,
        createdAt = 1_700_000_000_000,
        updatedAt = 1_700_000_000_000
    )

    @Test
    fun briefContainsTheChosenModeAndSourceMetadata() {
        val prompt = PromptComposer.compose(listOf(item("a")), CouncilMode.CHALLENGE)
        assertTrue(prompt.contains("Task: Challenge"))
        assertTrue(prompt.contains("SOURCE 1: Title a"))
        assertTrue(prompt.contains("Captured via: Quick capture"))
        assertTrue(prompt.contains("Do not invent evidence"))
    }

    @Test
    fun emptySelectionIsRejected() {
        assertThrows(IllegalArgumentException::class.java) { PromptComposer.compose(emptyList(), CouncilMode.RESEARCH) }
    }

    @Test
    fun largeSourceIsExplicitlyTruncated() {
        val prompt = PromptComposer.compose(listOf(item("large", "x".repeat(3_500))), CouncilMode.SYNTHESIZE)
        assertTrue(prompt.contains("[Source excerpt truncated by SynthOS"))
    }

    @Test
    fun tooManySourcesAreRejected() {
        val items = (1..(PromptComposer.MAX_SELECTED_ITEMS + 1)).map { item(it.toString()) }
        assertThrows(IllegalArgumentException::class.java) { PromptComposer.compose(items, CouncilMode.PLAN) }
    }
    @Test
    fun missionHandoffIncludesRoleGoalAndOnlySelectedContext() {
        val mission = item("mission", "Build a useful job research workflow")
        val source = item("source", "A job listing from https://example.test/job")
        val brief = PromptComposer.composeMissionBrief(
            mission,
            listOf(source),
            MissionMode.COLLABORATE,
            PromptComposer.workstreams(MissionMode.COLLABORATE).first()
        )
        assertTrue(brief.contains("ROLE: Researcher"))
        assertTrue(brief.contains("Build a useful job research workflow"))
        assertTrue(brief.contains("SOURCE 1: Title source"))
        assertTrue(brief.contains("Do not claim to have opened a URL"))
    }

    @Test
    fun convergenceBriefDoesNotManufactureConsensus() {
        val mission = item("mission", "Choose an architecture")
        val brief = PromptComposer.composeMissionBrief(
            mission,
            emptyList(),
            MissionMode.CONVERGE,
            PromptComposer.workstreams(MissionMode.CONVERGE).last()
        )
        assertTrue(brief.contains("Do not manufacture consensus"))
        assertTrue(brief.contains("No additional saved sources were selected"))
    }

    @Test
    fun councilCanStartFromAQuestionWithoutPrivateLibraryContext() {
        val brief = PromptComposer.composeCouncilBrief("Compare two deployment approaches", emptyList(), MissionMode.COMPETE)
        assertTrue(brief.contains("Compare two deployment approaches"))
        assertTrue(brief.contains("No saved source material was selected"))
    }

}
