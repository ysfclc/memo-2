package app.synthos.pocket.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class CaptureCodecTest {
    private val sample = Capture(
        id = "capture-1",
        title = "Research local AI",
        content = "Compare local models and keep this URL: https://example.test/docs",
        kind = CaptureKind.RESEARCH,
        status = CaptureStatus.ACTIVE,
        sourceLabel = "Android share",
        sourceUrl = "https://example.test/docs",
        createdAt = 1_700_000_000_000,
        updatedAt = 1_700_000_000_100,
        originalContent = "Compare local models and keep this URL: https://example.test/docs"
    )

    @Test
    fun backupRoundTripPreservesAllFields() {
        val restored = CaptureCodec.decode(CaptureCodec.encode(listOf(sample)))
        assertEquals(listOf(sample), restored)
    }

    @Test
    fun emptyBackupIsValid() {
        assertEquals(emptyList<Capture>(), CaptureCodec.decode(CaptureCodec.encode(emptyList())))
    }

    @Test
    fun unknownSchemaIsRejected() {
        val backup = CaptureCodec.encode(listOf(sample)).replace("\"schemaVersion\": 3", "\"schemaVersion\": 999")
        assertThrows(IllegalArgumentException::class.java) { CaptureCodec.decode(backup) }
    }

    @Test
    fun duplicateIdsAreRejected() {
        assertThrows(IllegalArgumentException::class.java) { CaptureCodec.decode(CaptureCodec.encode(listOf(sample, sample))) }
    }

    @Test
    fun invalidJsonIsRejected() {
        assertThrows(IllegalArgumentException::class.java) { CaptureCodec.decode("not json") }
    }
    @Test
    fun backupRoundTripPreservesMissionLinksModeAndContextSelection() {
        val mission = sample.copy(id = "mission-1", missionMode = MissionMode.CONVERGE.name, contextIds = listOf("capture-1"))
        val response = sample.copy(id = "response-1", relatedToId = "mission-1")
        val restored = CaptureCodec.decode(CaptureCodec.encode(listOf(mission, response)))
        assertEquals(listOf(mission, response), restored)
    }


    @Test
    fun attachmentPayloadRoundTripPreservesOriginalBytesMetadata() {
        val attached = sample.copy(attachments = listOf(
            CaptureAttachment("file-1", "hello.txt", "text/plain", 3, "AQID")
        ))
        val restored = CaptureCodec.decode(CaptureCodec.encode(listOf(attached)))
        assertEquals(listOf(attached), restored)
    }

    @Test
    fun attachmentSizeMismatchIsRejected() {
        val attached = sample.copy(attachments = listOf(
            CaptureAttachment("file-1", "hello.txt", "text/plain", 4, "AQID")
        ))
        assertThrows(IllegalArgumentException::class.java) { CaptureCodec.encode(listOf(attached)) }
    }

    @Test
    fun schemaOneBackupRemainsReadable() {
        val legacyItem = sample.copy(originalContent = null)
        val legacy = CaptureCodec.encode(listOf(legacyItem)).replace("\"schemaVersion\": 3", "\"schemaVersion\": 1")
        assertEquals(listOf(legacyItem.copy(originalContent = legacyItem.content)), CaptureCodec.decode(legacy))
    }

    @Test
    fun schemaTwoBackupWithoutOriginalRemainsReadable() {
        val legacyItem = sample.copy(originalContent = null)
        val legacy = CaptureCodec.encode(listOf(legacyItem)).replace("\"schemaVersion\": 3", "\"schemaVersion\": 2")
        assertEquals(listOf(legacyItem.copy(originalContent = legacyItem.content)), CaptureCodec.decode(legacy))
    }

    @Test
    fun editPolicyPreservesOriginalSourceProvenanceLinksAndAttachments() {
        val existing = sample.copy(
            originalContent = "The exact first capture",
            sourceLabel = "Android share",
            sourceUrl = "https://example.test/original",
            contextIds = listOf("source-a"),
            attachments = listOf(CaptureAttachment("file-1", "brief.txt", "text/plain", 3, "AQID"))
        )
        val untrustedDraft = existing.copy(
            title = " Edited title ",
            content = " Edited working copy ",
            originalContent = "Overwritten original",
            sourceLabel = "Forged source",
            sourceUrl = "https://example.test/changed",
            contextIds = emptyList(),
            attachments = emptyList()
        )
        val prepared = CaptureEditingPolicy.prepare(existing, untrustedDraft, existing.updatedAt)
        assertEquals("Edited title", prepared.title)
        assertEquals("Edited working copy", prepared.content)
        assertEquals("The exact first capture", prepared.originalContent)
        assertEquals("Android share", prepared.sourceLabel)
        assertEquals("https://example.test/original", prepared.sourceUrl)
        assertEquals(listOf("source-a"), prepared.contextIds)
        assertEquals(existing.attachments, prepared.attachments)
        assertEquals(existing.createdAt, prepared.createdAt)
        assertEquals(existing.updatedAt + 1L, prepared.updatedAt)
    }

    @Test
    fun attachPolicyLinksExistingSourceAndPromotesInboxToActive() {
        val source = sample.copy(status = CaptureStatus.INBOX, originalContent = sample.content)
        val mission = sample.copy(id = "mission-1", sourceLabel = MissionContextPolicy.MISSION_SOURCE_LABEL, contextIds = emptyList())
        val decision = MissionContextPolicy.attach(listOf(source, mission), source.id, mission.id, 1_800_000_000_000L)
        org.junit.Assert.assertTrue(decision.accepted)
        val linkedItems = decision.updatedItems!!
        assertEquals(2, linkedItems.size)
        assertEquals(listOf(source.id), linkedItems.single { it.id == mission.id }.contextIds)
        assertEquals(CaptureStatus.ACTIVE, linkedItems.single { it.id == source.id }.status)
    }

    @Test
    fun attachPolicyRejectsArchivedRecordsAndNinthSource() {
        val source = sample.copy(status = CaptureStatus.INBOX)
        val mission = sample.copy(
            id = "mission-1",
            sourceLabel = MissionContextPolicy.MISSION_SOURCE_LABEL,
            contextIds = (1..MissionContextPolicy.MAX_CONTEXT_SOURCES).map { "existing-$it" }
        )
        val full = MissionContextPolicy.attach(listOf(source, mission), source.id, mission.id, 1_800_000_000_000L)
        org.junit.Assert.assertFalse(full.accepted)
        val archived = MissionContextPolicy.attach(
            listOf(source.copy(status = CaptureStatus.ARCHIVED), mission.copy(contextIds = emptyList())),
            source.id,
            mission.id,
            1_800_000_000_000L
        )
        org.junit.Assert.assertFalse(archived.accepted)
    }

    @Test
    fun attachPolicyIsIdempotentForAlreadyLinkedSource() {
        val source = sample.copy(status = CaptureStatus.ACTIVE)
        val mission = sample.copy(
            id = "mission-1",
            sourceLabel = MissionContextPolicy.MISSION_SOURCE_LABEL,
            contextIds = listOf(source.id)
        )
        val items = listOf(source, mission)
        val decision = MissionContextPolicy.attach(items, source.id, mission.id, 1_800_000_000_000L)
        org.junit.Assert.assertTrue(decision.accepted)
        org.junit.Assert.assertSame(items, decision.updatedItems)
    }

    @Test
    fun editedWorkingCopyKeepsTheOriginalCapturedText() {
        val edited = sample.copy(content = "Rewritten working notes")
        val restored = CaptureCodec.decode(CaptureCodec.encode(listOf(edited))).single()
        assertEquals("Rewritten working notes", restored.content)
        assertEquals(sample.content, restored.originalContent)
    }

}
